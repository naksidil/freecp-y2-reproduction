_base_ = '/content/freecp_t4/FreeCP/configs/cfg_voc21.py'
model = dict(type='SecondLookFreeCPSegmentation', model_type="SCLIP", clip_type="CLIP", vit_type="ViT-B/16", rp_thres=0.1, ap_thres=0.8, name_path='/content/freecp_t4/FreeCP/configs/cls_voc21.txt', use_pamr=False, use_secondlook=False)
test_dataloader = dict(num_workers=0, persistent_workers=False, dataset=dict(data_root='/content/freecp_t4/data/VOCdevkit/VOC2012',ann_file='/content/freecp_t4/runs/round2_20261111T211205_551816Z/splits/development200.txt'))
