_base_ = '/content/freecp_t4/FreeCP/configs/cfg_voc21.py'
model = dict(type='Y2FreeCPSegmentation', model_type="SCLIP",clip_type="CLIP",vit_type="ViT-B/16",rp_thres=.15,ap_thres=.8,name_path='/content/freecp_t4/FreeCP/configs/cls_voc21.txt', extra_queries=[], y2_tau=None, rescue_mode='y2')
test_dataloader = dict(num_workers=0,persistent_workers=False,dataset=dict(data_root='/content/freecp_t4/data/VOCdevkit/VOC2012',ann_file='/content/freecp_t4/runs/y2benchmark_20261112T234550_921116Z/splits/full_val1449.txt'))
