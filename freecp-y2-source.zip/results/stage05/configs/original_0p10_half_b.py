_base_ = '/content/freecp_t4/FreeCP/configs/cfg_voc21.py'
model = dict(type="AuditedFreeCPSegmentation", model_type="SCLIP", rp_score='original', rp_thres=0.1, ap_thres=0.8, name_path='/content/freecp_t4/runs/validation_20261111T162602_440029Z/vocabularies/half_b.txt')
test_dataloader = dict(num_workers=0, persistent_workers=False, dataset=dict(data_root='/content/freecp_t4/data/VOCdevkit/VOC2012', ann_file='/content/freecp_t4/runs/validation_20261111T162602_440029Z/evidence/val1449.split.txt'))
