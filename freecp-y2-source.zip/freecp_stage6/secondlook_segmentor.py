"""External FreeCP extension: bounded, background-only region rescue and PAMR.

No edits to the pinned upstream repository; no labels enter rescue decisions.
"""
import math
import numpy as np
import torch
import torch.nn.functional as F
from mmseg.registry import MODELS
from mmengine.structures import PixelData
from freecp_segmentor import FreeCPSegmentation
from pamr_chunked import ChunkedPAMR
from protocol6 import PARAMS, slide_boxes, best_component, expand_box, verify_views

@MODELS.register_module()
class SecondLookFreeCPSegmentation(FreeCPSegmentation):
    def __init__(self, use_secondlook=False, use_pamr=False, **kwargs):
        super().__init__(**kwargs)
        if (self.model_type!='SCLIP' or self.clip_type!='CLIP' or self.vit_type!='ViT-B/16'
            or self.dataset!='voc' or self.num_classes!=21 or self.num_bkg_prompts!=26
            or self.num_queries!=46 or not self.with_bkg or self.ignore_bkg
            or self.slide_crop!=384 or self.slide_stride!=112 or self.ap_thres!=0.8):
            raise ValueError('Round two requires the unchanged OpenAI SCLIP/VOC21 configuration.')
        self.use_secondlook=bool(use_secondlook); self.use_pamr=bool(use_pamr)
        if self.use_secondlook and self.rp_thres!=0.15:
            raise ValueError('Rescue must use original RP threshold 0.15.')
        self.pamr=ChunkedPAMR(PARAMS['pamr_iterations'],PARAMS['pamr_dilations']).to(self.query_features.device) if use_pamr else None

    @torch.no_grad()
    def predict(self, inputs, data_samples):
        if len(data_samples)!=1 or not isinstance(inputs,torch.Tensor) or inputs.shape[0]!=1:
            raise ValueError('This experiment requires tensor input and batch size one.')
        self.rp_audit=[]; self.rescue_audit=[]; self.proposals={}; self.rp_union=set()
        self.extra_clip_forwards=0; self.audit_enabled=True
        labels=torch.arange(20,device=inputs.device)
        metas=[s.metainfo for s in data_samples]
        # All 20 foreground classes, independent of any ground-truth annotation.
        seg_logits,_=self.forward_slide(inputs,labels,metas,self.slide_stride,self.slide_crop)
        if self.use_secondlook:
            seg_logits=self.apply_secondlook(inputs,seg_logits)
        outputs=super().postprocess_result(seg_logits,None,data_samples,labels)
        if self.use_pamr:
            scores=outputs[0].seg_logits.data.unsqueeze(0)
            guide=F.interpolate(inputs.float(),size=scores.shape[-2:],mode='bilinear',align_corners=False)
            scores=self.pamr(guide,scores,PARAMS['pamr_channel_chunk'])[0]
            outputs[0].set_data({'seg_logits':PixelData(data=scores),
                                 'pred_sem_seg':PixelData(data=scores.argmax(0,keepdim=True))})
        outputs[0].set_metainfo(dict(rp_audit=self.rp_audit,rescue_audit=self.rescue_audit,
            extra_clip_forwards=self.extra_clip_forwards,
            rejected_candidates_available=len([c for c in self.proposals if c not in self.rp_union]),
            pamr_applied=self.use_pamr))
        self.proposals={}
        return outputs

    def forward_slide(self,img,seg_label,img_metas,stride=112,crop_size=224):
        self._boxes=slide_boxes(img.shape[-2],img.shape[-1],crop_size,stride)
        self._crop_counter=0
        result=super().forward_slide(img,seg_label,img_metas,stride,crop_size)
        if self._crop_counter!=len(self._boxes):
            raise RuntimeError('Sliding-window geometry differs from pinned upstream.')
        return result

    def forward_feature(self,img,cls_label=None,logit_size=None):
        self._active_box=self._boxes[self._crop_counter]
        self._crop_counter+=1
        return super().forward_feature(img,cls_label,logit_size)

    def redundancy_purification(self,logits,logits_ref):
        x=logits[0,self.num_bkg_prompts:]; y=logits_ref[0,self.num_bkg_prompts:]
        scores=(x*y).sum((-1,-2))/(x.sum((-1,-2))+y.sum((-1,-2))+1e-8)
        if not torch.isfinite(scores).all():
            raise RuntimeError('Non-finite RP scores.')
        vals=scores.detach().float().cpu().tolist()
        if self.use_secondlook:
            # Save a small patch map BEFORE the original hard zeroing.
            for c,s in enumerate(vals):
                if PARAMS['candidate_floor']<=s<=self.rp_thres:
                    if c not in self.proposals or s>self.proposals[c]['rp_score']:
                        self.proposals[c]=dict(class_index=c,rp_score=s,box=self._active_box,
                            map=y[c].detach().float().clone())
        purified,candidates=super().redundancy_purification(logits,logits_ref)
        kept=candidates.detach().cpu().tolist(); self.rp_union.update(kept)
        self.rp_audit.append(dict(crop_index=len(self.rp_audit),box=list(self._active_box),
                                 scores=vals,kept_voc_class_ids=[i+1 for i in kept]))
        return purified,candidates

    def apply_secondlook(self,inputs,seg_logits):
        height,width=inputs.shape[-2:]; target_shape=seg_logits.shape[-2:]
        # Determine eligibility once from the untouched complete FreeCP output.
        bg_eligible=seg_logits[0,self.num_bkg_prompts:].amax(0)<=0.5
        proposals=sorted((p for c,p in self.proposals.items() if c not in self.rp_union),
                         key=lambda p:(-p['rp_score'],p['class_index']))
        evaluated=0
        for p in proposals:
            if evaluated>=PARAMS['max_candidates']:
                break
            c=p['class_index']; cam=p['map']
            row=dict(voc_class_id=c+1,rp_score=p['rp_score'],source_crop_box=list(p['box']),
                     accepted=False,restoration_pixels_above_0p5=0,pre_pamr_final_rescued_pixels=0)
            component=best_component(cam.cpu().numpy(),PARAMS['component_threshold'],PARAMS['min_component_patches'])
            if component is None:
                row['reason']='no_component_with_two_patches'; self.rescue_audit.append(row); continue
            support,box=component
            tx0,ty0,tx1,ty1=p['box']; gh,gw=cam.shape
            bx0,by0,bx1,by1=box
            tight=(tx0+math.floor(bx0*(tx1-tx0)/gw),ty0+math.floor(by0*(ty1-ty0)/gh),
                   tx0+math.ceil(bx1*(tx1-tx0)/gw),ty0+math.ceil(by1*(ty1-ty0)/gh))
            context=expand_box(tight,width,height,PARAMS['context_expansion'])
            evaluated+=1; similarities=[]
            for x0,y0,x1,y1 in [tight,context]:
                view=F.interpolate(inputs[:,:,y0:y1,x0:x1],size=(PARAMS['crop_size'],)*2,mode='bilinear',align_corners=False)
                _,cls_logits,_,_=self.net.cam(view,self.query_featuresLLM,self.model_type)
                cosine=cls_logits.reshape(-1).float()/self.net.logit_scale.exp().float()
                if cosine.numel()!=self.num_queries:
                    raise RuntimeError('Unexpected crop classification shape.')
                similarities.append(cosine.cpu().numpy()); self.extra_clip_forwards+=1
            verdict=verify_views(similarities,self.num_bkg_prompts+c,PARAMS['cosine_floor'],PARAMS['cosine_margin'])
            row.update(verdict); row.update(tight_box=list(tight),context_box=list(context),
                query_cosines=[a.tolist() for a in similarities],component_patches=int(support.sum()))
            if verdict['accepted']:
                sm=torch.as_tensor(support,device=cam.device,dtype=torch.float32)[None,None]
                local=F.interpolate((cam[None,None]*sm),size=(ty1-ty0,tx1-tx0),mode='bilinear',align_corners=False)
                hard=F.interpolate(sm,size=(ty1-ty0,tx1-tx0),mode='nearest')
                padding=(tx0,width-tx1,ty0,height-ty1)
                full=F.interpolate(F.pad(local,padding),size=target_shape,mode='bilinear',align_corners=False)[0,0]
                support_full=F.interpolate(F.pad(hard,padding),size=target_shape,mode='nearest')[0,0]>0
                restored=torch.where(bg_eligible & support_full,full,torch.zeros_like(full))
                # For previously globally RP-rejected classes the original map is zero.
                index=self.num_bkg_prompts+c
                seg_logits[0,index]=torch.maximum(seg_logits[0,index],restored.to(seg_logits.dtype))
                row['restoration_pixels_above_0p5']=int((restored>0.5).sum().item())
                row['reason']='accepted_both_views'
            else:
                row['reason']='failed_cosine_floor_or_all_query_margin'
            self.rescue_audit.append(row)
        if self.extra_clip_forwards>4:
            raise RuntimeError('Second-look compute budget exceeded.')
        foreground=seg_logits[0,self.num_bkg_prompts:]
        winner=torch.cat([1-foreground.amax(0,keepdim=True),foreground],dim=0).argmax(0)
        for row in self.rescue_audit:
            if row['accepted']:
                row['pre_pamr_final_rescued_pixels']=int((bg_eligible & (winner==row['voc_class_id'])).sum().item())
        return seg_logits
