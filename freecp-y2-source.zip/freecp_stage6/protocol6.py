"""Round two: a fixed development experiment; confirmation IDs remain unused."""
import hashlib
import json
from pathlib import Path

VERSION = 1
OLD50_SHA = '4f991c55bd461523a92888da6d3c871ebe9cd0d5a93de3522115ec90f055bad8'
SEED = 'YZM5110-round2-20261111-v1'
PARAMS = dict(candidate_floor=0.05, max_candidates=2, component_threshold=0.4,
              min_component_patches=2, context_expansion=1.5, crop_size=224,
              cosine_floor=0.20, cosine_margin=0.01,
              pamr_iterations=10, pamr_dilations=[8, 16], pamr_channel_chunk=4)
CONDITIONS = [
    dict(id='baseline', rp_thres=0.15, use_secondlook=False, use_pamr=False),
    dict(id='pamr', rp_thres=0.15, use_secondlook=False, use_pamr=True),
    dict(id='lower_rp', rp_thres=0.10, use_secondlook=False, use_pamr=False),
    dict(id='secondlook', rp_thres=0.15, use_secondlook=True, use_pamr=False),
    dict(id='secondlook_pamr', rp_thres=0.15, use_secondlook=True, use_pamr=True),
]

def split_digest(ids):
    return hashlib.sha256(('\n'.join(ids) + '\n').encode()).hexdigest()

def make_splits(train, val, old):
    train, val, old = list(train), list(val), list(old)
    if len(train) != 1464 or len(set(train)) != 1464:
        raise ValueError('Expected the original 1464 unique VOC training IDs.')
    if len(val) != 1449 or len(set(val)) != 1449 or set(train) & set(val):
        raise ValueError('Invalid validation split or train/val overlap.')
    if len(old) != 50 or split_digest(old) != OLD50_SHA or not set(old) <= set(train):
        raise ValueError('The previous train50 exclusion list changed.')
    if any(Path(i).name != i or not i.replace('_', '').isdigit() for i in train + val):
        raise ValueError('Malformed VOC IDs.')
    ranked = sorted(set(train) - set(old), key=lambda i: (hashlib.sha256((SEED + ':' + i).encode()).hexdigest(), i))
    return {'development200': ranked[:200], 'confirmation300': ranked[200:500],
            'unused914': ranked[500:], 'pilot3': old[:3]}

def scientific_protocol():
    return dict(version=VERSION, seed=SEED, conditions=CONDITIONS, fixed_parameters=PARAMS,
        hypothesis='Selective region verification can rescue RP-rejected foreground classes without the false-positive explosion of globally relaxed purification; PAMR may complement it through local refinement.',
        source='VOC2012 train: exclude the previously examined 50 images before deterministic SHA256 ranking.',
        development_images=200, reserved_confirmation_images=300,
        previously_seen_validation='All 1449 official val images were evaluated in round one. They are not an untouched test set.',
        selection='No parameter sweep in this package. Report every fixed condition. Rank the four extensions by unrounded development mIoU, ties by the CONDITIONS order. Ranking is exploratory, not proof of improvement.',
        confirmation_policy='This package writes IDs only; it neither loads nor evaluates confirmation images. Freeze any next plan before opening their results. Any later retuning must be disclosed.',
        verification='At most two globally RP-rejected foreground classes per image, each checked in a tight and 1.5x context crop. Both must beat ALL other foreground and background text queries by >0.01 cosine and reach >=0.20 cosine.',
        localization='Restore only the selected component of the pre-RP refined map, at pixels classified as background by the complete original output. Do not restore an entire class map.',
        pamr='Joint 21-channel maps AFTER FreeCP constructs its background score; RGB guidance from the resized input, float32, 10 iterations, dilations 8/16. Chunking changes memory scheduling only.',
        primary_outcome='VOC21 mIoU; pooled confusion counts, not mean per-image IoU.',
        secondary_outcomes=['per-class IoU', 'foreground-to-background errors', 'RP class retention before AP', 'accepted/false rescue class-image pairs', 'actual restored pixels', 'paired image bootstrap', 'test-step time after one warm-up', 'GPU peak allocated memory'],
        resource_limit='Timing includes audit, preprocessing and CPU geometry; it is pipeline time, not pure GPU-kernel latency.',
        novelty_established=False, improvement_demonstrated=False,
        method_parameters_are_design_choices=True)

def protocol_hash():
    return hashlib.sha256(json.dumps(scientific_protocol(), sort_keys=True).encode()).hexdigest()

def check_condition(condition):
    if condition not in CONDITIONS:
        raise ValueError('Condition is outside the frozen five-condition development plan.')

def slide_boxes(height, width, crop, stride):
    hg = max(height-crop+stride-1, 0)//stride+1
    wg = max(width-crop+stride-1, 0)//stride+1
    boxes = []
    for hi in range(hg):
        for wi in range(wg):
            y2, x2 = min(hi*stride+crop, height), min(wi*stride+crop, width)
            boxes.append((max(x2-crop, 0), max(y2-crop, 0), x2, y2))
    return boxes

def expand_box(box, width, height, factor=1.5):
    import math
    x0, y0, x1, y1 = box
    cx, cy = (x0+x1)/2, (y0+y1)/2
    hw, hh = (x1-x0)*factor/2, (y1-y0)*factor/2
    return (max(0, math.floor(cx-hw)), max(0, math.floor(cy-hh)),
            min(width, math.ceil(cx+hw)), min(height, math.ceil(cy+hh)))

def verify_views(scores, target, floor=0.20, margin=0.01):
    """Cosines, not softmax probabilities; all competing queries participate."""
    import numpy as np
    a = np.asarray(scores, dtype=float)
    if a.ndim != 2 or a.shape[0] != 2 or not 0 <= target < a.shape[1] or not np.isfinite(a).all():
        raise ValueError('Expected two finite vectors of query cosine similarities.')
    target_scores = a[:, target]
    rivals = np.delete(a, target, axis=1).max(axis=1)
    gaps = target_scores-rivals
    accepted = bool(np.all(target_scores >= floor) and np.all(gaps > margin))
    return dict(accepted=accepted, target_cosines=target_scores.tolist(),
                rival_cosines=rivals.tolist(), margins=gaps.tolist())

def best_component(values, threshold=0.4, min_patches=2):
    """8-connected positive component with largest activation mass; exclusive xyxy."""
    import numpy as np
    a = np.asarray(values, dtype=float)
    if a.ndim != 2 or not np.isfinite(a).all():
        raise ValueError('Expected a finite 2D map.')
    if a.max() <= 0:
        return None
    active = (a >= threshold*a.max()) & (a > 0)
    seen = np.zeros_like(active); components = []
    for y, x in zip(*np.where(active)):
        if seen[y,x]:
            continue
        stack=[(int(y),int(x))]; seen[y,x]=True; pixels=[]
        while stack:
            py,px=stack.pop(); pixels.append((py,px))
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    ny,nx=py+dy,px+dx
                    if 0<=ny<a.shape[0] and 0<=nx<a.shape[1] and active[ny,nx] and not seen[ny,nx]:
                        seen[ny,nx]=True; stack.append((ny,nx))
        if len(pixels)>=min_patches:
            components.append(pixels)
    if not components:
        return None
    pixels=max(components,key=lambda ps: sum(a[y,x] for y,x in ps))
    mask=np.zeros_like(active)
    for y,x in pixels: mask[y,x]=True
    ys,xs=np.where(mask)
    return mask, (int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1))
