"""Descriptive development analysis; no claims of held-out improvement."""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image
from metrics import summarize_confusion
from protocol6 import CONDITIONS, protocol_hash
from stage2_helpers import save_json

def parity(a,b,destination):
    a,b=Path(a),Path(b)
    aa=np.load(a/'per_image_confusions.npz');bb=np.load(b/'per_image_confusions.npz')
    if not np.array_equal(aa['image_ids'],bb['image_ids']) or not np.array_equal(aa['confusion_matrices'],bb['confusion_matrices']):
        raise RuntimeError('Baseline parity failed: confusion matrices differ.')
    for i in aa['image_ids']:
        name=str(i)+'_prediction.png'
        if not np.array_equal(np.array(Image.open(a/'figures'/name)),np.array(Image.open(b/'figures'/name))):
            raise RuntimeError('Baseline parity failed: pixel labels differ.')
    save_json(destination,dict(ok=True,n_images=len(aa['image_ids']),all_pixels_identical=True,
                              original_run=str(a),extension_disabled_run=str(b)))

def miou_samples(cms,weights):
    tp=np.diagonal(cms,axis1=1,axis2=2).astype(float)
    union=cms.sum(1)+cms.sum(2)-tp
    numerator=weights@tp;denominator=weights@union
    iou=np.divide(numerator,denominator,out=np.full_like(numerator,np.nan),where=denominator>0)
    return np.nanmean(iou,axis=1)*100

def analyze(folder,bootstrap=2000):
    folder=Path(folder);records=[];arrays={};image_ids=None;gt_margins=None;images=None
    for condition in CONDITIONS:
        path=folder/'conditions'/condition['id']
        report=json.loads((path/'evaluation_report.json').read_text())
        if not report['ok'] or report['condition']!=condition or report['manifest']['split_role']!='development200':
            raise RuntimeError('Incomplete or incompatible development condition.')
        a=np.load(path/'per_image_confusions.npz');cms=a['confusion_matrices']
        hashes=[(r['image_id'],r['image_sha256'],r['gt_sha256']) for r in report['per_image']]
        if image_ids is None:
            image_ids=a['image_ids'];gt_margins=cms.sum(2);images=hashes
        elif not np.array_equal(image_ids,a['image_ids']) or not np.array_equal(gt_margins,cms.sum(2)) or hashes!=images:
            raise RuntimeError('Conditions use different images, GT counts or order.')
        arrays[condition['id']]=cms
        metric=summarize_confusion(cms.sum(0));saved=report['independent_metrics_percent']
        if abs(metric['mIoU']-saved['mIoU'])>1e-9:
            raise RuntimeError('Stored mIoU does not match saved matrices.')
        present_count=retained_count=absent_count=false_retained=0
        attempts=accepted=true_accepted=false_accepted=0
        pairs={k:dict(total=0,rp_retained=0) for k in ['lt_1pct','1_to_5pct','ge_5pct']}
        for row,cm in zip(report['per_image'],cms):
            present=set(row['gt_present_foreground_class_ids']);kept=set(row['rp_kept_class_ids_union'])
            present_count+=len(present);retained_count+=len(present&kept)
            absent_count+=20-len(present);false_retained+=len(kept-present)
            for r in row['rescue_audit']:
                attempts+=int('target_cosines' in r)
                if r['accepted']:
                    accepted+=1;true_accepted+=int(r['voc_class_id'] in present);false_accepted+=int(r['voc_class_id'] not in present)
            gt=cm.sum(1);valid=gt.sum()
            for c in present:
                ratio=gt[c]/valid;key='lt_1pct' if ratio<.01 else '1_to_5pct' if ratio<.05 else 'ge_5pct'
                pairs[key]['total']+=1;pairs[key]['rp_retained']+=int(c in kept)
        totals=cms.sum(0)
        records.append(dict(condition=condition,mIoU=metric['mIoU'],metrics=metric,
            mean_test_step_seconds=float(np.mean([r['pipeline_test_step_seconds'] for r in report['per_image']])),
            median_test_step_seconds=float(np.median([r['pipeline_test_step_seconds'] for r in report['per_image']])),
            peak_allocated_gpu_gib=max(r['peak_allocated_gpu_gib'] for r in report['per_image']),
            extra_clip_forwards=sum(r['extra_clip_forwards'] for r in report['per_image']),
            rp_present_retained=retained_count,rp_present_total=present_count,
            rp_absent_retained=false_retained,rp_absent_total=absent_count,
            rescue_verified_candidates=attempts,rescue_accepted=accepted,
            rescue_accepted_present_class_pairs=true_accepted,rescue_accepted_absent_class_pairs=false_accepted,
            pre_pamr_final_rescued_pixels=sum(r['pre_pamr_final_rescued_pixels'] for row in report['per_image'] for r in row['rescue_audit']),
            foreground_pixels=int(totals[1:].sum()),foreground_to_background_pixels=int(totals[1:,0].sum()),
            foreground_to_wrong_foreground_pixels=int(totals[1:,1:].sum()-np.trace(totals[1:,1:])),
            class_area_diagnostics=pairs))
    rng=np.random.RandomState(511006)
    weights=rng.multinomial(len(image_ids),np.ones(len(image_ids))/len(image_ids),size=bootstrap).astype(float)
    sampled={key:miou_samples(cms,weights) for key,cms in arrays.items()}
    base=records[0]['mIoU'];comparisons=[]
    for r in records[1:]:
        key=r['condition']['id'];diff=sampled[key]-sampled['baseline']
        comparisons.append(dict(condition=key,delta_mIoU=r['mIoU']-base,
            paired_image_bootstrap_95ci=np.percentile(diff,[2.5,97.5]).tolist()))
    byid={r['condition']['id']:r for r in records}
    interaction=sampled['secondlook_pamr']-sampled['secondlook']-sampled['pamr']+sampled['baseline']
    order={c['id']:i for i,c in enumerate(CONDITIONS)}
    ranking=sorted(records[1:],key=lambda r:(-r['mIoU'],order[r['condition']['id']]))
    winner=ranking[0]
    summary=dict(ok=True,protocol_hash=protocol_hash(),n_images=len(image_ids),split='development200',records=records,
        comparisons_to_baseline=comparisons,bootstrap_replicates=bootstrap,
        interaction_mIoU=byid['secondlook_pamr']['mIoU']-byid['secondlook']['mIoU']-byid['pamr']['mIoU']+base,
        interaction_bootstrap_95ci=np.percentile(interaction,[2.5,97.5]).tolist(),
        development_ranking=[r['condition']['id'] for r in ranking],
        development_leader=winner['condition']['id'],leader_delta=winner['mIoU']-base,
        confirmation_evaluated=False,novelty_established=False,improvement_demonstrated=False,
        interpretation='Exploratory fixed-condition development only. CIs are descriptive, unadjusted for multiple comparisons/selection. Accepted present classes do not by themselves prove correct pixel localization. Small-area groups are class-image pairs, not object instances.')
    save_json(folder/'development_summary.json',summary)
    lines=['ASAMA 06 — GELISTIRME SONUCLARI','200 yeni train goruntusu; confirmation300 CALISTIRILMADI.','',
           'Yontem                 mIoU      Fark      Ortalama sn/goruntu']
    for r in records:
        lines.append(f"{r['condition']['id']:22s} {r['mIoU']:8.3f} {r['mIoU']-base:+8.3f} {r['mean_test_step_seconds']:12.3f}")
    lines+=['','Bu tablo gelistirme sonucudur; genelleme veya yayin basarisi kaniti degildir.',
            'Dogrulama goruntuleri ayrildi ve okunmadi. Sonuc ZIP dosyasini paylas.',
            'Surelere denetim islemleri dahildir; saf GPU gecikmesi degildir.']
    (folder/'SONUC_OZETI.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines),flush=True)
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir');p.add_argument('--parity',nargs=3);a=p.parse_args()
    if a.parity:parity(*a.parity)
    else:analyze(a.run_dir)
