"""Mandatory Colab-only synthetic checks of the actual rescue implementation."""
import argparse
import sys
import unittest
from pathlib import Path

def main(repo):
    sys.path.insert(0,str(Path(repo).resolve()))
    import torch
    from secondlook_segmentor import SecondLookFreeCPSegmentation

    class FakeCLIP(torch.nn.Module):
        def __init__(self,accept=True):
            super().__init__();self.logit_scale=torch.tensor(100.).log();self.calls=0;self.accept=accept
        def cam(self,image,text,model_type):
            assert tuple(image.shape)==(1,3,224,224)
            scores=torch.zeros(1,1,46)
            target=26+self.calls//2
            scores[0,0,target]=.4 if self.accept else .1
            if not self.accept:scores[0,0,0]=.5
            self.calls+=1
            return None,scores*100,None,None

    def make(accept=True,n=1):
        m=SecondLookFreeCPSegmentation.__new__(SecondLookFreeCPSegmentation)
        torch.nn.Module.__init__(m)
        m.num_bkg_prompts=26;m.num_queries=46;m.model_type='SCLIP'
        m.net=FakeCLIP(accept);m.query_featuresLLM=torch.zeros(46,4)
        m.proposals={};m.rp_union=set();m.rescue_audit=[];m.extra_clip_forwards=0
        cam=torch.zeros(4,4);cam[1:3,1:3]=1
        for i in range(n):m.proposals[i]=dict(class_index=i,rp_score=.14-.01*i,box=(0,0,8,8),map=cam.clone())
        return m

    class RescueTests(unittest.TestCase):
        def test_restore_is_local_and_protects_existing_foreground(self):
            m=make();image=torch.ones(1,3,8,8);scores=torch.zeros(1,46,8,8)
            scores[0,30,3,3]=.8
            before=scores.clone();after=m.apply_secondlook(image,scores)
            self.assertTrue(m.rescue_audit[0]['accepted']);self.assertEqual(m.extra_clip_forwards,2)
            self.assertEqual(float(after[0,26,3,3]),0)
            self.assertEqual(float(after[0,30,3,3]),float(before[0,30,3,3]))
            self.assertEqual(float(after[0,26,0,0]),0)
            self.assertGreater(int((after[0,26]>.5).sum()),0)
            torch.testing.assert_close(after[:,:26],before[:,:26])
            torch.testing.assert_close(after[:,27:],before[:,27:])

        def test_rejected_crop_is_exact_noop(self):
            m=make(False);image=torch.ones(1,3,8,8);scores=torch.rand(1,46,8,8);before=scores.clone()
            torch.testing.assert_close(m.apply_secondlook(image,scores),before,rtol=0,atol=0)
            self.assertFalse(m.rescue_audit[0]['accepted'])

        def test_budget_and_global_rp_retention(self):
            m=make(n=3);m.apply_secondlook(torch.ones(1,3,8,8),torch.zeros(1,46,8,8))
            self.assertEqual(m.extra_clip_forwards,4);self.assertEqual(len(m.rescue_audit),2)
            m=make();m.rp_union={0};before=torch.zeros(1,46,8,8)
            torch.testing.assert_close(m.apply_secondlook(torch.ones(1,3,8,8),before.clone()),before)
            self.assertEqual(m.extra_clip_forwards,0)

    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RescueTests))
    if not result.wasSuccessful():raise SystemExit(1)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);a=p.parse_args();main(a.repo)
