import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image
from analyze6 import miou_samples,parity
from metrics import summarize_confusion

class AnalysisTests(unittest.TestCase):
    def test_bootstrap_aggregates_counts_not_image_means(self):
        a=np.array([[[8,2],[1,1]],[[1,0],[8,90]]],dtype=np.int64)
        weights=np.array([[1.,1.],[2.,0.],[0.,2.]])
        got=miou_samples(a,weights)
        expected=[summarize_confusion(a.sum(0))['mIoU'],summarize_confusion(a[0]*2)['mIoU'],summarize_confusion(a[1]*2)['mIoU']]
        np.testing.assert_allclose(got,expected,rtol=0,atol=1e-12)
        self.assertNotAlmostEqual(got[0],np.mean(got[1:]))

    def test_parity_checks_pixels_even_when_counts_match(self):
        with tempfile.TemporaryDirectory() as d:
            a,b=Path(d)/'a',Path(d)/'b'
            for p in [a,b]:
                (p/'figures').mkdir(parents=True)
                np.savez_compressed(p/'per_image_confusions.npz',image_ids=np.array(['one']),confusion_matrices=np.eye(21,dtype=int)[None])
            x=np.array([[0,1],[1,0]],dtype=np.uint8)
            for p in [a,b]:Image.fromarray(x).save(p/'figures/one_prediction.png')
            parity(a,b,Path(d)/'parity.json')
            self.assertTrue(json.loads((Path(d)/'parity.json').read_text())['ok'])
            Image.fromarray(1-x).save(b/'figures/one_prediction.png')
            with self.assertRaises(RuntimeError):parity(a,b,Path(d)/'bad.json')

if __name__=='__main__':unittest.main()
