"""Memory-scheduled PAMR; derived from pamr_upstream.py (Apache-2.0).

Modified 2026-11-11: float32 finite checks and channel chunks; no OOM fallback.
Channels have no cross-channel interactions, so the PAMR update is unchanged.
"""
import torch
import torch.nn.functional as F
from pamr_upstream import PAMR

class ChunkedPAMR(PAMR):
    def forward(self, image, mask, channel_chunk=4):
        if channel_chunk < 1:
            raise ValueError('Channel chunk must be positive.')
        image, mask = image.float(), mask.float()
        if not torch.isfinite(image).all() or not torch.isfinite(mask).all():
            raise ValueError('Non-finite PAMR input.')
        mask=F.interpolate(mask, size=image.shape[-2:], mode='bilinear', align_corners=True)
        affinities=-self.aff_x(image)/(1e-8+0.1*self.aff_std(image))
        affinities=F.softmax(affinities.mean(1,keepdim=True),dim=2)
        for _ in range(self.num_iter):
            updated=torch.empty_like(mask)
            for start in range(0,mask.shape[1],channel_chunk):
                stop=start+channel_chunk
                updated[:,start:stop]=(self.aff_m(mask[:,start:stop].contiguous())*affinities).sum(2)
            mask=updated
        if not torch.isfinite(mask).all():
            raise ValueError('Non-finite PAMR result.')
        return mask
