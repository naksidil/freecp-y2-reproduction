"""Matched VOC evaluation, artifact capture and one discarded warm-up per run."""
import argparse
import json
import os
import sys
import time
import traceback
from pathlib import Path
from stage2_helpers import digest, save_json, UPSTREAM_SHA
from protocol6 import CONDITIONS, check_condition, protocol_hash, PARAMS

def main(repo,config,output):
    repo,config,output=map(lambda p:Path(p).resolve(),[repo,config,output])
    output.mkdir(parents=True,exist_ok=True)
    report=dict(ok=False,stage='round2_development',per_image=[],ground_truth_used_for_decisions=False,
        confirmation_evaluated=False,novelty_established=False,improvement_demonstrated=False,
        timing_note='One first-image warm-up is excluded. Timed test_step includes preprocessing and audits. Model loading, data-loader wait, output saving and metric calculations are excluded; not GPU-only latency.')
    matrices=[]; np=None; started=time.perf_counter()
    try:
        import subprocess
        if subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()!=UPSTREAM_SHA:
            raise RuntimeError('Unexpected FreeCP commit.')
        if subprocess.call(['git','-C',str(repo),'diff','--quiet','HEAD','--']):
            raise RuntimeError('Tracked FreeCP source was modified.')
        sys.path.insert(0,str(repo));os.chdir(repo)
        import numpy as np
        import torch
        from PIL import Image
        from mmengine.config import Config
        from mmengine.hooks import Hook
        from mmengine.runner import Runner
        import freecp_segmentor, custom_datasets, secondlook_segmentor
        from metrics import confusion_matrix,summarize_confusion
        cfg=Config.fromfile(str(config)); manifest=json.loads(config.with_suffix('.manifest.json').read_text())
        report['manifest']=manifest;report['condition']=manifest['condition']
        condition=manifest['condition'];check_condition(condition)
        if manifest['protocol_hash']!=protocol_hash() or digest(cfg.test_dataloader.dataset.ann_file)!=manifest['split_sha256']:
            raise RuntimeError('Split/protocol integrity failure.')
        if manifest['split_role'] not in ['pilot3','development200']:
            raise RuntimeError('Stage 06 never evaluates reserved confirmation or official val images.')
        ids=Path(cfg.test_dataloader.dataset.ann_file).read_text().split()
        if len(ids)!=manifest['n_images'] or len(ids)!=len(set(ids)):
            raise RuntimeError('Invalid selected IDs.')
        if manifest['model_kind']=='official':
            if cfg.model.type!='FreeCPSegmentation' or condition!=CONDITIONS[0] or manifest['split_role']!='pilot3':
                raise RuntimeError('Official implementation is used only for parity on old pilot images.')
        else:
            if (cfg.model.type!='SecondLookFreeCPSegmentation' or cfg.model.use_pamr!=condition['use_pamr']
                or cfg.model.use_secondlook!=condition['use_secondlook']):
                raise RuntimeError('Extension configuration differs from condition.')
        if (cfg.model.model_type!='SCLIP' or cfg.model.rp_thres!=condition['rp_thres']
            or cfg.model.ap_thres!=.8 or digest(cfg.model.name_path)!=manifest['vocabulary_sha256']):
            raise RuntimeError('Frozen model/vocabulary differs.')
        cfg.work_dir=str(output/'mmengine');cfg.launcher='none'
        cfg.randomness=dict(seed=511006,deterministic=False)
        cfg.dump(str(output/'resolved_config.py'))
        runner=Runner.from_cfg(cfg)
        report['gpu']=torch.cuda.get_device_name(0)
        report['class_names']=list(runner.test_dataloader.dataset.metainfo['classes'])
        palette=[v for c in runner.test_dataloader.dataset.metainfo['palette'] for v in c]
        palette=(palette+[0]*768)[:768];palette[765:768]=[128]*3
        figures=output/'figures';figures.mkdir(exist_ok=True)
        model=runner.model;model.eval()
        # Warm-up uses the first image of THIS split, never a held-out image.
        warm=next(iter(runner.test_dataloader))
        with torch.no_grad(): model.test_step(warm)
        torch.cuda.synchronize();del warm
        (output/'per_image.jsonl').write_text('')

        class Recorder(Hook):
            def before_test_iter(self,runner,batch_idx,data_batch=None):
                torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();self.t=time.perf_counter()
            def after_test_iter(self,runner,batch_idx,data_batch=None,outputs=None):
                torch.cuda.synchronize();elapsed=time.perf_counter()-self.t
                peak=torch.cuda.max_memory_allocated()/1024**3
                for sample in outputs:
                    image_path=Path(sample.metainfo['img_path']);image_id=image_path.stem
                    pred=sample.pred_sem_seg.data.squeeze(0).detach().cpu().numpy()
                    scores=sample.seg_logits.data
                    if not torch.isfinite(scores).all() or pred.ndim!=2 or pred.min()<0 or pred.max()>20:
                        raise RuntimeError('Invalid prediction.')
                    # GT is used for measurement only, after model output exists.
                    gt_path=Path(manifest['data_root'])/'SegmentationClass'/(image_id+'.png')
                    gt=np.array(Image.open(gt_path));cm=confusion_matrix(gt,pred.astype(np.int64))
                    image=Image.open(image_path).convert('RGB')
                    mask=Image.fromarray(pred.astype('uint8'),mode='P');mask.putpalette(palette)
                    mask.save(figures/(image_id+'_prediction.png'))
                    if len(report['per_image'])<3:
                        target=Image.fromarray(gt.astype('uint8'),mode='P');target.putpalette(palette)
                        preview=Image.new('RGB',(image.width*3,image.height))
                        for pos,im in enumerate([image,target,mask]):preview.paste(im.convert('RGB'),(pos*image.width,0))
                        preview.save(figures/(image_id+'_image_gt_prediction.jpg'))
                    rp=sample.metainfo.get('rp_audit',[]);rescue=sample.metainfo.get('rescue_audit',[])
                    if manifest['model_kind']=='extension' and (not rp or any(len(r['scores'])!=20 for r in rp)):
                        raise RuntimeError('Missing RP audit.')
                    if sample.metainfo.get('extra_clip_forwards',0)>4:
                        raise RuntimeError('Compute budget exceeded.')
                    if manifest['model_kind']=='extension' and bool(sample.metainfo.get('pamr_applied'))!=condition['use_pamr']:
                        raise RuntimeError('PAMR was not applied as declared.')
                    kept=sorted(set(c for r in rp for c in r['kept_voc_class_ids']))
                    present=sorted(int(c) for c in np.unique(gt) if 1<=c<=20)
                    row=dict(image_id=image_id,pipeline_test_step_seconds=elapsed,peak_allocated_gpu_gib=peak,
                        image_sha256=digest(image_path),gt_sha256=digest(gt_path),rp_audit=rp,rescue_audit=rescue,
                        rp_kept_class_ids_union=kept,gt_present_foreground_class_ids=present,
                        extra_clip_forwards=sample.metainfo.get('extra_clip_forwards',0),
                        predicted_classes=np.unique(pred).tolist(),pamr_applied=condition['use_pamr'])
                    report['per_image'].append(row);matrices.append(cm)
                    with (output/'per_image.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
                    n=len(matrices)
                    if n%10==0:print(f"{condition['id']}: {n}/{len(ids)} images",flush=True)

        runner.register_hook(Recorder())
        metrics=runner.test()
        if [r['image_id'] for r in report['per_image']]!=ids:
            raise RuntimeError('Evaluated ID order differs from locked split.')
        independent=summarize_confusion(np.sum(matrices,axis=0))
        if any(abs(independent[k]-float(metrics[k]))>.011 for k in ['mIoU','mAcc','aAcc']):
            raise RuntimeError('Independent metrics disagree with MMSeg.')
        ckpt=Path.home()/'.cache/clip/ViT-B-16.pt'
        if not ckpt.is_file() or digest(ckpt)!='5806e77cd80f8b59890b7e101eabd078d9fb84e6937f9e85e4ecb61988df416f':
            raise RuntimeError('Unexpected checkpoint.')
        report.update(ok=True,independent_metrics_percent=independent,metrics_crosscheck_passed=True,
                      real_images_evaluated=len(ids),checkpoint_sha256=digest(ckpt))
    except Exception as exc:
        report['error']=f'{type(exc).__name__}: {exc}';report['traceback']=traceback.format_exc();raise
    finally:
        report['wall_seconds_including_load']=time.perf_counter()-started
        if matrices and np is not None:
            np.savez_compressed(output/'per_image_confusions.npz',image_ids=np.array([r['image_id'] for r in report['per_image']]),confusion_matrices=np.stack(matrices))
        save_json(output/'evaluation_report.json',report)
        if report['ok']:
            members=[output/'evaluation_report.json',output/'per_image.jsonl',output/'per_image_confusions.npz']
            members+=sorted((output/'figures').glob('*_prediction.png'))
            save_json(output/'result_files_sha256.json',{str(p.relative_to(output)):digest(p) for p in members})
        print(json.dumps({k:report.get(k) for k in ['ok','real_images_evaluated','independent_metrics_percent','error']},indent=2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--config',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();main(a.repo,a.config,a.output)
