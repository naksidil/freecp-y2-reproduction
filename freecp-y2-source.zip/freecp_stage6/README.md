# FreeCP — Aşama 06: PAMR ve seçici ikinci bakış

Bu paket yeni yöntemin **geliştirme deneyidir**. İyileşme gösterildiği veya GPU'da önceden başarıyla çalıştığı iddia edilmez.

## Çalıştırma

1. 02 kurulumunun çalıştığı aynı canlı Colab sanal makinesini ve T4 GPU'yu kullan.
2. Not defterinin en altına yeni kod hücresi ekle. `COLAB_BASLAT.txt` içeriğini yapıştır.
3. Dosya sorulduğunda `06_FreeCP_PAMR_ve_Ikinci_Bakis.zip` seç.
4. Ön kontroller, üç görüntülük pilot, ardından beş koşul × 200 görüntü çalışır.
5. Çıktıda `Tamamlanan gelistirme kosulu: 5 / 5` ve `Deney tamamlandi.` beklenir.
6. İnen `freecp_round2_results_....zip` dosyasını paylaş. Bu, yüklediğin deney paketinden farklıdır.

03, 04 ve 05 sonuç klasörleri bu paketin ön koşulu değildir. Aynı VM'de 02 ortamı, FreeCP deposu, model ağırlığı ve VOC verisi yeterlidir. VM sıfırlandıysa önce 02 kurulumu gerekir. Bu paket paket yöneticisi çalıştırmaz veya mevcut depoyu değiştirmez. Oturumun sıfırlanması / farklı VM'ye geçiş için otomatik geri yükleme sunmaz.

Aynı canlı VM'de kesilirse aynı hücreyi aynı paketle çalıştır: tamamlanmış koşullar yeniden kullanılabilir, yarım koşul baştan çalışır. Ayrıntılı kayıtlar ve eski yarım çıktı korunur. Gerçek hata varsa yeniden başlatmadan önce hata ZIP'ini incelet.

## Sabit bilimsel plan

- OpenAI CLIP ViT-B/16, SCLIP + FreeCP; commit `6946aa7999ec5d57d1fe91968ba1ae35a1e53295`.
- Önceki train50 listesi pakette bulunur ve dışlanır. Geri kalan 1414 eğitim görüntüsü, kimliklere uygulanan sabit SHA256 sıralaması ile 200 geliştirme, 300 sonraki doğrulama ve 914 kullanılmayan görüntüye ayrılır.
- Üç pilot görüntü eski train50'den alınır; yeni doğrulama görüntüsü pilotta kullanılmaz.
- Önceki 1449 görüntülük resmi validation sonuçları zaten görülmüştür. Bu çalışma onları kör test gibi sunmaz.
- Bu paket confirmation300 kimliklerini kaydeder; görüntülerini/etiketlerini yüklemez, çıkarım yapmaz. Ayrılan küme aynı veri dağılımındandır; bağımsız ikinci veri kümesi sayılmaz.
- Tüm koşullar aynı 200 görüntüyü ve aynı 26 arka plan + 20 ön plan sorgusunu kullanır.

| Koşul | RP | İkinci bakış | PAMR |
|---|---:|---:|---:|
| baseline | 0.15 | kapalı | kapalı |
| pamr | 0.15 | kapalı | açık |
| lower_rp | 0.10 | kapalı | kapalı |
| secondlook | 0.15 | açık | kapalı |
| secondlook_pamr | 0.15 | açık | açık |

Bu ilk sürümde eşik taraması yoktur. Geliştirme koşullarının tümü raporlanır. Bu sonuçlardan sonra yöntem değişirse yeni sürüm ve yeni gelişim deneyi olarak belirtilmeli; ayrılmış doğrulamaya bakılarak ayar seçilmemelidir.

## İkinci bakışın tam tanımı

1. Orijinal RP skoru ve eşiği korunur; RP öncesi harita kaydedilir.
2. Yalnızca hiçbir kayan pencere kırpımında RP'den geçmeyen sınıflar adaydır. RP'den geçip AP'de elenen sınıflar bu deneyde geri alınmaz.
3. Aday RP skoru [0.05, 0.15] aralığındadır. Her sınıf için en yüksek skorlu kırpım seçilir. Sınıflar skora göre sıralanır; eşitlikte sınıf sırası kullanılır.
4. Haritanın maksimumunun %40'ı üzerindeki 8-komşu bileşenlerden aktivasyon toplamı en yüksek olan seçilir. En az iki yama gerekir. Kutu sınırları exclusive xyxy'dır; son satır/sütun kaybedilmez.
5. Görüntü başına en fazla iki sınıf; her biri dar kutu ve 1.5× genişletilmiş bağlam kutusuyla iki kez doğrulanır. En fazla **dört ek CLIP ileri geçişi** vardır. Kutular aynıysa yine iki ölçüm sayılır; bunlar istatistiksel olarak bağımsız kanıt değildir.
6. Kırpımlar 224×224'e yeniden boyutlanır. Aynı dondurulmuş CLIP'in orijinal CLS özelliği, FreeCP'nin mevcut Vicuna açıklama gömmeleriyle karşılaştırılır. Tüm 46 sorgu rekabet eder; yalnızca adayla karşılaştırma yapılmaz. Harici LLM çağrısı / API anahtarı yoktur.
7. Her iki görüntüde adayın kosinüsü en az 0.20, en güçlü rakibe farkı **0.01'den büyük** olmalıdır. Sıcaklıklı logit skoru kosinüse geri çevrilir. Bu eşikler önceden seçilmiş tasarım tercihleridir; başarıları kanıtlanmış değildir.
8. Kabul edilen sınıfın RP öncesi haritası yalnızca seçilen bileşen içinde ve orijinal tam FreeCP sonucunun arka plan piksellerinde eklenir. Orijinal ön plan pikselleri ikinci bakış tarafından değiştirilmez. Kabul, doğru piksel geri kazanımıyla aynı şey değildir.

## PAMR

FreeCP'nin 20 ön plan haritası ve `1 - max(foreground)` arka plan haritasından oluşan 21 kanal birlikte iyileştirilir. Kılavuz, ağın normalize edilmiş RGB girdisinin çıktı boyutuna ölçeklenmiş halidir. İşlem float32; 10 iterasyon; dilation 8 ve 16'dır. Bellek tüketimi için dört kanal birlikte hesaplanır; kanallar arasında etkileşim bulunmadığından matematiksel güncelleme korunur. Bu eşdeğerlik Colab'da standart PAMR'a karşı test edilir. OOM olursa PAMR sessizce atlanmaz; deney hata kaydıyla durur.

## Ön kontroller ve çıktı

- Çalışan CUDA/MMCV ortamı ve tokenizer/model/depo bütünlüğü.
- Sabit split, kutu geometrisi, tüm rakiplerle doğrulama, PAMR eşdeğerliği ve bellek bölme testleri.
- Gerçek ikinci bakış kodunda sentetik kabul/red, yerellik, ön plan koruma ve dört çağrı sınırı.
- Üç gerçek görüntüde resmi FreeCP ile eklentiler kapalı sürümün **tüm piksel etiketleri ve karışıklık matrisleri eşit** olmalıdır.
- Üç görüntüde iki eklentinin birlikte çalışması denenir. Bu pilot başarı veya genelleme kanıtı değildir.

Çıktılar: `round2_report.json`, `protocol.json`, `split_manifest.json`, `baseline_parity.json`, `development_summary.json`, `SONUC_OZETI.txt`, koşul başına maske PNG'leri, ilk üç görüntünün önceden belirlenmiş önizlemeleri, görüntü başına karışıklık matrisi, RP/ikinci bakış denetimi, ortam ve hata kayıtları.

mIoU toplu karışıklık matrisinden yeniden hesaplanır ve MMSeg ile karşılaştırılır. Eşleştirilmiş görüntü bootstrap güven aralıkları keşifseldir; çoklu karşılaştırma veya model seçimi için düzeltilmez. Kaynak ölçümünde ilk görüntüyle bir ısınma çalışması dışlanır; test_step süresi ön işleme ve denetimi içerir, saf GPU süresi değildir. Her koşul ayrı süreçte çalışır. Çalıştırma sırası sabittir; termal/yük etkileri ayrıca sınırlılık olarak raporlanmalıdır.

## Kaynaklar ve atıf

- FreeCP: Chen et al., ICCV 2025, https://arxiv.org/abs/2508.00557 — ana yöntem; RP/AP kodu değiştirilmez.
- NACLIP: Hajimiri et al., WACV 2025, https://arxiv.org/abs/2404.08181 — PAMR karşılaştırmasına motivasyon ve kaynak uygulama: https://github.com/sinahmr/NACLIP/blob/main/pamr.py
- PAMR: Araslanov and Roth, CVPR 2020, Single-Stage Semantic Segmentation from Image Labels; https://github.com/visinf/1-stage-wseg — telif/Apache-2.0 metni korunmuştur.
- CLIP as RNN: Sun et al., CVPR 2024, https://arxiv.org/abs/2312.07661 — bölgesel yeniden doğrulama fikrinin öncüllerindendir; kodu burada kullanılmamıştır.

PAMR ve bölgesel doğrulama kendi başlarına yeni yöntemler değildir. Özgünlük, önerilen sınırlı ve bölgesel geri kazanım kararının gerekçesi, kontrol deneyleri ve literatür karşılaştırmasıyla değerlendirilmelidir. Yeni parçaların kodu ve deney düzeni ChatGPT/Codex yardımıyla hazırlanmıştır; nihai raporda AI kullanımı açıklanmalıdır.
