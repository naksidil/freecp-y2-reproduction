"""One entrypoint; no installations, prior-run dependency, or held-out inference."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime,timezone
from pathlib import Path
from stage2_helpers import save_json,digest,git_blob_sha,UPSTREAM_SHA,BPE_GIT_BLOB_SHA,run_logged
from protocol6 import CONDITIONS,PARAMS,make_splits,scientific_protocol,protocol_hash,split_digest

def fingerprint(folder):
    h=hashlib.sha256()
    for p in sorted(Path(folder).iterdir()):
        if p.is_file() and p.suffix in {'.py','.json','.txt','.md'}:
            h.update(p.name.encode()+b'\0'+p.read_bytes())
    return h.hexdigest()

def select_run(root,code_hash):
    pointer=root/'latest_round2_work.json'
    if pointer.is_file():
        old=json.loads(pointer.read_text());folder=Path(old['artifact']).resolve()
        if folder.parent!=(root/'runs').resolve() or not folder.name.startswith('round2_'):
            raise ValueError('Invalid resume path.')
        if old.get('package_fingerprint')==code_hash and (folder/'round2_report.json').is_file():
            return folder,json.loads((folder/'round2_report.json').read_text()),True
    run_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    folder=root/'runs'/('round2_'+run_id);folder.mkdir(parents=True)
    state=dict(ok=False,run_id=run_id,package_fingerprint=code_hash,protocol_hash=protocol_hash(),
        planned_conditions=5,completed_conditions=[],confirmation_evaluated=False,attempts=[])
    save_json(pointer,dict(artifact=str(folder),package_fingerprint=code_hash))
    save_json(folder/'round2_report.json',state)
    return folder,state,False

def write_config(repo,voc,split,condition,dest,role,official=False):
    kind='FreeCPSegmentation' if official else 'SecondLookFreeCPSegmentation'
    extra='' if official else f', use_pamr={condition["use_pamr"]!r}, use_secondlook={condition["use_secondlook"]!r}'
    name_path=repo/'configs/cls_voc21.txt'
    dest.write_text(f'_base_ = {str(repo/"configs/cfg_voc21.py")!r}\n'
        f'model = dict(type={kind!r}, model_type="SCLIP", clip_type="CLIP", vit_type="ViT-B/16", '
        f'rp_thres={condition["rp_thres"]!r}, ap_thres=0.8, name_path={str(name_path)!r}{extra})\n'
        'test_dataloader = dict(num_workers=0, persistent_workers=False, '
        f'dataset=dict(data_root={str(voc)!r},ann_file={str(split)!r}))\n',encoding='utf-8')
    manifest=dict(protocol_hash=protocol_hash(),upstream_commit=UPSTREAM_SHA,source_split='train',
        split_role=role,split_sha256=digest(split),n_images=len(split.read_text().split()),
        data_root=str(voc),condition=condition,model_kind='official' if official else 'extension',
        vocabulary_sha256=digest(name_path))
    save_json(dest.with_suffix('.manifest.json'),manifest)
    return manifest

def is_complete(output,manifest):
    try:
        r=json.loads((output/'evaluation_report.json').read_text())
        hashes=json.loads((output/'result_files_sha256.json').read_text())
        if len(hashes)!=manifest['n_images']+3 or any(not (output/name).is_file() or digest(output/name)!=h for name,h in hashes.items()):
            return False
        return (r['ok'] is True and r['manifest']==manifest and r['real_images_evaluated']==manifest['n_images']
            and (output/'per_image_confusions.npz').is_file()
            and len(list((output/'figures').glob('*_prediction.png')))==manifest['n_images'])
    except (OSError,ValueError,KeyError):return False

def main(root='/content/freecp_t4'):
    root=Path(root).resolve();root.mkdir(parents=True,exist_ok=True)
    source=Path(__file__).resolve().parent;code_hash=fingerprint(source)
    folder,state,resumed=select_run(root,code_hash)
    state['ok']=False;state.pop('error',None);state.pop('traceback',None)
    state['attempts'].append(dict(started_utc=datetime.now(timezone.utc).isoformat(),resumed=resumed))
    code=1
    try:
        scripts=folder/'scripts'
        if not scripts.exists():
            scripts.mkdir()
            for p in source.iterdir():
                if p.is_file() and p.suffix in {'.py','.txt','.md','.json'}:shutil.copy2(p,scripts/p.name)
        if fingerprint(scripts)!=code_hash:raise RuntimeError('Resume source fingerprint differs.')
        python=root/'env_py310/bin/python';repo=root/'FreeCP';voc=root/'data/VOCdevkit/VOC2012'
        for p in [python,repo/'configs/cfg_voc21.py',voc/'ImageSets/Segmentation/train.txt',voc/'ImageSets/Segmentation/val.txt']:
            if not p.is_file():
                raise FileNotFoundError(f'{p} missing. This VM needs stage 02 setup. Stages 03,04,05 need not be rerun for stage 06.')
        if git_blob_sha(repo/'open_clip/bpe_simple_vocab_16e6.txt.gz')!=BPE_GIT_BLOB_SHA:
            raise RuntimeError('Tokenizer checksum differs.')
        train=(voc/'ImageSets/Segmentation/train.txt').read_text().split()
        val=(voc/'ImageSets/Segmentation/val.txt').read_text().split()
        old=(scripts/'previous_train50.txt').read_text().split()
        splits=make_splits(train,val,old)
        splitdir=folder/'splits';splitdir.mkdir(exist_ok=True)
        for name,ids in splits.items():
            path=splitdir/(name+'.txt');raw='\n'.join(ids)+'\n'
            if path.exists() and path.read_text()!=raw:raise RuntimeError('Saved split differs.')
            path.write_text(raw)
        split_manifest={name:dict(n_images=len(ids),sha256=split_digest(ids)) for name,ids in splits.items()}
        split_manifest['source_train_sha256']=digest(voc/'ImageSets/Segmentation/train.txt')
        split_manifest['old50_excluded']=True;split_manifest['confirmation_evaluated']=False
        save_json(folder/'split_manifest.json',split_manifest)
        save_json(folder/'protocol.json',scientific_protocol())
        # Verify known pilot content; no confirmation image or mask is opened.
        for r in json.loads((scripts/'reference_pilot.json').read_text()):
            for field,subdir,suffix in [('image_sha256','JPEGImages','.jpg'),('gt_sha256','SegmentationClass','.png')]:
                if digest(voc/subdir/(r['image_id']+suffix))!=r[field]:raise RuntimeError('Pilot dataset differs from round one.')
        for i in splits['development200']:
            for subdir,suffix in [('JPEGImages','.jpg'),('SegmentationClass','.png')]:
                if not (voc/subdir/(i+suffix)).is_file():raise FileNotFoundError('Missing development image/mask: '+i)
        env=os.environ.copy();env.update(MPLBACKEND='Agg',TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1')
        def run(cmd,label,cwd=None):run_logged(cmd,label,folder,cwd=cwd,env=env)
        run([python,scripts/'check_runtime.py',repo,folder/'runtime_report.json'],'runtime_check',repo)
        freeze=subprocess.check_output([str(python),'-m','pip','freeze'],text=True,env=env)
        if (folder/'pip_freeze.txt').exists() and (folder/'pip_freeze.txt').read_text()!=freeze:
            raise RuntimeError('Environment changed since this round started.')
        (folder/'pip_freeze.txt').write_text(freeze)
        run([python,'-m','unittest','-v','test_metrics','test_round2','test_analysis6'],'unit_tests',scripts)
        run([python,scripts/'test_model6.py','--repo',repo],'model_unit_tests',repo)
        configdir=folder/'configs';configdir.mkdir(exist_ok=True)

        def evaluate(name,condition,role,official=False):
            config=configdir/(name+'.py');out=folder/('pilot' if role=='pilot3' else 'conditions')/name
            manifest=write_config(repo,voc,splitdir/(role+'.txt'),condition,config,role,official)
            if is_complete(out,manifest):print('RESUME: '+name,flush=True)
            else:
                if out.exists():
                    partial=folder/'partial_runs';partial.mkdir(exist_ok=True)
                    out.rename(partial/(name+'_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')))
                run([python,scripts/'evaluate6.py','--repo',repo,'--config',config,'--output',out],name,repo)
            if not is_complete(out,manifest):raise RuntimeError('Incomplete condition '+name)
            return out

        print('ON KONTROL: 3 goruntude orijinal, eklentiler kapali, ve iki eklenti acik.',flush=True)
        official=evaluate('official',CONDITIONS[0],'pilot3',True)
        disabled=evaluate('extensions_off',CONDITIONS[0],'pilot3')
        run([python,scripts/'analyze6.py','--parity',official,disabled,folder/'baseline_parity.json'],'baseline_parity',repo)
        evaluate('combined_smoke',CONDITIONS[4],'pilot3')
        state['baseline_parity_passed']=True;save_json(folder/'round2_report.json',state)
        print('GELISTIRME: 5 kosul x 200 goruntu. Ayrilan 300 dogrulama goruntusu CALISTIRILMAYACAK.',flush=True)
        state['completed_conditions']=[]
        for c in CONDITIONS:
            output=evaluate(c['id'],c,'development200')
            r=json.loads((output/'evaluation_report.json').read_text())
            state['completed_conditions'].append(c['id']);save_json(folder/'round2_report.json',state)
            print(f"TAMAMLANDI {len(state['completed_conditions'])}/5: {c['id']} mIoU={r['independent_metrics_percent']['mIoU']:.4f}",flush=True)
        run([python,scripts/'analyze6.py','--run-dir',folder],'development_analysis',repo)
        state['ok']=True;code=0
    except (Exception,KeyboardInterrupt) as exc:
        state['error']=f'{type(exc).__name__}: {exc}';state['traceback']=traceback.format_exc()
        print(state['traceback'],flush=True)
    finally:
        state['attempts'][-1].update(finished_utc=datetime.now(timezone.utc).isoformat(),ok=state['ok'])
        save_json(folder/'round2_report.json',state)
        archive=shutil.make_archive(str(root/('freecp_round2_results_'+state['run_id'])),'zip',root_dir=folder)
        save_json(root/'latest_round2_result.json',dict(ok=state['ok'],archive=archive,artifact=str(folder),
            completed_conditions=len(state['completed_conditions']),error=state.get('error')))
        print('RESULT_ZIP='+archive,flush=True)
        print('5/5 gelistirme tamamlandi.' if state['ok'] else 'Deney durdu; hata ZIP dosyasina kaydedildi.',flush=True)
    return code

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',default='/content/freecp_t4');a=p.parse_args()
    raise SystemExit(main(a.root))
