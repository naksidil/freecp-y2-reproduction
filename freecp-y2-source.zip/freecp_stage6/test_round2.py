import hashlib
import json
import unittest
from pathlib import Path
import numpy as np
from protocol6 import (make_splits, slide_boxes, expand_box, best_component, verify_views,
                       CONDITIONS, check_condition, protocol_hash, OLD50_SHA)

class ProtocolTests(unittest.TestCase):
    def test_splits_disjoint_reproducible_and_exclude_old50(self):
        old=Path(__file__).with_name('previous_train50.txt').read_text().split()
        train=old+[f'2099_{i:06d}' for i in range(1414)]
        val=[f'2098_{i:06d}' for i in range(1449)]
        a=make_splits(train,val,old); b=make_splits(list(reversed(train)),val,old)
        self.assertEqual(a,b)
        self.assertEqual([len(a[k]) for k in ['development200','confirmation300','unused914','pilot3']],[200,300,914,3])
        sets=[set(a[k]) for k in ['development200','confirmation300','unused914']]+[set(old),set(val)]
        self.assertTrue(all(not (s&t) for i,s in enumerate(sets) for t in sets[i+1:]))
        with self.assertRaises(ValueError): make_splits(train,train[:1449],old)
        with self.assertRaises(ValueError): make_splits(train,val,old[::-1])

    def test_fixed_conditions(self):
        for c in CONDITIONS: check_condition(c)
        with self.assertRaises(ValueError): check_condition(dict(CONDITIONS[0],rp_thres=.01))
        self.assertEqual(len(protocol_hash()),64)

    def test_exclusive_boxes_cover_small_and_large_inputs(self):
        for h,w in [(200,300),(448,597),(448,2048),(384,384)]:
            count=np.zeros((h,w),dtype=int)
            for x0,y0,x1,y1 in slide_boxes(h,w,384,112):
                self.assertTrue(0<=x0<x1<=w and 0<=y0<y1<=h)
                count[y0:y1,x0:x1]+=1
            self.assertTrue((count>0).all())
        self.assertEqual(slide_boxes(200,300,384,112),[(0,0,300,200)])

    def test_edge_component_keeps_last_row_and_column(self):
        a=np.zeros((4,4));a[2:,3]=1
        mask,box=best_component(a)
        self.assertEqual(box,(3,2,4,4));self.assertEqual(mask.sum(),2)
        self.assertIsNone(best_component(np.zeros((4,4))))
        a=np.zeros((4,4));a[1,1]=1
        self.assertIsNone(best_component(a))

    def test_component_uses_mass_and_eight_connectivity(self):
        a=np.zeros((8,8));a[0,0]=1;a[1,1]=1;a[6,6]=.5;a[6,7]=.5
        mask,box=best_component(a)
        self.assertEqual(box,(0,0,2,2));self.assertEqual(mask.sum(),2)

    def test_context_box_clips_and_contains_original(self):
        for b in [(0,0,4,4),(8,8,10,10),(3,3,7,7)]:
            c=expand_box(b,10,10)
            self.assertTrue(0<=c[0]<=b[0] and 0<=c[1]<=b[1])
            self.assertTrue(b[2]<=c[2]<=10 and b[3]<=c[3]<=10)

    def test_verification_requires_both_views_and_all_competitors(self):
        a=np.zeros((2,46));a[:,26]=.3;a[:,0]=.27
        self.assertTrue(verify_views(a,26)['accepted'])
        a[1,0]=.31 # background rival must reject
        self.assertFalse(verify_views(a,26)['accepted'])
        a[1,0]=0;a[0,45]=.4 # distant foreground competitor must reject
        self.assertFalse(verify_views(a,26)['accepted'])
        a[:]=0;a[:,26]=.19
        self.assertFalse(verify_views(a,26)['accepted'])
        a[:]=0;a[:,26]=.3;a[:,27]=.3
        self.assertFalse(verify_views(a,26)['accepted'])
        a[0,0]=np.nan
        with self.assertRaises(ValueError): verify_views(a,26)

try:
    import torch
except ImportError:
    torch=None

@unittest.skipIf(torch is None,'PyTorch is absent on build host; mandatory in Colab.')
class PAMRTests(unittest.TestCase):
    def test_chunking_matches_upstream_all_channels(self):
        from pamr_upstream import PAMR
        from pamr_chunked import ChunkedPAMR
        torch.manual_seed(511006)
        device='cuda' if torch.cuda.is_available() else 'cpu'
        image=torch.rand(1,3,17,19,device=device)
        mask=torch.rand(1,21,17,19,device=device)
        original=PAMR(3,[1,3]).to(device)
        variant=ChunkedPAMR(3,[1,3]).to(device)
        expected=original(image,mask)
        actual=variant(image,mask,4)
        torch.testing.assert_close(actual,expected,rtol=1e-6,atol=1e-6)

    def test_pamr_preserves_zero_class_and_constant_score(self):
        from pamr_chunked import ChunkedPAMR
        m=ChunkedPAMR(10,[8,16])
        guide=torch.rand(1,3,13,17)
        scores=torch.ones(1,3,13,17)*.7;scores[:,0]=0
        actual=m(guide,scores,2)
        self.assertEqual(int(torch.count_nonzero(actual[:,0])),0)
        torch.testing.assert_close(actual[:,1:],scores[:,1:],rtol=1e-5,atol=1e-6)

    def test_nonfinite_fails_instead_of_silent_fallback(self):
        from pamr_chunked import ChunkedPAMR
        with self.assertRaises(ValueError):
            ChunkedPAMR(1,[1])(torch.full((1,3,2,2),float('nan')),torch.zeros(1,2,2,2))

if __name__=='__main__': unittest.main()
