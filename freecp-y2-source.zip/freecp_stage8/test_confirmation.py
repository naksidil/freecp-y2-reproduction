import io
import json
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
import numpy as np
from PIL import Image
from analyze8 import miou,paired_comparison,rescue_summary,verify_random_budgets,analyze
from metrics import confusion_matrix,summarize_confusion
from protocol8 import CONDITIONS,TAU,protocol_hash,validate_manifest,verify_reviewed_evidence
from protocol7 import CONF_SHA,rescue_indices
from stage2_helpers import save_json,digest
from run_y2_confirmation import write_config

class ConfirmationTests(unittest.TestCase):
    def test_reviewed_rule_selects_half(self):
        _,s=verify_reviewed_evidence(Path(__file__).parent)
        self.assertEqual(s['proposed_common_tau'],.5)
    def test_tensor_base_mask_is_authoritative_at_half_boundary(self):
        keep,rescue=rescue_indices([float(np.float16(.15)),.2],[0,0],.5,base_mask=[False,True])
        self.assertEqual(keep.tolist(),[1]);self.assertEqual(rescue.tolist(),[])
    def test_aggregate_miou_not_average_image_iou(self):
        a=np.array([[[1000,0],[0,0]],[[0,0],[90,10]]])
        self.assertAlmostEqual(float(miou(a.sum(0))),summarize_confusion(a.sum(0))['mIoU'])
        self.assertNotAlmostEqual(float(miou(a.sum(0))),float(miou(a).mean()))
    def test_identical_predictions_have_zero_interval_and_influence(self):
        a=np.array([[[5,1],[2,3]],[[8,0],[1,4]],[[2,0],[1,7]]])
        r=paired_comparison(a,a,40)
        self.assertEqual(r['delta_mIoU'],0);self.assertEqual(r['paired_bootstrap_95ci'],[0,0])
        self.assertEqual(r['leave_one_out_min'],0)
    def test_unmatched_gt_is_rejected(self):
        a=np.array([np.eye(2,dtype=int)]*3);b=a.copy();b[0,0,0]+=1
        with self.assertRaises(ValueError):paired_comparison(a,b,10)
    def test_random_budget_mismatch_is_rejected(self):
        row=dict(image_id='x',rp_audit=[dict(box=[0,0,2,2],original_rp_kept_class_ids=[1],rescued_class_ids=[2])])
        other=json.loads(json.dumps(row));other['rp_audit'][0]['rescued_class_ids']=[]
        with self.assertRaises(ValueError):verify_random_budgets([row],[other])
    def test_added_class_is_unknown_not_false(self):
        w=dict(rescued_class_ids=[1,2,21],ap_kept_class_ids=[1,21],gt_valid_pixels=2,gt_voc_counts=[1]+[0]*19)
        r=rescue_summary([dict(rp_audit=[w])])
        self.assertEqual(r['voc_true_pairs'],1);self.assertEqual(r['voc_false_pairs'],1)
        self.assertEqual(r['extra_pairs_presence_unknown'],1);self.assertEqual(r['voc_rescue_precision'],.5)
        self.assertEqual(r['rescued_pairs_surviving_ap'],2)
    def test_no_threshold_or_split_drift(self):
        m=dict(protocol_hash=protocol_hash(),condition=CONDITIONS[1],model_kind='y2',split_role='confirmation300',split_sha256=CONF_SHA,n_images=300)
        cfg=SimpleNamespace(model=SimpleNamespace(type='Y2FreeCPSegmentation',y2_tau=.5,rescue_mode='y2'))
        validate_manifest(m,cfg);cfg.model.y2_tau=.2
        with self.assertRaises(ValueError):validate_manifest(m,cfg)
        cfg.model.y2_tau=.5;m['split_role']='development200'
        with self.assertRaises(ValueError):validate_manifest(m,cfg)
    def test_config_contains_exact_condition(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'configs').mkdir();(p/'configs/cls_voc21.txt').write_text('vocab')
            split=p/'split.txt';split.write_text('a\nb\nc\n')
            for c in CONDITIONS:
                out=p/(c['id']+'.py')
                m=write_config(p,p,split,c,out,'pilot3',dict(extra_queries=['wall']))
                ns={};exec(out.read_text(),ns)
                self.assertEqual(ns['model']['y2_tau'],None if c['method']=='baseline' else .5)
                self.assertEqual(ns['model']['rescue_mode'],'random' if c['method']=='random' else 'y2')
                self.assertEqual(m['n_output_classes'],22 if c['expanded'] else 21)

class IntegrationTests(unittest.TestCase):
    def test_six_saved_conditions_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);ids=np.array([f'fake_{i:04d}' for i in range(300)]);gt=np.array([[0,0],[1,1]])
            for c in CONDITIONS:
                p=root/'conditions'/c['id'];fig=p/'figures';fig.mkdir(parents=True)
                rows=[];cms=[]
                for i,name in enumerate(ids):
                    pred=gt.copy()
                    if c['method']=='baseline':pred[1,1]=0
                    elif c['method']=='random':pred[1,1]=2
                    cm=confusion_matrix(gt,pred);cms.append(cm)
                    for suffix in ['prediction','raw']:Image.fromarray(pred.astype('uint8')).save(fig/(name+'_'+suffix+'.png'))
                    resc=[] if c['method']=='baseline' else [1 if c['method']=='y2' else 3]
                    w=dict(box=[0,0,2,2],original_rp_kept_class_ids=[2],rescued_class_ids=resc,
                           ap_kept_class_ids=[2]+resc,gt_valid_pixels=4,gt_voc_counts=[2]+[0]*19)
                    rows.append(dict(image_id=str(name),image_sha256='same-image',gt_sha256='same-gt',
                        rp_audit=[w],pipeline_test_step_seconds=.1,peak_allocated_gpu_gib=.5,
                        extra_label_pixels=0,extra_label_pixels_on_voc_foreground=0))
                np.savez_compressed(p/'per_image_confusions.npz',image_ids=ids,confusion_matrices=np.stack(cms))
                (p/'per_image.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
                m=dict(protocol_hash=protocol_hash(),condition=c,split_role='confirmation300')
                save_json(p/'evaluation_report.json',dict(ok=True,manifest=m,real_images_evaluated=300,
                    independent_metrics_percent=summarize_confusion(np.stack(cms).sum(0)),wall_seconds_including_load=10))
                save_json(p/'result_files_sha256.json',{str(q.relative_to(p)):digest(q) for q in p.rglob('*') if q.is_file()})
            with redirect_stdout(io.StringIO()):r=analyze(root,draws=10)
            self.assertTrue(r['ok']);self.assertEqual(len(r['results']),6);self.assertEqual(len(r['comparisons']),6)
            self.assertTrue(r['random_budget_verified']);self.assertEqual(r['comparisons'][0]['changed_images'],300)
            self.assertGreater(r['comparisons'][0]['delta_mIoU'],0)
            self.assertEqual(sum(c['primary'] for c in r['comparisons']),1)
            self.assertTrue((root/'SONUC_OZETI.txt').is_file())

if __name__=='__main__':unittest.main()
