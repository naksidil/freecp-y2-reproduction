"""Fixed Y2 confirmation; selected solely from the stage07 development results."""
import hashlib
import json
from pathlib import Path
from protocol7 import CONF_SHA, DEV_SHA

TAU = 0.5
VERSION = '08-y2-confirmation-v1'
CONDITIONS = [dict(id=f'{v}_{m}', expanded=(v=='expanded'), method=m)
              for v in ['original','expanded'] for m in ['baseline','y2','random']]

def scientific_protocol():
    return dict(version=VERSION, conditions=CONDITIONS, tau=TAU,
        development_sha256=DEV_SHA, confirmation_sha256=CONF_SHA,
        selection='Stage07 predeclared grid rule: rescue precision >=0.80 and >=5 true window-class rescues at BOTH vocabularies; maximize pooled true rescues. Selected tau=0.5. No segmentation tuning.',
        evidence='Stage07 run 20261112T223438_764899Z; 200 VOC train development images, never the reserved confirmation300.',
        source='300 held-out VOC2012 train images, disjoint from development200, old train50 and official val1449.',
        hypothesis='Retain classes rejected by RP when the same-window CLS probability >=0.5; test whether this improves segmentation.',
        primary='expanded_y2 minus expanded_baseline: mIoU percentage-point difference on confirmation300.',
        secondary=['original_y2 minus original_baseline', 'y2 minus matched-budget random at each vocabulary', 'random minus baseline at each vocabulary'],
        rule='For ALL foreground queries (including additional ADE queries), retain if S>0.15 OR p>=0.5 BEFORE zeroing; unchanged AP=0.8 follows.',
        probability='float32 softmax of existing window CLS logits over all 26 original background queries and all foreground queries.',
        baseline='Original FreeCP RP=0.15 / AP=0.8, plus identical audit logging. No Y2 rescue.',
        random_control='For every window, count classes Y2 would rescue across ALL foreground queries; sample that many uniformly without replacement among RP-rejected queries. Keep all original RP survivors.',
        random_seed='First 8 SHA256 hex digits of image_id + colon + one-based crop index; same fixed rule at both vocabularies. One random realization only; no seed search.',
        vocabulary='Unchanged stage07 K=21/Q=46 and K=124/Q=149. Original embeddings preserved; frozen ADE exclusions and pinned AP descriptions.',
        evaluation='Full argmax over all output classes, then map indices>20 to VOC background 0. Void255 ignored. mIoU uses aggregated per-class intersections/unions.',
        unknown_extra_labels='No presence ground truth for the added ADE labels. Report rescue counts but NEVER classify those rescues as correct/incorrect.',
        uncertainty='Paired image bootstrap, 5000 draws, seed 51100813. 95% percentile intervals are unadjusted; one primary contrast is predeclared. Random-control interval conditions on one fixed random realization.',
        sensitivity='Leave-one-image-out differences and per-image changed pixel counts; no threshold changes after inspecting confirmation results.',
        timing='Same instrumentation and one excluded warm-up per condition. Pipeline test_step time includes preprocessing/audit transfers, not GPU-only latency. Expanded vocab may change AP work.',
        no_more_tuning=True, no_full_val_automatically=True,
        future='Y1 remains untested future work. PAMR/second-look and other old variants are not rerun.')

def protocol_hash():
    return hashlib.sha256(json.dumps(scientific_protocol(),sort_keys=True).encode()).hexdigest()

def verify_reviewed_evidence(folder):
    folder=Path(folder)
    r=json.loads((folder/'reviewed_stage7_run.json').read_text())
    s=json.loads((folder/'reviewed_stage7_summary.json').read_text())
    if (r['run_id']!='20261112T223438_764899Z' or not r['ok'] or not r['baseline_parity_passed']
        or r['confirmation_evaluated'] or s['confirmation_evaluated'] or s['y2_segmentation_evaluated']
        or s['proposed_common_tau']!=TAU):
        raise ValueError('Reviewed development evidence differs.')
    from analyze7 import common_tau
    if common_tau([x['threshold_presence_curve'] for x in s['results']])!=TAU:
        raise ValueError('Tau does not follow the frozen development rule.')
    return r,s

def validate_manifest(m,cfg):
    if m['protocol_hash']!=protocol_hash() or m['condition'] not in CONDITIONS:
        raise ValueError('Unrecognized confirmation protocol/condition.')
    method=m['condition']['method']; official=m['model_kind']=='official'
    if m['split_role']=='confirmation300':
        if m['split_sha256']!=CONF_SHA or m['n_images']!=300 or official:
            raise ValueError('Invalid confirmation split.')
    elif m['split_role']=='pilot3':
        if m['n_images']!=3 or (official and m['condition']['expanded']) or method!='baseline':
            raise ValueError('Invalid pilot.')
    else: raise ValueError('Only pilot3 and confirmation300 are permitted.')
    if official:
        if cfg.model.type!='FreeCPSegmentation':raise ValueError('Invalid official model.')
    else:
        if cfg.model.type!='Y2FreeCPSegmentation':raise ValueError('Invalid Y2 model.')
        expected=None if method=='baseline' else TAU
        if cfg.model.y2_tau!=expected or cfg.model.rescue_mode!=('random' if method=='random' else 'y2'):
            raise ValueError('Tau or rescue mode differs from the frozen method.')
