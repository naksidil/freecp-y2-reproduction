import json
import io
from contextlib import redirect_stdout
import tempfile
import unittest
from pathlib import Path
import numpy as np
from analyze7 import BinaryRanking,presence_table,common_tau,analyze
from protocol7 import rescue_indices,map_extended_prediction,vocabulary_plan,TAUS,CONDITIONS,protocol_hash,slide_boxes
from run_y2_confirmation import complete,select_run
from stage2_helpers import save_json,digest

class RankingTests(unittest.TestCase):
    def test_perfect_and_reversed(self):
        self.assertEqual(BinaryRanking([0,0,1,1],[0,1,2,3]).compute()['auroc'],1)
        self.assertEqual(BinaryRanking([0,0,1,1],[3,2,1,0]).compute()['auroc'],0)
    def test_ties_are_not_broken_by_order(self):
        a=BinaryRanking([1,0,1,0],[.5]*4).compute()
        self.assertEqual(a['auroc'],.5);self.assertEqual(a['average_precision'],.5)
    def test_weights_equal_explicit_replication(self):
        y=np.array([0,1,0,1]);s=np.array([.1,.1,.5,.9]);w=np.array([1,3,2,1])
        a=BinaryRanking(y,s).compute(w);b=BinaryRanking(np.repeat(y,w),np.repeat(s,w)).compute()
        self.assertAlmostEqual(a['auroc'],b['auroc']);self.assertAlmostEqual(a['average_precision'],b['average_precision'])
    def test_undefined_class_is_explicit(self):
        self.assertIsNone(BinaryRanking([0,0],[1,2]).compute()['auroc'])
        self.assertIsNone(BinaryRanking([1,1],[1,2]).compute()['auroc'])
    def test_confusion_counts(self):
        self.assertEqual({k:v for k,v in presence_table([1,1,0,0],[1,0,1,0]).items() if k in ['tp','fp','fn','tn']},dict(tp=1,fp=1,fn=1,tn=1))

class GateTests(unittest.TestCase):
    def test_or_strict_rp_inclusive_probability(self):
        keep,rescue=rescue_indices([.16,.15,.14,.10],[0,.2,.1,.3],.2)
        self.assertEqual(keep.tolist(),[0,1,3]);self.assertEqual(rescue.tolist(),[1,3])
    def test_random_control_has_same_budget_and_preserves_kept(self):
        s=np.array([.2,.3,.1,.1,.1,.1]);p=np.array([0,0,.8,.9,0,0])
        a,b=rescue_indices(s,p,.5,'random',123);c,d=rescue_indices(s,p,.5,'random',123)
        self.assertEqual(len(b),2);self.assertTrue({0,1}<=set(a));np.testing.assert_array_equal(b,d)
    def test_empty_rescue(self):
        _,r=rescue_indices([.2,.1],[0,0],1);self.assertEqual(len(r),0)
    def test_invalid_probability_rejected(self):
        with self.assertRaises(ValueError):rescue_indices([.1],[2],.2)
    def test_full_argmax_then_map(self):
        score=np.zeros((23,1,2));score[3,0,0]=.8;score[21,0,0]=.8;score[22,0,1]=.9
        # Tie is won by original class 3, not by a premature background aggregation.
        self.assertEqual(map_extended_prediction(score.argmax(0)).tolist(),[[3,0]])

class ProtocolTests(unittest.TestCase):
    def test_vocab_preserves_original_and_excludes_collisions(self):
        bg=['bg'+str(i) for i in range(26)];fg=['voc'+str(i) for i in range(20)]
        names=['person','airplane','bg0','voc0']+['extra'+str(i) for i in range(146)]
        v=vocabulary_plan(', '.join(bg)+'\n'+'\n'.join(fg),'\n'.join(names))
        self.assertEqual(len(v['extra_queries']),146);self.assertEqual(v['expanded_text_queries'],192)
        self.assertEqual(v['background_queries'],bg)
    def test_crop_geometry(self):
        b=slide_boxes(448,672,384,112)
        self.assertEqual(len(b),8);self.assertEqual(b[-1],(288,64,672,448))
    def test_common_tau_requires_each_vocabulary(self):
        curves=[[dict(tau=t,rescue_precision=.9,rescued_true_pairs=10 if t==.1 else 0) for t in TAUS] for _ in range(2)]
        self.assertEqual(common_tau(curves),.1)
        curves[1][TAUS.index(.1)]['rescue_precision']=.1;self.assertIsNone(common_tau(curves))
    def test_resume_hash_and_missing_artifact(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);m=dict(n_images=1,model_kind='diagnostic');save_json(p/'evaluation_report.json',dict(ok=True,manifest=m,real_images_evaluated=1))
            self.assertFalse(complete(p,m))
    def test_distinct_package_creates_distinct_run(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);a,_,r=select_run(root,'abc');b,_,r=select_run(root,'abc')
            self.assertEqual(a,b);self.assertTrue(r)
            c,_,r=select_run(root,'def');self.assertNotEqual(a,c);self.assertFalse(r)

class AnalysisIntegrationTests(unittest.TestCase):
    def test_saved_outputs_produce_matched_diagnostic_only_report(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);rng=np.random.RandomState(3);ids=np.array(['a','b','c','d']);wi=np.repeat(np.arange(4),2)
            counts=(rng.rand(8,20)>.8).astype('int64')*8;score=rng.rand(8,20)*.3;prob=rng.rand(8,20)*.2
            for c in CONDITIONS:
                p=root/'conditions'/c['id'];p.mkdir(parents=True)
                cms=np.stack([np.eye(21,dtype='int64')*10 for _ in ids])
                np.savez_compressed(p/'per_image_confusions.npz',image_ids=ids,confusion_matrices=cms)
                np.savez_compressed(p/'presence_arrays.npz',rp_scores=score,cls_probabilities=prob,cls_cosines=prob,
                    gt_counts=counts,window_image_index=wi,image_gt_counts=np.stack([counts[wi==i].sum(0) for i in range(4)]),
                    image_rp_kept=np.stack([(score[wi==i]>.15).any(0) for i in range(4)]))
                save_json(p/'evaluation_report.json',dict(ok=True,manifest=dict(protocol_hash=protocol_hash(),split_role='development200'),
                    n_output_classes=21,n_text_queries=46,per_image=[dict(pipeline_test_step_seconds=.1,peak_allocated_gpu_gib=.5) for _ in ids]))
            with redirect_stdout(io.StringIO()):r=analyze(root,bootstrap=12)
            self.assertFalse(r['confirmation_evaluated']);self.assertFalse(r['y2_segmentation_evaluated'])
            self.assertEqual(r['vocabulary_delta_mIoU'],0);self.assertEqual(r['vocabulary_delta_paired_bootstrap_95ci'],[0,0])
            self.assertTrue((root/'SONUC_OZETI.txt').is_file())

if __name__=='__main__':unittest.main()
