"""Matched-image segmentation comparisons; never choose a threshold here."""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image
from metrics import summarize_confusion
from protocol8 import CONDITIONS,protocol_hash,TAU
from stage2_helpers import digest,save_json

COMPARISONS=[('expanded_y2','expanded_baseline'),('original_y2','original_baseline'),
             ('original_y2','original_random'),('expanded_y2','expanded_random'),
             ('original_random','original_baseline'),('expanded_random','expanded_baseline')]

def miou(cm):
    """mIoU from total confusion, in percent, with absent classes excluded."""
    cm=np.asarray(cm,dtype=np.float64)
    inter=np.diagonal(cm,axis1=-2,axis2=-1)
    union=cm.sum(-2)+cm.sum(-1)-inter
    iou=np.divide(inter,union,out=np.full_like(inter,np.nan),where=union>0)
    return np.nanmean(iou,axis=-1)*100

def paired_comparison(a,b,draws=5000):
    a=np.asarray(a);b=np.asarray(b)
    if a.shape!=b.shape or a.ndim!=3 or len(a)<2 or not np.array_equal(a.sum(2),b.sum(2)):
        raise ValueError('Unpaired predictions/ground truth.')
    rng=np.random.RandomState(51100813);ds=[];n=len(a);total_a=a.sum(0);total_b=b.sum(0)
    for _ in range(draws):
        ix=rng.randint(n,size=n);ds.append(float(miou(a[ix].sum(0))-miou(b[ix].sum(0))))
    loo=miou(total_a[None]-a)-miou(total_b[None]-b)
    delta=float(miou(total_a)-miou(total_b));j=int(np.argmax(np.abs(loo-delta)))
    return dict(delta_mIoU=delta,paired_bootstrap_95ci=np.percentile(ds,[2.5,97.5]).tolist(),
        bootstrap_draws=draws,leave_one_out_min=float(loo.min()),leave_one_out_max=float(loo.max()),
        most_influential_image_index=j,delta_without_most_influential_image=float(loo[j]))

def rescue_summary(rows):
    out=dict(rescued_window_class_pairs=0,voc_true_pairs=0,voc_false_pairs=0,
             extra_pairs_presence_unknown=0,images_with_rescue=0,rescued_pairs_surviving_ap=0,
             voc_true_pairs_surviving_ap=0,voc_false_pairs_surviving_ap=0,
             extra_pairs_surviving_ap_presence_unknown=0)
    for r in rows:
        touched=False
        for w in r['rp_audit']:
            ap=set(w['ap_kept_class_ids'])
            for c in w['rescued_class_ids']:
                out['rescued_window_class_pairs']+=1;touched=True
                survival=c in ap
                out['rescued_pairs_surviving_ap']+=int(survival)
                if c>20:
                    out['extra_pairs_presence_unknown']+=1
                    out['extra_pairs_surviving_ap_presence_unknown']+=int(survival)
                elif w['gt_valid_pixels']>0:
                    key='voc_true_pairs' if w['gt_voc_counts'][c-1]>0 else 'voc_false_pairs'
                    out[key]+=1;out[key+'_surviving_ap']+=int(survival)
        out['images_with_rescue']+=int(touched)
    denom=out['voc_true_pairs']+out['voc_false_pairs']
    out['voc_rescue_precision']=out['voc_true_pairs']/denom if denom else None
    out['note']='Overlapping windows are not independent; presence is unknown for added labels and fully void crops.'
    return out

def verify_random_budgets(yrows,rrows):
    if [r['image_id'] for r in yrows]!=[r['image_id'] for r in rrows]:raise ValueError('Unmatched random-control images.')
    for y,r in zip(yrows,rrows):
        if len(y['rp_audit'])!=len(r['rp_audit']):raise ValueError('Different window counts.')
        for yw,rw in zip(y['rp_audit'],r['rp_audit']):
            if (yw['box']!=rw['box'] or yw['original_rp_kept_class_ids']!=rw['original_rp_kept_class_ids']
                or len(yw['rescued_class_ids'])!=len(rw['rescued_class_ids'])):
                raise ValueError('Random control is not matched to the Y2 per-window rescue budget.')

def analyze(folder,draws=5000):
    folder=Path(folder);arrays={};rows={};stats=[];ids=None;gtref=None;checksums=None
    for c in CONDITIONS:
        name=c['id'];p=folder/'conditions'/name
        report=json.loads((p/'evaluation_report.json').read_text())
        if (not report['ok'] or report['manifest']['protocol_hash']!=protocol_hash()
            or report['manifest']['condition']!=c or report['manifest']['split_role']!='confirmation300'
            or report['real_images_evaluated']!=300):raise ValueError('Incomplete confirmation condition.')
        hashes=json.loads((p/'result_files_sha256.json').read_text())
        if any(digest(p/n)!=h for n,h in hashes.items()):raise ValueError('Changed result file.')
        with np.load(p/'per_image_confusions.npz') as a:
            image_ids=a['image_ids'];cms=a['confusion_matrices'];arrays[name]=cms
        rows[name]=[json.loads(line) for line in (p/'per_image.jsonl').read_text().splitlines()]
        current=[(r['image_id'],r['image_sha256'],r['gt_sha256']) for r in rows[name]]
        if len(cms)!=300 or [x[0] for x in current]!=image_ids.tolist():raise ValueError('Result IDs differ.')
        if ids is None:ids=image_ids;gtref=cms.sum(2);checksums=current
        elif not np.array_equal(ids,image_ids) or not np.array_equal(gtref,cms.sum(2)) or checksums!=current:
            raise ValueError('Images/ground truth differ between conditions.')
        metric=summarize_confusion(cms.sum(0))
        if abs(metric['mIoU']-report['independent_metrics_percent']['mIoU'])>1e-8:raise ValueError('Metric mismatch.')
        times=np.array([r['pipeline_test_step_seconds'] for r in rows[name]])
        stats.append(dict(condition=c,n_images=len(cms),mIoU=metric['mIoU'],metrics=metric,
            mean_pipeline_seconds=float(times.mean()),median_pipeline_seconds=float(np.median(times)),
            p95_pipeline_seconds=float(np.percentile(times,95)),peak_allocated_gpu_gib=max(r['peak_allocated_gpu_gib'] for r in rows[name]),
            wall_seconds_including_load=report['wall_seconds_including_load'],rescues=rescue_summary(rows[name]),
            extra_label_pixels=sum(r['extra_label_pixels'] for r in rows[name]),
            extra_label_pixels_on_voc_foreground=sum(r['extra_label_pixels_on_voc_foreground'] for r in rows[name])))
    for v in ['original','expanded']:verify_random_budgets(rows[v+'_y2'],rows[v+'_random'])
    comparisons=[]
    for method,control in COMPARISONS:
        d=paired_comparison(arrays[method],arrays[control],draws)
        j=d.pop('most_influential_image_index');d['most_influential_image']=str(ids[j])
        changed=[];raw_changed=[]
        for image_id in ids:
            base=folder/'conditions'/control/'figures';new=folder/'conditions'/method/'figures'
            a=np.array(Image.open(base/(str(image_id)+'_prediction.png')));b=np.array(Image.open(new/(str(image_id)+'_prediction.png')))
            ar=np.array(Image.open(base/(str(image_id)+'_raw.png')));br=np.array(Image.open(new/(str(image_id)+'_raw.png')))
            if a.shape!=b.shape or ar.shape!=br.shape:raise ValueError('Prediction size mismatch.')
            changed.append(int((a!=b).sum()));raw_changed.append(int((ar!=br).sum()))
        d.update(method=method,control=control,primary=(method,control)==COMPARISONS[0],
            changed_images=int(np.count_nonzero(changed)),changed_pixels=int(sum(changed)),
            changed_raw_images=int(np.count_nonzero(raw_changed)),changed_raw_pixels=int(sum(raw_changed)))
        comparisons.append(d)
    result=dict(ok=True,protocol_hash=protocol_hash(),tau=TAU,split='confirmation300',
        confirmation_evaluated=True,y2_segmentation_evaluated=True,random_budget_verified=True,
        results=stats,comparisons=comparisons,
        caveat='Intervals are unadjusted paired image bootstrap. Random-control intervals condition on one fixed random realization. No threshold tuning or automatic full-VOC evaluation follows.')
    save_json(folder/'y2_confirmation_summary.json',result)
    lines=['ASAMA 08 — SABIT Y2 DOGRULAMASI','300 ayrilmis train goruntusu; tau=0.5; 6/6 kosul.','']
    for s in stats:lines.append(f"{s['condition']['id']}: mIoU={s['mIoU']:.4f}; ortalama sure={s['mean_pipeline_seconds']:.3f} sn/goruntu")
    lines.append('')
    for c in comparisons:
        lo,hi=c['paired_bootstrap_95ci']
        lines.append(f"{c['method']} - {c['control']}: {c['delta_mIoU']:+.4f} puan; %95 GA [{lo:+.4f}, {hi:+.4f}]; degisen goruntu={c['changed_images']}")
    lines+=['','Rastgele kontrol her pencerede Y2 ile ayni sayida sinifi geri aldi.',
        'Sonuc ZIP dosyasini paylas. Bu sonuclara gore esik degistirilmeyecek; 1449 val otomatik baslamaz.']
    (folder/'SONUC_OZETI.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines),flush=True);return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);a=p.parse_args();analyze(a.run_dir)
