# 08 — FreeCP + Y2, sabit ayarlarla doğrulama

Bu paket, 07'nin tamamlanan tanı sonucuna dayanır. Y2 eşiği **0,50** olarak
sabitlenmiştir. İki sınıf listesinde, daha önce ayrılmış aynı 300 VOC train
görüntüsünde altı koşul çalıştırılır. Geliştirme görüntüleri yeniden ayarlama
için kullanılmaz; eşik araması ve otomatik 1449 val çalıştırması yapılmaz.

## Colab'da çalıştırma

1. **07'nin çalıştığı aynı Colab oturumunda T4 ile devam et.**
2. ZIP'i bilgisayarında aç; `COLAB_BASLAT.txt` içindeki kodu kopyala.
3. Mevcut defterin en altına yeni bir kod hücresi ekle ve kodu yapıştır.
4. Hücreyi çalıştır; dosya seçicide **08_FreeCP_Y2_Sabit_Dogrulama.zip** seç.
5. Sonunda `Tamamlanan kosul: 6 / 6` ve `Dogrulama tamamlandi.` beklenir.
6. İndirilen `freecp_y2_confirmation_...zip` dosyasını konuşmaya yükle.

**02–07'yi yeniden çalıştırma.** Oturum tamamen sıfırlandıysa önce yalnızca
02 kurulumu gerekir. Paket, incelenmiş 07 sonuç özetini içerir; eski 07
çalışmasının Colab diskinde bulunmasına bağımlı değildir. Başlatıcı ana
Colab ortamında `import torch` yapmaz; mevcut Python 3.10 ortamını kullanır.
Paket herhangi bir kütüphane kurmaz, model sürümünü veya upstream dosyalarını değiştirmez.

Aynı oturumdaki kesinti sonrası aynı hücreyi aynı paketle yeniden çalıştırmak,
hash'i doğrulanmış tamamlanmış koşulları atlar. Yarım kalan koşul yeniden
başlar; yarım çıktı ayrı klasörde saklanır. Colab sanal makinesi tamamen
silinirse çalışma dosyaları da silinebilir; indirilmiş sonuç ZIP'lerini sakla.
Hata olursa sonucu da ZIP'e koyar. Hata ZIP'ini paylaş; eşiklerle oynamak gerekmez.

## Deney

| Sınıf listesi | Yöntemler |
|---|---|
| K=21, Q=46 | Orijinal FreeCP; FreeCP + Y2; rastgele geri alma |
| K=124, Q=149 | Orijinal FreeCP; FreeCP + Y2; rastgele geri alma |

K çıktı sınıfı sayısıdır; Q metin sorgusu sayısıdır. K arka planı tek sınıf
sayar; Q mevcut 26 arka plan sorgusunu ayrı sayar. 103 ek ADE kavramı,
07'de önceden tanımlanan aynı dışlamalarla kullanılır. ADE görüntüsü indirilmez.

**Y2:** Aynı pencerede RP'nin attığı bir sınıfın mevcut CLS softmax skoru
en az 0,50 ise refinement haritasını koru ve sınıfı AP'ye giren listeye ekle.
RP=0,15 ve AP=0,8 değişmez. Softmax bütün arka plan ve ön plan sorgularını
kapsar. Kural ek ADE sınıfları dahil bütün ön plan sorgularına uygulanır.
GT modelin kararında kullanılmaz; varlık ölçümleri tahminden sonra eklenir.

**Kontrol:** Her pencerede Y2'nin geri alacağı sınıf sayısını hesapla;
RP'nin attıkları arasından o kadar sınıfı eşit olasılıkla, tekrarsız seç.
Görüntü kimliği ve pencere indeksinden üretilen sabit tohum kullanılır.
Analiz her pencerenin geri alma sayısının iki yöntem arasında eşit olduğunu
doğrular. Bu tek rastgele gerçekleşmedir; farklı tohumlar arasında genelleme
iddiası yapılmaz.

Ek ADE etiketleri VOC'ta bilinmediğinden geri alınmaları doğru/yanlış diye
etiketlenmez. Tüm sınıflar üzerinde argmax alındıktan sonra 20'den büyük
etiketler VOC arka planına eşlenir. Ham ve eşlenmiş maskeler birlikte saklanır.

## Eşik neden 0,50?

07'den önce tanımlanan ortak eşik kuralı: her iki sınıf listesinde de geri
alma precision en az %80 ve en az beş doğru pencere-sınıf geri alımı; uygun
eşikler arasından toplam doğru geri alımı en yüksek olanı seç. Ortak aday
0,50 çıktı. Seçim mIoU'ya göre yapılmadı.

K=21: 49 doğru, 7 yanlış VOC pencere-sınıf geri alımı (%87,5).
K=124: 29 doğru, 6 yanlış (%82,9). Bunlar 49 ve 29 ayrı görüntü değildir.
Görüntü genelinde tamamen kaçırılmış doğru sınıf geri alımı her listede 4'tür.
Ek listede ayrıca 25 ADE pencere-sınıf geri alımının varlık etiketi bilinmiyor.
Bu sonuçlar segmentasyon kazancını kanıtlamaz. Birleşik genel AUROC'ta
belirgin bir artış görülmedi. Bu nedenle tek bir kontrollü Y2 deneyi yapılır.

## Ölçümler ve doğrulama

- Önce mevcut ortamın gerçek CUDA işlemleri, yerel birim testleri, model
  mantığı testleri ve 3 pilot görüntüde orijinal kodla piksel eşliği doğrulanır.
- Altı koşul da aynı 300 görüntüyü aynı sırada kullanır. Bu görüntüler train'den
  gelir; eski train50 ve development200 ile çakışmaz. Val1449'dan gelmezler.
- Birincil karşılaştırma önceden **geniş listede Y2 eksi baseline mIoU** olarak
  sabitlenmiştir. Diğer karşılaştırmalar ikincildir.
- mIoU, görüntü IoU'larının ortalamasıyla değil, toplam sınıf kesişim/birleşimiyle
  hesaplanır. MMSeg sonucu bağımsız confusion-matrix hesabıyla karşılaştırılır.
- 5000 eşli görüntü bootstrap örneklemesiyle %95 aralık; görüntü çıkarma analizi,
  değişen görüntü/piksel sayıları ve AP sonrası geri alınan sınıflar raporlanır.
- Güven aralıkları çoklu karşılaştırmaya göre düzeltilmemiştir. Rastgele kontrol
  aralığı tek sabit rastgele gerçekleşmeye koşulludur.
- Süre, bir ısınma turundan sonra görüntü başına test_step süresidir; ön işleme
  ve kayıt aktarımını içerir. GPU'ya özgü çekirdek süresi değildir. Bellek ölçülür.

`protocol.json`, kaynak kopyaları, paket fingerprint'i, ortam sürümleri ve
veri hash'leri sonuç ZIP'inde bulunur. 300 sonucu görüldükten sonra eşik
değiştirilmez; değişirse yeni çalışma keşif amaçlı olarak etiketlenmelidir.

## Sınırlar

Bu paket hazırlanırken GPU çıkarımı burada çalıştırılmadı. CPU'da birim ve
altı koşullu sentetik analiz testleri yapıldı; gerçek CUDA/model kontrolleri
paket tarafından Colab'da çalıştırılacak. Başarılı sonuç iddiası ancak sonuç
ZIP'i incelendikten sonra yapılabilir. Y1 henüz denenmedi; gelecek çalışmadır.

Orijinal çalışma: Training-Free Class Purification for Open-Vocabulary
Semantic Segmentation. Upstream: https://github.com/chenqi1126/FreeCP
Sabit commit: 6946aa7999ec5d57d1fe91968ba1ae35a1e53295.
