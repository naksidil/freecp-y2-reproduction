# 09 — Sabit Y2 ile son VOC benchmark karşılaştırması

**Aynı T4 Colab oturumunda doğrudan 09'u çalıştır. 02–08'i yeniden çalıştırma.**
Oturum sıfırlandıysa yalnızca 02 kurulumu gerekir; incelenmiş 08 sonuç özeti
ve eski baseline referansı bu paketin içindedir.

1. ZIP'i bilgisayarında aç ve `COLAB_BASLAT.txt` içindeki kodu kopyala.
2. 08'i çalıştırdığın defterin en altına yeni bir kod hücresi ekleyip yapıştır.
3. Çalıştırınca **09_FreeCP_Y2_Final_Benchmark.zip** dosyasını seç.
4. Sonunda `Tamamlanan kosul: 2 / 2` ve `Benchmark tamamlandi.` beklenir.
5. İndirilen `freecp_y2_benchmark_...zip` dosyasını konuşmaya yükle.

Başlatıcı ana Colab ortamında PyTorch kullanmaz; mevcut Python 3.10 ortamını
çalıştırır. Kütüphane kurulmaz, upstream dosyaları ve eşikler değiştirilmez.
Hata olursa kayıtlar yine sonuç ZIP'ine konur. Aynı oturumda aynı paketle tekrar
çalıştırma, hash'i doğrulanmış tamamlanmış koşulları atlar; yarım koşul baştan
başlar ve önceki yarım çıktıyı saklar. Sanal makine silinirse dosyalar kaybolabilir.

## Ne çalıştırılıyor?

Resmi VOC2012 **val1449** görüntülerinin tamamında yalnızca **K=21 / Q=46**:

- Orijinal FreeCP: RP=0,15; AP=0,8.
- Aynı FreeCP + Y2: aynı pencerede CLS softmax skoru en az **0,50** olan
  RP-reddedilmiş sınıfın haritasını koru; değişmeyen AP adımına dahil et.

Bu eşik 07 geliştirme verisinde seçildi; 08 sonuçlarından sonra değiştirilmedi.
Ek sınıf listesi, rastgele kontrol, PAMR, ikinci bakış ve eşik araması çalışmaz.
300 doğrulama görüntüsü yeniden kullanılmaz. İki yöntem aynı val görüntülerini
aynı sırada kullanır; GT tahminden sonra analiz için okunur.

**Bu 1449 görüntülük küme daha önce RP ve arka plan deneylerinde görüldü.**
Dolayısıyla bu çalışma yeni ve dokunulmamış bir doğrulama olarak sunulamaz.
Sabit yöntemin ek benchmark sonucudur. 08'deki 300 görüntülük doğrulama sonucu
ve belirsizliği raporda ayrıca korunur; bu sonuç onun yerine geçirilmez.

## 08'in incelenmiş sonucu

| 300 görüntü | Orijinal liste | Geniş liste |
|---|---:|---:|
| FreeCP mIoU | 63,04677 | 59,82753 |
| FreeCP + Y2 mIoU | 63,20448 | 60,11691 |
| Rastgele geri alma mIoU | 62,95823 | 59,76441 |
| Y2 eksi FreeCP | +0,15770 | +0,28938 |
| %95 eşli bootstrap aralığı | [−0,11215; +0,66284] | [−0,11333; +0,84380] |

Altı koşulun dosya hash'leri ve 300 görüntünün eşleşmesi doğrulandı. Kaynaklar
gönderilen 08 paketiyle aynı. Geliştirme200 ve doğrulama300 arasında çakışma yok.
31 birim/analiz testi, 7 model testi, CUDA kontrolleri ve 3 görüntüde orijinal
kodla piksel eşliği başarılı. mIoU, bootstrap ve görüntü çıkarma hesapları
kayıtlardan yeniden hesaplanıp doğrulandı.

Önemli sınır: geniş listedeki +0,28938, `2008_005874` saksı bitkisi görüntüsü
çıkarılınca **−0,00471** olur. Orijinal listedeki +0,15770,
`2008_005342` yemek masası görüntüsü çıkarılınca **+0,01899** olur. Y2 her
listede 16/300 görüntünün VOC maskesini değiştirir. Kazanç küçük ve örneklere
duyarlıdır; üstünlük güven aralıklarıyla gösterilmiş değildir.

Y2'nin orijinal listede geri aldığı 56 pencere-sınıf kararının 48'i doğru,
8'i yanlıştır (%85,71); eşit sayıdaki rastgele kontrolde 3'ü doğrudur. Geniş
listede 34 doğru, 5 yanlış VOC kararı ve varlık etiketi bilinmeyen 25 ek sınıf
kararı vardır. Sınıf varlığının doğru tahmini, bölgenin doğru segmentasyonu
anlamına gelmez. Birden fazla pencere aynı görüntüyü/nesneyi sayabilir.

Y2'nin tek çalıştırmadaki süresinin düşük çıkması hızlanma kanıtı değildir;
karşılaştırmalar sıralı ve zamanlama değişken olabilir. Rastgele kontrol de
tek sabit rastgele gerçekleşmedir; bütün rastgele seçimler için iddia kurulmaz.

## 09'un kontrolleri ve çıktıları

- CUDA ve model kontrolleri; 3 pilotta orijinal uygulamayla piksel eşliği.
- Her görüntünün tahmini, confusion matrisi, RP/CLS ve geri alma/AP kayıtları.
- mIoU toplam sınıf kesişim/birleşimlerinden hesaplanır; görüntü mIoU'larının
  ortalaması kullanılmaz. MMSeg sonucu bağımsız metrikle doğrulanır.
- 5000 eşli görüntü bootstrap örneklemesiyle betimsel %95 aralık; görüntü
  çıkarma analizi; değişen piksel ve görüntü sayıları; sınıf bazında sonuçlar.
- Isınma sonrası pipeline süresi ve tepe GPU belleği. Süre ön işleme/kayıt
  aktarımını içerir; saf GPU çekirdek süresi değildir.
- Tekrarlanan baseline, arşivdeki **65,76325321** sonucunun görüntü başına
  confusion matrisleriyle karşılaştırılır. GT/ID farkı varsa analiz durur;
  tahmin farkları varsa bunlar raporlanır ve saklanmaz.

Paket hazırlanırken 15 CPU testi ve iki koşullu 1449 kayıt içeren sentetik
analiz testi geçti (toplam 15 testin içinde). Burada GPU çıkarımı yapılmadı;
gerçek GPU/model testleri Colab'da gerçekleştirilecektir. Protokol, kaynak
kopyaları, ortam bilgisi ve hash'ler sonuç arşivinde bulunur.

Y1 henüz uygulanmış veya test edilmiş değildir; gelecek çalışma olarak kalır.

Upstream: https://github.com/chenqi1126/FreeCP
Sabit commit: 6946aa7999ec5d57d1fe91968ba1ae35a1e53295.
