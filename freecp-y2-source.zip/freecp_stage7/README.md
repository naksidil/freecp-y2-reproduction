# 07 — FreeCP Y2: iki vokabülerde tanı

Bu paket, bir sonraki yöntem adayı olarak yalnızca Y2'yi inceler. Y1 gelecek çalışmadır.
Y2 henüz gerçek görüntülerde uygulanmaz: iki farklı vokabülerle orijinal FreeCP
çalıştırılır ve zaten hesaplanan pencere CLS skorları kaydedilir. Kayıtlardan Y2
kuralının sınıf varlığı bakımından kurtarabileceği durumlar hesaplanır. Bunlar
Y2 segmentasyon sonuçları değildir; AP ve piksel rekabeti daha sonra ayrıca ölçülür.

## Çalıştırma

1. Stage 02 kurulumu tamamlanmış aynı Colab sanal makinesini, T4 ile kullan.
2. `COLAB_BASLAT.txt` içindeki tek hücreyi not defterinin en altına ekle.
3. Bu **07** ZIP dosyasını seç; başka ZIP veya sonuç ZIP'i seçme.
4. İşlem bitince indirilen `freecp_y2_diagnostics_....zip` dosyasını paylaş.

03, 04, 05 ve 06'yı yeniden çalıştırmak gerekmez. Oturum sıfırlandıysa önce 02
kurulumunu tamamla. Bu paket ortamı kurmaz/değiştirmez; eşikleri hata gidermek için
değiştirmez. Aynı kod ve aynı ortamla tekrar başlatıldığında hash'leri doğrulanmış
tamamlanmış koşullar atlanır. Yarım kalan koşul baştan çalışır; eski kayıt korunur.
Başarısızlıkta da hata çıktıları ZIP'e yazılır. Uzun süre sessizlik olursa hücreyi
tekrar tekrar başlatma; önce mevcut çıktıyı kontrol et.

## Sabit deney tasarımı

- Aynı `VOC2012 train` içindeki 200 geliştirme görüntüsü (06 ile aynı IDs).
- Önceki 50 görüntü ve ayrılmış 300 görüntüyle çakışma yoktur. 300 görüntünün
  yalnızca ID listesi korunur; görüntüler/maskeler açılmaz ve inference yapılmaz.
- Kıyas: orijinal FreeCP + orijinal vokabüler; orijinal FreeCP + geniş vokabüler.
- Orijinal: 20 ön plan + 1 çıktı arka planı (**K=21**); 26 arka plan metin sorgusu
  + 20 ön plan sorgusu (**Q=46**).
- Geniş: sabit ADE150 adlarından mevcut sorguların birebir kopyaları ve önceden
  listelenen VOC örtüşmeleri çıkarılır; **103** yeni sorgu kalır. **K=124, Q=149**.
  Böylece yaklaşık 170 diye yuvarlamak yerine gerçek boyutları bildiriyoruz.
- 47 dışlanan ad ve gerekçesi `vocabulary_manifest.json` içindedir. Filtre
  görüntülere veya sonuçlara bakılarak oluşturulmamıştır. Arka plan sorgularının
  tam kopyaları da çıkarılır; tekilleştirme ve semantik örtüşme listesi farklıdır.
- ADE görüntü/veri seti indirilmez. Yeni adların şablonları ve AP için Vicuna
  açıklamaları sabit FreeCP deposundan alınır. Yeni LLM/API çağrısı yoktur.
- Orijinal 46 metin embedding'i aynen korunur. RP=0.15 ve AP=0.8 iki koşulda da
  aynıdır. PAMR, önceki seçici ikinci bakış, Y1 ve Y3 bu pakette kullanılmaz.

## Y2 kuralı (uygulaması hazır, bu turda kapalı)

Aynı pencere içinde `S > 0.15 OR p >= tau`. `p`, zaten hesaplanan normal CLIP
CLS skorunun **arka plan dahil bütün metin sorguları üzerindeki float32 softmax**
değeridir. Karar harita sıfırlanmadan önce alınır; tutulan sınıfların birleşimi
değişmemiş AP'ye gider. Başka pencereden kanıt taşınmaz. Bu tasarım eski ikinci
bakışın arka-plan-piksellerini koruma kısıtını taşımaz; AP ve piksel çıktıları
değişebileceğinden yalnızca varlık kazancıyla segmentasyon başarısı iddia edilemez.

`y2_segmentor.py` opsiyonel kurtarma ve aynı sayıda rastgele kurtarma kodunu içerir.
07'nin çalıştırıcısı `y2_tau=None` dışında bir değerle değerlendirmeyi reddeder.
Kurtarma yapılacak final paket, tanı incelendikten sonra ayrı sabitlenecektir.

## Kaydedilenler ve değerlendirme

- Her pencere için RP skoru S, CLS softmax p, ham kosinüs, RP ve AP sınıf listeleri.
- Pencerenin orijinal 20 sınıf için gerçek piksel sayıları: GT, inference bittikten
  sonra model giriş boyutuna `torch nearest` ile ölçeklenir. 255 void sayılmaz.
  Tamamen void olan pencereler varlık analizine girmez; yok etiketi verilmez.
- Görüntü başına 21x21 confusion matrix, orijinal ve geniş etiketli tahmin maskeleri.
- Geniş çıktıda önce bütün sınıflarla argmax yapılır, sonra 20'den büyük etiketler
  VOC arka planına eşlenir. Erken arka plan birleştirmesi yapılmaz (eşit skorlarda
  sonuç değiştirebilir). Ek etiketlerin ön plan üstüne düştüğü piksel sayısı saklanır.
- Yeni ADE kavramlarının VOC görüntülerinde bulunmadığını BİLMİYORUZ. Varlık
  precision/recall/AUROC/AP yalnızca orijinal 20 etiketli sınıf için hesaplanır.
  Geniş-vokabüler mIoU, açıkça tanımlanan VOC eşlemesiyle bir stres testidir;
  ADE başarısı veya genel açık-dünya tanıma doğruluğu değildir.
- Pencere düzeyi mikro AUROC/AP: S, p, kosinüs ve önceden sabitlenmiş
  `max(S/0.15, p/0.05)` sıralaması. Sonuncusu keşif amaçlı OR skorudur;
  birleşim formülü/eşiği seçilmiş veya doğrulanmış sayılmaz.
- Görüntü düzeyinde pencere maksimumlarından sınıf bazlı ve makro AP/AUROC.
- Y2'nin gerçek hedefi için ayrıca yalnızca RP'nin elediği pencere-sınıf
  çiftlerinde AUROC/AP. Kolay, zaten tutulan sınıflar bu tanıyı şişiremez.
- Güven aralıkları: aynı görüntülerin 1.000 paired-bootstrap örneklemi;
  görüntünün bütün örtüşen pencereleri birlikte yeniden örneklenir.
- Sınıf düzeyinde kaçırılan benzersiz piksel payı ayrı raporlanır. Örtüşen
  pencerelerdeki piksel toplamını benzersiz görüntü alanı diye sunmayın.
- Süre, ön işleme ve kayıt üretimi dahil test_step süresidir; saf GPU süresi değildir.

## Tau önerisi ve sonraki karar

Sabit grid: 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10, 0.20, 0.50, 1.0.
Ortak eşik adayı için HER İKİ vokabülerde kurtarma precision >=0.80 ve en az
5 gerçek kurtarılan pencere-sınıf çifti şartı aranır. Uyanlar arasında toplam
gerçek kurtarması en yüksek eşik seçilir; eşitlikte yüksek eşik tercih edilir.
Bu 0.80/5 sınırları bu çalışma için seçilmiş mühendislik tercihleridir; literatürce
kanıtlanmış eşikler değildir. mIoU seçime girmez. Hiçbir eşik uymuyorsa `None`
yazılır; bu yeni bir yöntemin olanaksız olduğunu kanıtlamaz.

Tanı sonuçlarını gördükten sonra sınıf sayıları, precision/recall ve belirsizlik
birlikte incelenecek. Evrensel bir `AUROC +0.02` geçme/kalma kuralı yoktur.
200 görüntüdeki öneri keşif amaçlıdır. 300 doğrulama görüntüsünden önce yöntem,
tek ortak tau, kıyaslar, rastgele kontrol seed'i ve başarı ölçütleri yazılı olarak
sabitlenecek. Bu paket git commit'i oluşturmaz; protokol ve dosya hash'lerini kaydeder.

## Rapora eklenecek gelecek çalışma

“Gelecek çalışmalarda, benzer veya eşanlamlı etiketlerin olasılık kütlesini
paylaşmasının etkisini azaltmak amacıyla grup düzeyinde sınıf arındırma (Y1)
incelenebilir. Grup oluşturma hataları, grup büyüklüğü yanlılığı ve aynı görüntüde
birlikte bulunan sınıfların yanlış birleştirilmesi ayrıca değerlendirilmelidir.
Bu yaklaşım mevcut çalışmada uygulanmamış ve deneysel olarak doğrulanmamıştır.”

## Kontroller ve sınırlar

Önce yerel birim testleri ve Colab model testleri; ardından 3 eski pilot görüntüde
orijinal kod ile kayıt eklenmiş kodun piksel eşliği; ardından geniş vokabülerde
3 görüntülük smoke test. Bunlardan biri geçmezse 200 görüntülük tur başlamaz.
Bu paket hazırlanırken gerçek T4/CLIP inference çalıştırılmadı; bu kontroller
Colab'da zorunludur. Test başarısı, Y2'nin bilimsel olarak başarılı olduğu anlamına gelmez.
