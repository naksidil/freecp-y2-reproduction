"""Window-level presence analysis; all uncertainty resamples whole images."""
import argparse
import json
from pathlib import Path
import numpy as np
from protocol7 import CONDITIONS,TAUS,protocol_hash
from metrics import summarize_confusion
from stage2_helpers import save_json

class BinaryRanking:
    """Grouped-threshold AUROC/AP, handling ties without arbitrary ordering."""
    def __init__(self,y,score):
        self.y=np.asarray(y,dtype=bool).reshape(-1)
        score=np.asarray(score,dtype=float).reshape(-1)
        if len(score)!=len(self.y) or not np.isfinite(score).all():raise ValueError('Invalid binary ranking data.')
        _,ascending=np.unique(score,return_inverse=True)
        self.group=(ascending.max()-ascending) if len(ascending) else ascending
        self.n=int(ascending.max()+1) if len(ascending) else 0

    def compute(self,weights=None):
        w=np.ones(len(self.y)) if weights is None else np.asarray(weights,dtype=float)
        if w.shape!=self.y.shape or np.any(w<0):raise ValueError('Invalid weights.')
        tp=np.cumsum(np.bincount(self.group,weights=w*self.y,minlength=self.n))
        fp=np.cumsum(np.bincount(self.group,weights=w*(~self.y),minlength=self.n))
        pos=float(tp[-1]) if len(tp) else 0.;neg=float(fp[-1]) if len(fp) else 0.
        if pos==0:return dict(auroc=None,average_precision=None,positives=0.,negatives=neg)
        recall=tp/pos;precision=np.divide(tp,tp+fp,out=np.zeros_like(tp),where=tp+fp>0)
        ap=float(np.sum(np.diff(np.r_[0.,recall])*precision))
        auc=float(np.sum(np.diff(np.r_[0.,fp/neg])*(np.r_[0.,recall][1:]+np.r_[0.,recall][:-1])/2)) if neg else None
        return dict(auroc=auc,average_precision=ap,positives=pos,negatives=neg)

def presence_table(y,keep):
    y=np.asarray(y,dtype=bool);k=np.asarray(keep,dtype=bool)
    tp=int((y&k).sum());fp=int((~y&k).sum());fn=int((y&~k).sum());tn=int((~y&~k).sum())
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else None,
                recall=tp/(tp+fn) if tp+fn else None,false_positive_rate=fp/(fp+tn) if fp+tn else None)

def common_tau(curves):
    candidates=[]
    for tau in TAUS:
        rows=[next(x for x in curve if x['tau']==tau) for curve in curves]
        if all(r['rescue_precision'] is not None and r['rescue_precision']>=.8 and r['rescued_true_pairs']>=5 for r in rows):
            candidates.append((sum(r['rescued_true_pairs'] for r in rows),tau))
    if not candidates:return None
    return max(candidates)[1]

def analyze(folder,bootstrap=1000):
    folder=Path(folder);summaries=[];arrays={};curves=[];ids_reference=None;gt_reference=None
    for cond in CONDITIONS:
        path=folder/'conditions'/cond['id'];r=json.loads((path/'evaluation_report.json').read_text())
        if not r['ok'] or r['manifest']['protocol_hash']!=protocol_hash() or r['manifest']['split_role']!='development200':
            raise ValueError('Not a completed stage07 development condition.')
        a=np.load(path/'presence_arrays.npz');cm=np.load(path/'per_image_confusions.npz')
        ids=cm['image_ids'];cms=cm['confusion_matrices'];arrays[cond['id']]=cms
        if ids_reference is None:ids_reference=ids;gt_reference=cms.sum(2)
        elif not np.array_equal(ids,ids_reference) or not np.array_equal(cms.sum(2),gt_reference):raise ValueError('Unmatched images/GT.')
        score=a['rp_scores'];prob=a['cls_probabilities'];cos=a['cls_cosines'];gt=a['gt_counts']>0
        wi=a['window_image_index'];totalgt=a['image_gt_counts'];imagekeep=a['image_rp_kept']
        if (score.shape!=prob.shape or score.shape!=cos.shape or score.shape!=gt.shape or score.shape[1]!=20
            or wi.shape!=(len(score),) or np.any(wi<0) or np.any(wi>=len(ids))):raise ValueError('Invalid presence dimensions.')
        all_scores=dict(rp=score,cls_probability=prob,cls_cosine=cos,or_fixed_tau_0p05=np.maximum(score/.15,prob/.05))
        ranks={k:BinaryRanking(gt,s) for k,s in all_scores.items()}
        stats={k:v.compute() for k,v in ranks.items()}
        rejected=score<=.15
        rejected_stats={k:BinaryRanking(gt[rejected],s[rejected]).compute() for k,s in all_scores.items()}
        pair_image=np.repeat(wi,20);rng=np.random.RandomState(511007);draws={k:[] for k in ranks if k!='rp'}
        for _ in range(bootstrap):
            multiplicities=rng.multinomial(len(ids),np.ones(len(ids))/len(ids));weights=multiplicities[pair_image]
            base=ranks['rp'].compute(weights)['auroc']
            for key in draws:
                auc=ranks[key].compute(weights)['auroc']
                if base is not None and auc is not None:draws[key].append(auc-base)
        cis={k:dict(delta=stats[k]['auroc']-stats['rp']['auroc'],
                    paired_image_bootstrap_95ci=np.percentile(v,[2.5,97.5]).tolist(),valid_draws=len(v)) for k,v in draws.items() if v}
        image_stats={}
        for key,s in all_scores.items():
            valid_images=np.array([np.any(wi==i) for i in range(len(ids))]);im=np.zeros((len(ids),20))
            for i in np.flatnonzero(valid_images):im[i]=s[wi==i].max(0)
            perclass=[BinaryRanking(totalgt[valid_images,c]>0,im[valid_images,c]).compute() for c in range(20)]
            aps=[x['average_precision'] for x in perclass if x['average_precision'] is not None]
            aucs=[x['auroc'] for x in perclass if x['auroc'] is not None]
            image_stats[key]=dict(macro_AP=float(np.mean(aps)) if aps else None,
                macro_AUROC=float(np.mean(aucs)) if aucs else None,per_class=perclass,
                note='Score max over windows; annotated absence/presence only for original 20 VOC classes.')
        baseline=score>.15;curve=[]
        for tau in TAUS:
            rescue=(~baseline)&(prob>=tau);tp=int((rescue & gt).sum());fp=int((rescue & ~gt).sum())
            curve.append(dict(tau=tau,rescued_true_pairs=tp,rescued_false_pairs=fp,
                rescue_precision=tp/(tp+fp) if tp+fp else None,
                rescued_fraction_of_rp_misses=tp/int((gt&~baseline).sum()) if (gt&~baseline).any() else None,
                union_presence=presence_table(gt,baseline|rescue),
                rescued_positive_pixel_count_overlapping_windows=int(a['gt_counts'][rescue & gt].sum())))
        curves.append(curve)
        missed=(totalgt>0)&(~imagekeep);misspixels=int(totalgt[missed].sum());fg=int(totalgt.sum())
        perclass=[presence_table(gt[:,c],baseline[:,c]) for c in range(20)]
        summary=dict(condition=cond,output_classes=r['n_output_classes'],text_queries=r['n_text_queries'],
            mIoU=summarize_confusion(cms.sum(0))['mIoU'],
            window_presence=presence_table(gt,baseline),image_presence=presence_table(totalgt>0,imagekeep),
            window_presence_per_class=perclass,window_ranking=stats,window_ranking_rp_rejected_only=rejected_stats,
            auroc_differences=cis,image_ranking=image_stats,
            globally_missed_gt_foreground_pixels=misspixels,total_gt_foreground_pixels=fg,
            globally_missed_foreground_fraction=misspixels/fg if fg else None,
            threshold_presence_curve=curve,windows=len(wi),images=len(ids),
            mean_pipeline_seconds=float(np.mean([x['pipeline_test_step_seconds'] for x in r['per_image']])),
            peak_allocated_gpu_gib=max(x['peak_allocated_gpu_gib'] for x in r['per_image']))
        summaries.append(summary)
    from_metrics={k:summarize_confusion(v.sum(0))['mIoU'] for k,v in arrays.items()}
    # Matched development vocabulary comparison; same resamples for both conditions.
    rng=np.random.RandomState(511008);deltas=[]
    for _ in range(bootstrap):
        ix=rng.randint(0,len(ids_reference),len(ids_reference))
        deltas.append(summarize_confusion(arrays['expanded_vocab'][ix].sum(0))['mIoU']-summarize_confusion(arrays['original_vocab'][ix].sum(0))['mIoU'])
    result=dict(ok=True,protocol_hash=protocol_hash(),split='development200',results=summaries,
        vocabulary_delta_mIoU=from_metrics['expanded_vocab']-from_metrics['original_vocab'],
        vocabulary_delta_paired_bootstrap_95ci=np.percentile(deltas,[2.5,97.5]).tolist(),
        bootstrap_draws=bootstrap,proposed_common_tau=common_tau(curves),
        proposal_is_exploratory=True,y2_segmentation_evaluated=False,confirmation_evaluated=False,
        caution='No AUROC cutoff establishes improvement. No new class is a verified negative. Presence improvements do not prove segmentation gains; AP competition can change after rescue.')
    save_json(folder/'y2_diagnostic_summary.json',result)
    lines=['ASAMA 07 — Y2 TANI SONUCLARI','200 train goruntusu, iki vokabuler. Y2 segmentasyonu ve ayrilan 300 goruntu CALISTIRILMADI.','']
    for r in summaries:
        t=r['window_presence'];rank=r['window_ranking']
        lines.append(f"{r['condition']['id']}: K={r['output_classes']}, Q={r['text_queries']}, mIoU={r['mIoU']:.3f}")
        lines.append(f"Pencere-sinif TP/FP/FN/TN: {t['tp']}/{t['fp']}/{t['fn']}/{t['tn']}")
        lines.append('AUROC S / p / sabit OR: '+ ' / '.join(f"{rank[k]['auroc']:.4f}" for k in ['rp','cls_probability','or_fixed_tau_0p05']))
        lines.append(f"Tum pencerelerde RP'nin attigi siniflarin on plan piksel payi: %{100*r['globally_missed_foreground_fraction']:.3f}")
    lines+=['',f"Ortak tau adayi (yalnizca gelistirme varlik olcumu): {result['proposed_common_tau']}",
        'Bu sayilar Y2 mIoU sonucu degildir. Sonuc ZIP dosyasini paylas; final kuralini sonra sabitleyecegiz.']
    (folder/'SONUC_OZETI.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');print('\n'.join(lines),flush=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);a=p.parse_args();analyze(a.run_dir)
