import io
import json
import sys
import tarfile
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from stage2_helpers import extract_voc_files, git_blob_sha, run_logged
import check_runtime
import run_pilot


class Stage2Tests(unittest.TestCase):
    def test_git_blob_digest(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'hello'
            p.write_bytes(b'hello\n')
            self.assertEqual(git_blob_sha(p), 'ce013625030ba8dba906f756967f9e9ca394464a')

    def test_process_success_is_recorded(self):
        with tempfile.TemporaryDirectory() as td, redirect_stdout(io.StringIO()):
            run_logged([sys.executable, '-c', 'print("ok")'], 'sample', td)
            states = json.loads((Path(td) / 'stages.json').read_text())
            self.assertTrue(states['sample']['ok'])
            self.assertEqual((Path(td) / 'sample.log').read_text().strip(), 'ok')

    def test_process_failure_is_recorded(self):
        with tempfile.TemporaryDirectory() as td, redirect_stdout(io.StringIO()):
            with self.assertRaises(RuntimeError):
                run_logged([sys.executable, '-c', 'raise SystemExit(7)'], 'failed', td)
            state = json.loads((Path(td) / 'stages.json').read_text())['failed']
            self.assertFalse(state['ok'])
            self.assertEqual(state['returncode'], 7)

    def test_only_needed_dataset_files_are_extracted(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / 'fixture.tar'
            with tarfile.open(archive, 'w') as tar:
                for name in ['VOCdevkit/VOC2012/JPEGImages/a.jpg', 'VOCdevkit/VOC2012/Annotations/a.xml']:
                    info = tarfile.TarInfo(name)
                    info.size = 3
                    tar.addfile(info, io.BytesIO(b'abc'))
            extract_voc_files(archive, root / 'out')
            self.assertEqual((root / 'out/VOCdevkit/VOC2012/JPEGImages/a.jpg').read_bytes(), b'abc')
            self.assertFalse((root / 'out/VOCdevkit/VOC2012/Annotations').exists())

    def test_archive_traversal_and_links_are_rejected(self):
        for is_link in [False, True]:
            with self.subTest(is_link=is_link), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                archive = root / 'fixture.tar'
                with tarfile.open(archive, 'w') as tar:
                    info = tarfile.TarInfo('VOCdevkit/VOC2012/JPEGImages/link' if is_link else 'VOCdevkit/VOC2012/JPEGImages/../../../../escaped')
                    if is_link:
                        info.type = tarfile.SYMTYPE
                        info.linkname = '/tmp/outside'
                        tar.addfile(info)
                    else:
                        info.size = 3
                        tar.addfile(info, io.BytesIO(b'abc'))
                with self.assertRaises(ValueError):
                    extract_voc_files(archive, root / 'out')

    def test_runtime_error_writes_readable_report(self):
        with tempfile.TemporaryDirectory() as td, redirect_stdout(io.StringIO()):
            path = Path(td) / 'runtime.json'
            with patch.object(check_runtime.sys, 'version_info', (3, 13, 0)):
                with self.assertRaisesRegex(RuntimeError, 'Python 3.10'):
                    check_runtime.check(Path(td), path)
            report = json.loads(path.read_text())
            self.assertFalse(report['ok'])
            self.assertIn('Python 3.10', report['error'])

    def test_pilot_source_error_never_claims_success(self):
        with tempfile.TemporaryDirectory() as td, redirect_stdout(io.StringIO()):
            root = Path(td)
            with patch('run_pilot.subprocess.check_output', return_value='wrong-revision'):
                with self.assertRaisesRegex(RuntimeError, 'revision'):
                    run_pilot.main(root, root / 'config.py', root / 'result')
            report = json.loads((root / 'result/pilot_report.json').read_text())
            self.assertFalse(report['ok'])
            self.assertEqual(report['real_images_evaluated'], 0)
            self.assertFalse(report['full_baseline_reproduced'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
