"""Run the original SCLIP+FreeCP pipeline on a fixed VOC train subset."""
from __future__ import annotations
import argparse
import json
import math
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path
from stage2_helpers import UPSTREAM_SHA, digest, save_json


def clean_json(value):
    if isinstance(value, dict):
        return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean_json(v) for v in value]
    if hasattr(value, 'item'):
        return clean_json(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def main(repo, config, output):
    repo, config, output = Path(repo).resolve(), Path(config).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    report = {'ok': False, 'stage': 'real_image_smoke_test', 'method': 'SCLIP + FreeCP',
              'real_images_evaluated': 0, 'full_baseline_reproduced': False,
              'improvement_demonstrated': False, 'novelty_established': False,
              'upstream_commit': UPSTREAM_SHA, 'model_algorithm_changed': False,
              'note': 'Small train subset only. Not comparable with published validation scores.',
              'timing_note': 'Unwarmed test-step timings include preprocessing and source mask reads; not a latency benchmark.',
              'per_image': []}
    try:
        actual = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
        if actual != UPSTREAM_SHA:
            raise RuntimeError('Unexpected upstream revision.')
        if subprocess.call(['git', '-C', str(repo), 'diff', '--quiet', 'HEAD', '--']) != 0:
            raise RuntimeError('Tracked upstream files changed; stop rather than silently alter the baseline.')
        sys.path.insert(0, str(repo))
        os.chdir(repo)
        import numpy as np
        import torch
        from PIL import Image
        import freecp_segmentor
        import custom_datasets
        from mmengine.config import Config
        from mmengine.hooks import Hook
        from mmengine.runner import Runner
        cfg = Config.fromfile(str(config))
        if cfg.model.model_type != 'SCLIP':
            raise RuntimeError('The baseline must explicitly select SCLIP.')
        manifest = json.loads(config.with_suffix('.manifest.json').read_text())
        if manifest['source_split'] != 'train' or manifest['mode'] != 'pilot':
            raise RuntimeError('This driver is only for the training-split smoke test.')
        report['dataset_manifest'] = manifest
        cfg.work_dir = str(output / 'mmengine')
        cfg.launcher = 'none'
        cfg.randomness = dict(seed=5110, deterministic=False)
        cfg.dump(str(output / 'resolved_config.py'))
        report['config_sha256'] = digest(output / 'resolved_config.py')
        report['gpu'] = torch.cuda.get_device_name(0)
        runner = Runner.from_cfg(cfg)
        palette = [int(v) for color in runner.test_dataloader.dataset.metainfo['palette'] for v in color]
        palette = (palette + [0] * 768)[:768]
        palette[255 * 3:256 * 3] = [128, 128, 128]
        figures = output / 'figures'
        figures.mkdir(exist_ok=True)

        class ArtifactsHook(Hook):
            def before_test_iter(self, runner, batch_idx, data_batch=None):
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                self.started = time.perf_counter()

            def after_test_iter(self, runner, batch_idx, data_batch=None, outputs=None):
                torch.cuda.synchronize()
                elapsed = time.perf_counter() - self.started
                peak = torch.cuda.max_memory_allocated() / 1024**3
                for sample in outputs:
                    image_path = Path(sample.metainfo['img_path'])
                    image_id = image_path.stem
                    pred = sample.pred_sem_seg.data.squeeze(0).detach().cpu().numpy()
                    if pred.ndim != 2 or pred.min() < 0 or pred.max() > 20:
                        raise ValueError('Unexpected VOC21 prediction labels.')
                    finite = bool(torch.isfinite(sample.seg_logits.data).all().item())
                    image = Image.open(image_path).convert('RGB')
                    gt_path = Path(manifest['data_root']) / 'SegmentationClass' / (image_id + '.png')
                    gt_array = np.array(Image.open(gt_path))
                    if pred.shape != gt_array.shape or image.size != (pred.shape[1], pred.shape[0]):
                        raise ValueError('Prediction and ground-truth spatial dimensions differ.')
                    mask = Image.fromarray(pred.astype('uint8'), mode='P')
                    mask.putpalette(palette)
                    mask.save(figures / (image_id + '_prediction.png'))
                    gt = Image.fromarray(gt_array.astype('uint8'), mode='P')
                    gt.putpalette(palette)
                    preview = Image.new('RGB', (image.width * 3, image.height))
                    preview.paste(image, (0, 0))
                    preview.paste(gt.convert('RGB'), (image.width, 0))
                    preview.paste(mask.convert('RGB'), (image.width * 2, 0))
                    preview.save(figures / (image_id + '_image_gt_prediction.jpg'))
                    row = {'image_id': image_id, 'unwarmed_test_step_seconds': elapsed,
                           'peak_allocated_gpu_gib': peak, 'finite_logits': finite,
                           'height': int(pred.shape[0]), 'width': int(pred.shape[1]),
                           'predicted_classes': np.unique(pred).tolist(),
                           'image_sha256': digest(image_path), 'gt_sha256': digest(gt_path)}
                    report['per_image'].append(row)
                    report['real_images_evaluated'] = len(report['per_image'])
                    save_json(output / 'pilot_report.json', clean_json(report))

        runner.register_hook(ArtifactsHook())
        metrics = runner.test()
        report['metrics_percent'] = clean_json(metrics)
        if report['real_images_evaluated'] != manifest['n_images']:
            raise RuntimeError('Evaluated image count differs from the selected split.')
        if not all(row['finite_logits'] for row in report['per_image']):
            raise RuntimeError('Non-finite logits observed; inspect source behavior before continuing.')
        weights = Path.home() / '.cache/clip/ViT-B-16.pt'
        if weights.is_file():
            report['checkpoint'] = {'path': str(weights), 'sha256': digest(weights)}
            if report['checkpoint']['sha256'] != '5806e77cd80f8b59890b7e101eabd078d9fb84e6937f9e85e4ecb61988df416f':
                raise RuntimeError('Unexpected OpenAI ViT-B/16 checkpoint hash.')
        else:
            raise RuntimeError('Cannot locate the expected checkpoint for provenance.')
        report['ok'] = True
    except Exception as exc:
        report['error'] = f'{type(exc).__name__}: {exc}'
        report['traceback'] = traceback.format_exc()
        raise
    finally:
        report['total_wall_seconds_including_model_loading'] = time.perf_counter() - start
        save_json(output / 'pilot_report.json', clean_json(report))
        print(json.dumps(clean_json(report), indent=2), flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--repo', required=True)
    p.add_argument('--config', required=True)
    p.add_argument('--output', required=True)
    args = p.parse_args()
    main(args.repo, args.config, args.output)
