"""Phase-zero checks; standard library only. This does NOT run segmentation."""
from __future__ import annotations

import csv
import importlib.metadata
import importlib.util
import json
import math
import platform
from datetime import datetime, timezone
from pathlib import Path

UPSTREAM_SHA = "6946aa7999ec5d57d1fe91968ba1ae35a1e53295"
EPS = 1e-8


def published_code_score(before, after):
    """FreeCP redundancy_purification score, not the paper's Eq. 4.

    Inputs are flattened nonnegative maps. Matches the source expression:
    sum(X*Y) / (sum(X) + sum(Y) + 1e-8).
    """
    if len(before) != len(after) or not before:
        raise ValueError("Maps must have equal, non-zero lengths.")
    if any(not math.isfinite(x) or x < 0 for x in list(before) + list(after)):
        raise ValueError("Maps must contain finite nonnegative values.")
    return sum(x*y for x, y in zip(before, after)) / (sum(before) + sum(after) + EPS)


def cosine_shape_control(before, after):
    """Scale-invariant diagnostic control. NOT a validated improved method."""
    norm = math.sqrt(sum(x*x for x in before) * sum(y*y for y in after))
    return sum(x*y for x, y in zip(before, after)) / norm if norm else 0.0


def synthetic_probe():
    """Duplicate every candidate equally; target probability is divided by m.

    Refined spatial map is held fixed to isolate the pruning score. This is a
    controlled mathematical example, not real vocabulary expansion or mIoU.
    """
    original = [0.9, 0.8, 0.2, 0.1]
    refined = [1.0, 0.75, 0.125, 0.0]
    rows = []
    for copies in [1, 2, 4, 8]:
        target = [p / copies for p in original]
        score = published_code_score(target, refined)
        rows.append({
            "duplicate_copies_per_original_candidate": copies,
            "total_candidate_entries": 2 * copies,
            "code_rp_score": score,
            "rp_threshold": 0.15,
            "code_keeps_target": score > 0.15,
            "cosine_shape_control": cosine_shape_control(target, refined),
        })
    return rows


def environment_report():
    report = {
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(),
        "os": platform.system(),
        "machine": platform.machine(),
        "packages": {},
        "cuda_available": False,
        "cuda_kernel_test_passed": False,
    }
    for name in ["torch", "torchvision", "numpy", "mmcv", "mmcv-lite", "mmengine", "mmsegmentation"]:
        try:
            report["packages"][name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            report["packages"][name] = None
    if importlib.util.find_spec("torch") is None:
        report["next_step"] = "PyTorch is absent; no image-model experiment ran."
        return report
    try:
        import torch
        report["torch_cuda_build"] = torch.version.cuda
        report["cuda_available"] = torch.cuda.is_available()
        if report["cuda_available"]:
            props = torch.cuda.get_device_properties(0)
            report["gpu_name"] = props.name
            report["gpu_memory_gib"] = round(props.total_memory / 1024**3, 2)
            report["gpu_capability"] = list(torch.cuda.get_device_capability(0))
            x = torch.ones((32, 32), device="cuda")
            actual = (x @ x).mean().item()
            torch.cuda.synchronize()
            report["cuda_kernel_test_passed"] = actual == 32.0
            del x
        report["next_step"] = (
            "GPU kernel works. Validate the FreeCP dependency environment next."
            if report["cuda_kernel_test_passed"] else
            "Enable a GPU runtime or resolve CUDA compatibility before baseline evaluation."
        )
    except Exception as exc:
        report["gpu_check_error"] = f"{type(exc).__name__}: {exc}"
        report["next_step"] = "Resolve this environment error before baseline evaluation."
    return report


def write_report(output_dir="results"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rows = synthetic_probe()
    report = {
        "stage": "phase_0_environment_and_synthetic_diagnostic",
        "upstream_commit": UPSTREAM_SHA,
        "real_images_evaluated": 0,
        "baseline_reproduced": False,
        "improvement_demonstrated": False,
        "novelty_established": False,
        "environment": environment_report(),
        "synthetic_probe": rows,
        "interpretation": (
            "The published code's pruning score changes under uniform rescaling of "
            "the pre-refinement map, with the refined map fixed. This does not show "
            "segmentation failure or establish that cosine similarity improves it."
        ),
    }
    (out / "first_check_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    with (out / "synthetic_probe.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    return report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="results")
    args = parser.parse_args()
    print(json.dumps(write_report(args.output_dir), indent=2, ensure_ascii=False))
