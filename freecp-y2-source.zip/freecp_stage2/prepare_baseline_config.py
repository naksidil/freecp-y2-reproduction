"""Generate explicit SCLIP+FreeCP VOC21 configs without importing GPU packages."""
from __future__ import annotations
import argparse
import hashlib
import json
import random
import subprocess
from pathlib import Path
from first_check import UPSTREAM_SHA


def prepare(repo, data_root, output, mode="pilot", count=50, seed=5110):
    repo, data_root, output = Path(repo).resolve(), Path(data_root).resolve(), Path(output).resolve()
    if mode not in {"pilot", "reproduction"}:
        raise ValueError("Mode must be pilot or reproduction.")
    commit = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    if commit != UPSTREAM_SHA:
        raise ValueError(f"Expected pinned upstream commit {UPSTREAM_SHA}, got {commit}.")
    base = repo / "configs/cfg_voc21.py"
    if not base.is_file():
        raise FileNotFoundError(base)
    split = "train" if mode == "pilot" else "val"
    split_file = data_root / f"ImageSets/Segmentation/{split}.txt"
    ids = [s.strip() for s in split_file.read_text().splitlines() if s.strip()]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate IDs in dataset split.")
    if mode == "pilot":
        if count < 1 or count > len(ids):
            raise ValueError("Pilot count must be within the available training split.")
        ids = sorted(random.Random(seed).sample(ids, count))
    for item in ids:
        if Path(item).name != item:
            raise ValueError("Expected simple VOC image IDs.")
        for part, ext in [("JPEGImages", ".jpg"), ("SegmentationClass", ".png")]:
            path = data_root / part / (item + ext)
            if not path.is_file():
                raise FileNotFoundError(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    generated_split = output.with_suffix(".split.txt")
    split_text = "\n".join(ids) + "\n"
    generated_split.write_text(split_text, encoding="utf-8")
    # Upstream base_config.py defaults to GEM; explicitly override it here.
    config = (
        f"_base_ = {str(base)!r}\n"
        "model = dict(model_type='SCLIP')\n"
        "test_dataloader = dict(num_workers=0, persistent_workers=False, "
        f"dataset=dict(data_root={str(data_root)!r}, ann_file={str(generated_split)!r}))\n"
    )
    output.write_text(config, encoding="utf-8")
    manifest = {
        "upstream_commit": commit, "method": "SCLIP + FreeCP", "dataset": "VOC21",
        "mode": mode, "source_split": split, "n_images": len(ids),
        "sampling_seed": seed if mode == "pilot" else None,
        "split_sha256": hashlib.sha256(split_text.encode()).hexdigest(),
        "config": str(output), "data_root": str(data_root),
        "warning": (
            "Pilot is from training split; do not compare its mIoU to published validation results."
            if mode == "pilot" else
            "Full validation split; verify weights, dependencies and preprocessing before comparing published results."
        ),
    }
    output.with_suffix(".manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True)
    p.add_argument("--data-root", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--mode", choices=["pilot", "reproduction"], default="pilot")
    p.add_argument("--count", type=int, default=50)
    p.add_argument("--seed", type=int, default=5110)
    a = p.parse_args()
    print(json.dumps(prepare(a.repo, a.data_root, a.output, a.mode, a.count, a.seed), indent=2))
