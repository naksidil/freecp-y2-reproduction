"""Exact phase-04 selection. No search or selection is allowed on validation."""
import hashlib
import json
import math
from pathlib import Path

SELECTION_SHA256 = '147538bd48dd1a8c11fc9807ce472aa7543fa28da396922f23304e1962c0d067'
VAL_SHA256 = 'cdc1326d12f69ce5153aa5da04a4d8783e146868d42d19f82f44e74b97ac907d'
METHODS = [dict(name='released_original', score='original', threshold=0.15),
           dict(name='retuned_original', score='original', threshold=0.10),
           dict(name='cosine_RP', score='cosine', threshold=0.75)]
VOCABULARIES = ['clean', 'half_a', 'half_b', 'duplicate_bg']
BOOTSTRAP_DRAWS = 2000
BOOTSTRAP_SEED = 5110


def validate_selection(raw):
    """Validate the immutable, reviewed reference; never use this for live-run metadata."""
    if hashlib.sha256(raw).hexdigest() != SELECTION_SHA256:
        raise ValueError('Selection differs from the reviewed phase-04 result; no validation-driven retuning is allowed.')
    selected = json.loads(raw)
    if selected['methods'] != METHODS or selected['selection_source'] != 'clean_train50_only':
        raise ValueError('Unexpected locked methods.')
    return selected


def validate_compatible_selection(raw):
    """Accept rerun metadata changes while retaining the exact scientific selection."""
    reference = validate_selection((Path(__file__).parent / 'reviewed_selection.json').read_bytes())
    selected = json.loads(raw)
    for key in ['selection_source', 'protocol_sha256', 'rule', 'methods']:
        if selected.get(key) != reference[key]:
            raise ValueError(f'Rerun changed frozen scientific selection field: {key}. Share the new phase-04 result; thresholds will not be changed automatically.')
    rows = selected.get('calibration_runs', [])
    if len(rows) != 10:
        raise ValueError('Expected all ten predeclared clean-training calibration runs.')
    for row in rows:
        if (row.get('vocabulary') != 'clean' or row.get('score') not in {'original', 'cosine'}
                or not isinstance(row.get('mIoU'), (int, float))
                or not math.isfinite(row['mIoU']) or not 0 <= row['mIoU'] <= 100):
            raise ValueError('Invalid clean-training calibration evidence.')
    from protocol import choose_threshold
    for method in METHODS[1:]:
        best = choose_threshold(rows, method['score'])
        if best['threshold'] != method['threshold']:
            raise ValueError('Rerun calibration selected different thresholds; frozen validation settings will not be silently replaced.')
    return selected


def validate_condition(condition):
    if (condition['vocabulary'] not in VOCABULARIES or
            not any(condition['score'] == m['score'] and condition['threshold'] == m['threshold'] for m in METHODS)):
        raise ValueError('Condition is outside the locked validation plan.')
