"""Paired validation summaries and image-bootstrap intervals from confusion matrices."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from analyze_development import retention, comparison, check_parity
from metrics import summarize_confusion
from protocol import condition_id
from stage2_helpers import save_json, digest
from validation_protocol import (METHODS, VOCABULARIES, BOOTSTRAP_DRAWS,
                                 BOOTSTRAP_SEED, validate_selection, VAL_SHA256)


def batch_miou(matrices):
    """Input [..., GT, prediction], output [...] in percent; exclude zero-union classes."""
    matrices = np.asarray(matrices, dtype=np.float64)
    if matrices.ndim < 2 or matrices.shape[-1] != matrices.shape[-2] or np.any(matrices < 0):
        raise ValueError('Expected nonnegative square confusion matrices.')
    tp = np.diagonal(matrices, axis1=-2, axis2=-1)
    union = matrices.sum(-1) + matrices.sum(-2) - tp
    values = np.divide(tp, union, out=np.zeros_like(tp), where=union > 0)
    counts = (union > 0).sum(-1)
    return np.divide(values.sum(-1) * 100, counts, out=np.full_like(counts, np.nan, dtype=float), where=counts > 0)


def paired_bootstrap(confusions, draws=BOOTSTRAP_DRAWS, seed=BOOTSTRAP_SEED):
    """confusions: conditions x same images x classes x classes. Resample images jointly."""
    data = np.asarray(confusions, dtype=np.float64)
    if data.ndim != 4 or data.shape[2] != data.shape[3] or np.any(data < 0) or draws < 1:
        raise ValueError('Malformed paired matrices or draw count.')
    conditions, images, classes, _ = data.shape
    if images < 1:
        raise ValueError('Empty image set.')
    flat = np.ascontiguousarray(data.transpose(1, 0, 2, 3).reshape(images, -1))
    rng = np.random.default_rng(seed)
    scores = np.empty((draws, conditions), dtype=np.float64)
    # Same multinomial weights for every condition; mIoU is computed after aggregation.
    for start in range(0, draws, 128):
        count = min(128, draws - start)
        weights = rng.multinomial(images, np.full(images, 1 / images), size=count).astype(float)
        totals = (weights @ flat).reshape(count, conditions, classes, classes)
        scores[start:start+count] = batch_miou(totals)
    if not np.isfinite(scores).all():
        raise ValueError('Undefined bootstrap mIoU; inspect empty/all-void resamples.')
    return scores


def summarize(run_dir):
    run_dir = Path(run_dir)
    validate_selection((run_dir / 'evidence/selection.json').read_bytes())
    if digest(run_dir / 'evidence/val1449.split.txt') != VAL_SHA256:
        raise ValueError('Validation split hash mismatch.')
    expected_ids = (run_dir / 'evidence/val1449.split.txt').read_text().split()
    records, matrices, names = [], [], []
    for method in METHODS:
        clean_dir = run_dir / 'conditions' / condition_id(method['score'], method['threshold'], 'clean')
        clean = json.loads((clean_dir / 'evaluation_report.json').read_text())
        for vocabulary in VOCABULARIES:
            name = condition_id(method['score'], method['threshold'], vocabulary)
            path = run_dir / 'conditions' / name
            report = json.loads((path / 'evaluation_report.json').read_text())
            if (not report['ok'] or not report['full_validation_evaluated']
                    or report['real_images_evaluated'] != 1449):
                raise ValueError('Incomplete validation condition.')
            with np.load(path / 'per_image_confusions.npz') as data:
                if data['image_ids'].tolist() != expected_ids or data['confusion_matrices'].shape != (1449, 21, 21):
                    raise ValueError('Image pairing or matrix shape mismatch.')
                matrix = data['confusion_matrices'].copy()
            independent = summarize_confusion(matrix.sum(0))
            for key in ['mIoU', 'mAcc', 'aAcc']:
                if abs(independent[key] - report['independent_metrics_percent'][key]) > 1e-9:
                    raise ValueError('Independent metric recomputation failed.')
            row = {'method': method['name'], 'score': method['score'], 'threshold': method['threshold'],
                   'vocabulary': vocabulary, 'mIoU': independent['mIoU'],
                   'mIoU_change_from_clean_points': independent['mIoU'] - clean['independent_metrics_percent']['mIoU'],
                   'peak_allocated_gpu_gib': report['peak_allocated_gpu_gib'],
                   'mean_audited_unwarmed_step_seconds': float(np.mean([x['unwarmed_test_step_seconds'] for x in report['per_image']]))}
            row.update(retention(report['per_image']))
            row.update(comparison(clean_dir, path, clean, report))
            records.append(row)
            matrices.append(matrix)
            names.append(name)
    with (run_dir / 'validation_summary.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    save_json(run_dir / 'validation_summary.json', {
        'ok': True, 'split': 'full_val1449', 'records': records,
        'novelty_established': False,
        'retention_definition': 'Image-class micro rates from union of RP-kept classes over crops BEFORE AP. Not pixel recall.',
        'duplicate_control': 'Stable exact deduplication restores clean input; reuse clean predictions, not a separately measured run.',
        'timing_warning': 'Audited and unwarmed; not a formal latency benchmark.',
        'interpretation': 'Report all results including the failed cosine hypothesis. Baseline validation was already inspected for reproduction. No validation-driven retuning.'})
    print('All 12 conditions verified. Computing paired image-bootstrap intervals...', flush=True)
    bootstrap = paired_bootstrap(np.stack(matrices))
    np.savez_compressed(run_dir / 'paired_bootstrap_miou.npz', condition_names=np.array(names), scores=bootstrap)
    index = {name: i for i, name in enumerate(names)}

    def interval(label, terms, primary=False):
        observed = sum(coef * records[index[name]]['mIoU'] for name, coef in terms)
        values = sum(coef * bootstrap[:, index[name]] for name, coef in terms)
        low, high = np.percentile(values, [2.5, 97.5])
        return {'contrast': label, 'primary_endpoint': primary, 'estimate_points': float(observed),
                'paired_percentile_95_CI_points': [float(low), float(high)]}

    def name(method_index, vocabulary):
        m = METHODS[method_index]
        return condition_id(m['score'], m['threshold'], vocabulary)

    contrasts = [interval('Cosine minus retuned-original: duplicate-minus-clean mIoU change',
                          [(name(2, 'duplicate_bg'), 1), (name(2, 'clean'), -1),
                           (name(1, 'duplicate_bg'), -1), (name(1, 'clean'), 1)], primary=True),
                 interval('Retuned original minus released original on clean', [(name(1, 'clean'), 1), (name(0, 'clean'), -1)])]
    for vocabulary in VOCABULARIES:
        contrasts.append(interval('Cosine minus retuned original on ' + vocabulary,
                                  [(name(2, vocabulary), 1), (name(1, vocabulary), -1)]))
    for i, method in enumerate(METHODS):
        for vocabulary in VOCABULARIES[1:]:
            contrasts.append(interval(method['name'] + ': ' + vocabulary + ' minus clean',
                                      [(name(i, vocabulary), 1), (name(i, 'clean'), -1)]))
    save_json(run_dir / 'paired_comparisons.json', {
        'bootstrap_unit': 'image, jointly resampled across every condition',
        'draws': BOOTSTRAP_DRAWS, 'seed': BOOTSTRAP_SEED,
        'method': 'Aggregate resampled per-image confusion matrices, then recompute class-mean IoU. Percentile 95% intervals.',
        'contrasts': contrasts,
        'limits': ['Intervals describe image-sampling variation, not training-seed or threshold-selection uncertainty.',
                   'Secondary intervals are descriptive and unadjusted for multiple comparisons.',
                   'A smaller signed or absolute perturbation change is insufficient if clean segmentation quality is poor.',
                   'No new model is selected using these validation intervals.']})


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--run-dir')
    p.add_argument('--parity', nargs=3)
    args = p.parse_args()
    if args.parity:
        check_parity(*args.parity)
    elif args.run_dir:
        summarize(args.run_dir)
    else:
        p.error('Specify --run-dir or --parity.')
