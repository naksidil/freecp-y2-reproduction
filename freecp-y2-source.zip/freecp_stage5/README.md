# 05 — Sabit ayarlarla tam doğrulama

**Düzeltilmiş sürüm 2:** 04 yeniden çalıştırıldığında tarih ve çıktı klasörleri değişir. İlk 05 paketi seçim dosyasının tüm baytlarının eski çalışmayla eşit olmasını istediği için, aynı deneyin yeni çalışmasını reddedebiliyordu. Bu uygulama hatası düzeltildi. Yeniden çalıştırılan 04 aynı bilimsel protokolü ve seçilmiş eşikleri koruyorsa kabul edilir; eski referans ve yeni çalışma kaydı ayrı ayrı saklanır. Eşikler, model hesapları ve değerlendirme koşulları değiştirilmedi. Önceki 0/12 durmasının kesin nedeni, o çalışmanın hata kaydı görülmediği için bilinmiyor.

**Amaç:** 04'teki 50 eğitim görüntüsünde seçilmiş ayarları değiştirmeden, 1.449 VOC2012 doğrulama görüntüsünde değerlendirmek. Kosinüs önerisi geliştirme deneyinde başarısız oldu; bu paket başarısız sonucu saklamaz veya başarılı bir sonuç bulana kadar eşik aramaz.

## Önceki sonuç

19 geliştirme koşulu tamamlandı. 17 test geçti. İlk yöntemin 50 tahmin maskesi önceki sonuçla bayt düzeyinde aynıydı. 19 koşulun mIoU, mAcc ve aAcc değerleri kaydedilen karışıklık matrislerinden bağımsız yeniden hesaplandı; fark sıfırdı. 6.384 kırpmanın skor/eşik kararları da doğrulandı. Eşikler, bozulmuş kelime listelerine geçilmeden önce seçilmişti.

| Yöntem | Temiz liste mIoU (%) | Yarı A | Yarı B | Tekrarlı arka plan |
| --- | ---: | ---: | ---: | ---: |
| Orijinal RP, 0,15 | 55,55 | 46,72 | 53,90 | 53,71 |
| Orijinal RP, 0,10 | 56,27 | 44,22 | 50,81 | 58,95 |
| Kosinüs RP, 0,75 | 27,92 | 22,13 | 23,35 | 29,84 |

Bunlar **aynı 50 eğitim görüntüsündeki geliştirme sonuçlarıdır**. Önceki 1.449 doğrulama görüntüsünün %65,76 puanıyla doğrudan karşılaştırılmaz.

Kosinüs, temiz koşulda RP aşamasında görüntü başına ortalama 13,94 nesne sınıfı tutmuş; orijinal yöntem 1,62 sınıf tutmuş. Görüntüde olmayan sınıfları tutma oranı %1,85'ten %67,86'ya yükselmiş. Bu oranlar, RP'den sonra ve AP'den önce, tüm kırpmaların tuttuğu sınıfların birleşiminden hesaplanan **görüntü-sınıf oranlarıdır**, piksel hata oranı değildir.

Yorum: yalnızca mekânsal benzerliğe odaklanmak, güven/aktivasyon büyüklüğü bilgisini kaybedip yanlış sınıfların kalmasına yol açmış olabilir. Yüksek yanlış sınıf tutma oranı bu açıklamayı destekliyor; tek başına tüm nedensel mekanizmayı kanıtlamıyor. Eşik kontrolünün temiz listede +0,73 puan kazanması da doğrulamada henüz kanıtlanmış bir iyileşme değildir.

## Değiştirilmeyecek plan

- Orijinal RP: **0,15**.
- Eğitimde seçilmiş orijinal RP: **0,10**.
- Eğitimde seçilmiş kosinüs RP: **0,75**.
- Her yöntem: **clean, half_a, half_b, duplicate_bg**. Toplam 12 koşul, her koşulda aynı 1.449 görüntü.
- AP eşiği 0,8; CLIP ViT-B/16, SCLIP, ön işleme ve model uygulaması 04 ile aynı.
- İncelenmiş referans seçimin SHA256 değeri pakete sabitlenmiştir. Yeni 04 çalışmasının tarih/klasör bilgileri farklı olabilir; bilimsel protokol, seçim kuralı, on temiz eğitim kalibrasyonu ve seçilen eşikler kontrol edilir. Farklı eşiklerle çalışmayı reddeder.

## Çalıştırma

1. `05_FreeCP_Sabit_Ayarlarla_Dogrulama.zip` dosyasını indir.
2. ZIP içindeki `COLAB_BASLAT.txt` metnini, **04'ü çalıştırdığın aynı Colab not defterindeki eski 05 hücresinin yerine** yapıştır. Başında `DUZELTILMIS 05, SURUM 2` yazar. 04'te `Deney tamamlandi.` mesajını görmeden 05'e geçme.
3. Hücreyi çalıştır; dosya seçicide **05 ile başlayan paket ZIP'ini** yükle.
4. T4 ile devam et. Canlı oturum duruyorsa 02, 03 veya 04'ü tekrar çalıştırma, paketleri yeniden kurma.
5. İşlem bitince indirilen **`freecp_validation_results_....zip`** dosyasını paylaş. Sonuç ZIP'i bütün tahminleri ve kayıtları içerdiği için önceki dosyadan büyük olabilir.

Önceki sürelerden hareketle **yaklaşık 2–3 saat ayır**; bu bir süre garantisi değildir. Koşulların ilk üçü temiz liste karşılaştırmaları, sonraki üçü tekrarlı liste, son altısı iki yarım listedir. Her 50 görüntüde ilerleme, her koşul sonunda `VALIDATION .../12` yazılır. En sonda eşleştirilmiş istatistiksel analiz ve ZIP hazırlığı yapılır.

**Kesilirse:** Aynı paketle aynı hücreyi yeniden çalıştırabilirsin. Aynı Colab sanal makinesi ve dosyaları duruyorsa tamamlanmış koşullar yeniden kullanılabilir; yarım kalan koşul baştan çalışır ve eski kısmı ayrıca saklanır. Bu, silinen/sıfırlanan sanal makineden kurtarma sağlamaz. Başarısızlıkta indirilen ZIP'i paylaş.

## Kontroller ve çıktılar

Başlangıçta kaynak, tokenizer, Python paketleri, veri bölünmesi ve GPU kontrolleri yapılır. İlk koşul, eski 03 doğrulama çalışmasının 1.449 tahminiyle **her pikselde aynı** olmalıdır. Fark varsa yeni koşullara geçmeden durur.

- `validation_report.json`: tamamlanma, hata ve devam kaydı.
- `validation_baseline_parity.json`: önceki doğrulama tahminleriyle eşitlik.
- `validation_summary.csv` / `.json`: 12 koşulun kalite, kararlılık, sınıf koruma ve bellek sonuçları.
- `paired_comparisons.json`: eşleştirilmiş görüntü bootstrap güven aralıkları.
- `paired_bootstrap_miou.npz`: 2.000 bootstrap örneklemesinin mIoU sonuçları.
- `conditions/`: her koşulun bütün tahmin maskeleri, ilk iki örneğin görselleri, karışıklık matrisleri ve RP kayıtları.
- `evidence/`: değiştirilmemiş seçim dosyası, veri listesi ve önceki geliştirme sonuçları.

Burada `selection.json` incelenmiş özgün referanstır; `live_selection.json` bu oturumda kullanılan gerçek 04 çalışmasının kaydıdır. `selection_provenance.json` ikisinin kimliğini ve bilimsel uyumluluk kontrolünü açıklar. Böylece yeniden çalıştırmanın zaman/path bilgileri saklanır ve eski çalışmanın kendisiymiş gibi gösterilmez. Sürüm 2 farklı paket kimliğiyle yeni doğrulama çalışması açar; önceki 05 sürümünün çıktıları silinmez. Sürüm 2 kendi tamamlanmış koşullarından devam edebilir.

Bootstrap, aynı görüntüleri bütün koşullarda birlikte yeniden örnekler. Görüntü başına mIoU ortalaması almaz; karışıklık matrislerini topladıktan sonra mIoU hesaplar. %95 yüzdelik güven aralıkları görüntü örnekleme değişkenliğini gösterir; model eğitimi rastgeleliği veya eşik seçimi belirsizliğinin tamamını kapsamaz. İkincil aralıklar çoklu karşılaştırma düzeltmesi uygulanmamış betimleyici sonuçlardır.

Tekrarlı kelimeleri birebir ayıklamak, temiz listeyi aynen geri getirir. Bu basit kontrol temiz koşulun ölçümünü yeniden kullanır; ayrıca çalıştırılmış/zamanlanmış gibi sunulmaz. Salt tekrar sorununda yeni skora ihtiyaç olduğunu iddia etmeyeceğiz.

GPU belleği PyTorch'un tepe ayrılmış belleğidir. Kayıtlı süreler ayrıntılı denetim ve senkronizasyon içerir; yöntem hızlanması iddiası için kullanılmamalıdır. Ödevin kaynak metriğinde bellek kullanılabilir.

## Bilimsel yorum

Olumsuz sonuç, projenin tamamlanmadığı anlamına gelmez. Bu çalışmanın savunulabilir çıktısı; başarılı yeniden üretim, arka plan kelimelerine duyarlılık ölçümü, kontrollü bir değişiklik ve neden başarısız olduğunu açıklayan kanıtlar olabilir. Bu paket özgünlük veya konferans kabulü iddiasında bulunmaz. Doğrulama sonucuna bakıp eşik değiştirmek ya da yalnızca iyi görünen koşulu raporlamak yasaktır. Doğrulama başlangıç puanı yeniden üretim sırasında zaten görüldüğü için bu bölümü tamamen kör test diye adlandırmayacağız.

Kodu ve deney tasarımını hazırlarken yapay zekâ yardımı kullanıldı. Raporda bu yardım açıklanmalı, öğrenci kodu ve sonuçları anlayarak doğrulamalıdır.

## Yerel test durumu

Sayısal analiz, seçim kilidi, devam kontrolü ve sözdizimi testleri hazırlama ortamında çalıştırılmıştır; ayrıntı `VERIFICATION.json` içindedir. Bu ortamda Torch/GPU yoktur. 04'teki model uygulaması değişmeden korunmuştur ve kullanıcının T4 çalışmasında test edilmiştir; yeni 12 koşullu tam doğrulama akışı burada çalıştırılmış değildir.
