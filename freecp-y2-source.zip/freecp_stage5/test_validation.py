"""Scientific metric, pairing and locked-selection checks without model inference."""
import json
import hashlib
import tempfile
import unittest
from pathlib import Path
import numpy as np
from analyze_validation import batch_miou, paired_bootstrap
from validation_protocol import validate_selection, validate_compatible_selection, validate_condition, METHODS
from run_validation import choose_run, find_reviewed_development, read_compatible_development


class ValidationTests(unittest.TestCase):
    def rerun_selection(self):
        selected = json.loads((Path(__file__).parent / 'reviewed_selection.json').read_bytes())
        selected['locked_at_utc'] = '2026-11-11T12:45:00+00:00'
        for row in selected['calibration_runs']:
            row['run_directory'] = '/content/freecp_t4/runs/development_new/conditions/' + row['condition_id']
        return selected

    def test_locked_selection_rejects_retuning(self):
        raw = (Path(__file__).parent / 'reviewed_selection.json').read_bytes()
        self.assertEqual(validate_selection(raw)['methods'], METHODS)
        changed = json.loads(raw)
        changed['methods'][2]['threshold'] = .8
        with self.assertRaises(ValueError):
            validate_selection(json.dumps(changed).encode())
        with self.assertRaises(ValueError):
            validate_condition(dict(score='cosine', threshold=.8, vocabulary='clean'))
        with self.assertRaises(ValueError):
            validate_condition(dict(score='cosine', threshold=.75, vocabulary='new_unplanned_vocabulary'))

    def test_pooled_miou_is_not_average_image_miou(self):
        a = np.array([[9, 1], [0, 0]])
        b = np.array([[0, 0], [0, 1]])
        self.assertAlmostEqual(float(batch_miou(a+b)), 70.)
        self.assertAlmostEqual(float(np.mean(batch_miou(np.stack([a,b])))), 72.5)
        self.assertTrue(np.isnan(batch_miou(np.zeros((2,2)))))

    def test_paired_bootstrap_same_input_zero_difference(self):
        images = np.array([[[9, 1], [0, 0]], [[0, 0], [0, 1]]])
        data = np.stack([images, images])
        scores = paired_bootstrap(data, draws=100, seed=5110)
        self.assertEqual(scores.shape, (100,2))
        np.testing.assert_array_equal(scores[:,0], scores[:,1])
        self.assertTrue(set(np.round(scores.ravel(),8)) <= {45.,70.,100.})
        np.testing.assert_array_equal(scores, paired_bootstrap(data, draws=100, seed=5110))

    def test_batch_metric_matches_independent_implementation(self):
        from metrics import summarize_confusion
        rng = np.random.default_rng(5110)
        matrices = rng.integers(0,20,size=(4,21,21))
        expected = [summarize_confusion(m)['mIoU'] for m in matrices]
        np.testing.assert_allclose(batch_miou(matrices), expected, atol=1e-12)

    def test_resume_is_bound_to_exact_package(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            path, state, resumed=choose_run(root,'package-A')
            self.assertFalse(resumed)
            same, _, resumed=choose_run(root,'package-A')
            self.assertTrue(resumed)
            self.assertEqual(path,same)
            different, _, resumed=choose_run(root,'package-B')
            self.assertFalse(resumed)
            self.assertNotEqual(path,different)

    def test_rerun_metadata_changes_are_accepted_but_reference_remains_strict(self):
        raw = json.dumps(self.rerun_selection()).encode()
        with self.assertRaises(ValueError):
            validate_selection(raw)  # Reproduces the original bug at the live-run call site.
        self.assertEqual(validate_compatible_selection(raw)['methods'], METHODS)

    def test_rerun_still_rejects_changed_scientific_fields(self):
        for field, value in [('selection_source','validation'), ('rule','pick best validation score'),
                             ('protocol_sha256','different-protocol')]:
            selected = self.rerun_selection()
            selected[field] = value
            with self.assertRaises(ValueError):
                validate_compatible_selection(json.dumps(selected).encode())
        selected = self.rerun_selection()
        selected['methods'][2]['threshold'] = .9
        with self.assertRaises(ValueError):
            validate_compatible_selection(json.dumps(selected).encode())

    def test_rerun_calibration_must_support_same_winner(self):
        selected = self.rerun_selection()
        for row in selected['calibration_runs']:
            if row['score']=='cosine' and row['threshold']==.3:
                row['mIoU'] = 99.
        with self.assertRaises(ValueError):
            validate_compatible_selection(json.dumps(selected).encode())
        selected = self.rerun_selection()
        selected['calibration_runs'].pop()
        with self.assertRaises(ValueError):
            validate_compatible_selection(json.dumps(selected).encode())

    def test_live_rerun_discovery_and_hash_guard(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            run = root/'runs/development_20261111T124500'
            run.mkdir(parents=True)
            raw = json.dumps(self.rerun_selection()).encode()
            (run/'selection.json').write_bytes(raw)
            (run/'protocol.json').write_bytes((Path(__file__).parent/'reviewed_protocol.json').read_bytes())
            report = dict(ok=True, baseline_parity_passed=True, thresholds_locked=True,
                          validation_evaluated=False, previous_baseline=str(root/'runs/baseline_new'),
                          selection_sha256=hashlib.sha256(raw).hexdigest())
            (run/'development_report.json').write_text(json.dumps(report))
            found, baseline = find_reviewed_development(root)
            self.assertEqual(found,run)
            self.assertEqual(baseline,root/'runs/baseline_new')
            report['selection_sha256']='stale-hash'
            (run/'development_report.json').write_text(json.dumps(report))
            with self.assertRaises(ValueError):
                read_compatible_development(run)

    def test_incomplete_development_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            run = Path(d)
            (run/'selection.json').write_text(json.dumps(self.rerun_selection()))
            (run/'development_report.json').write_text(json.dumps(dict(ok=False)))
            with self.assertRaises(ValueError):
                read_compatible_development(run)


if __name__ == '__main__':
    unittest.main(verbosity=2)
