"""Resume-safe condition-level evaluation of the predeclared validation plan."""
from __future__ import annotations
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from protocol import condition_id
from stage2_helpers import UPSTREAM_SHA, BPE_GIT_BLOB_SHA, digest, git_blob_sha, run_logged, save_json
from validation_protocol import (METHODS, VOCABULARIES, VAL_SHA256, SELECTION_SHA256,
                                 validate_selection, validate_compatible_selection, validate_condition)


def package_fingerprint(folder):
    result = hashlib.sha256()
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in {'.py', '.md', '.txt', '.json'}:
            result.update(path.name.encode() + b'\0' + path.read_bytes())
    return result.hexdigest()


def read_compatible_development(directory):
    directory = Path(directory)
    raw = (directory / 'selection.json').read_bytes()
    selected = validate_compatible_selection(raw)
    report = json.loads((directory / 'development_report.json').read_text())
    if (report.get('ok') is not True or report.get('baseline_parity_passed') is not True
            or report.get('thresholds_locked') is not True or report.get('validation_evaluated') is not False):
        raise ValueError('Phase 04 did not successfully complete the frozen training-only experiment.')
    if report.get('selection_sha256') != hashlib.sha256(raw).hexdigest():
        raise ValueError('Live selection hash differs from its own phase-04 completion record.')
    if digest(directory / 'protocol.json') != selected['protocol_sha256']:
        raise ValueError('Phase-04 scientific protocol changed.')
    return directory, Path(report['previous_baseline'])


def find_reviewed_development(root):
    problems = []
    for path in sorted((root / 'runs').glob('development_*/selection.json'), reverse=True):
        try:
            return read_compatible_development(path.parent)
        except (OSError, ValueError, KeyError) as exc:
            problems.append(f'{path.parent.name}: {exc}')
    detail = ' | '.join(problems[:2]) if problems else 'No phase-04 selection files exist in this VM.'
    raise RuntimeError('No completed compatible phase-04 run found. ' + detail)


def choose_run(root, fingerprint):
    pointer = root / 'latest_validation_work.json'
    if pointer.is_file():
        info = json.loads(pointer.read_text())
        artifact = Path(info['artifact']).resolve()
        if artifact.parent != (root / 'runs').resolve() or not artifact.name.startswith('validation_'):
            raise ValueError('Unexpected resume path.')
        if info.get('package_fingerprint') == fingerprint and (artifact / 'validation_report.json').is_file():
            state = json.loads((artifact / 'validation_report.json').read_text())
            return artifact, state, True
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    artifact = root / 'runs' / ('validation_' + run_id)
    artifact.mkdir(parents=True, exist_ok=False)
    state = {'ok': False, 'run_id': run_id, 'stage': 'locked_full_validation',
             'package_fingerprint': fingerprint, 'selection_sha256': SELECTION_SHA256,
             'planned_conditions': 12, 'completed_runs': [], 'validation_driven_tuning': False,
             'novelty_established': False, 'attempts': []}
    save_json(artifact / 'validation_report.json', state)
    save_json(pointer, {'artifact': str(artifact), 'package_fingerprint': fingerprint})
    return artifact, state, False


def completed_condition(output, condition):
    try:
        report = json.loads((output / 'evaluation_report.json').read_text())
        return (report.get('ok') is True and report.get('full_validation_evaluated') is True
                and report.get('real_images_evaluated') == 1449 and report.get('condition') == condition
                and report['dataset_manifest']['split_sha256'] == VAL_SHA256
                and report['dataset_manifest']['selection_sha256'] == SELECTION_SHA256
                and (output / 'per_image_confusions.npz').is_file()
                and len(list((output / 'figures').glob('*_prediction.png'))) == 1449)
    except (OSError, ValueError, KeyError):
        return False


def write_config(repo, voc, split, vocabulary, condition, output):
    validate_condition(condition)
    output.write_text(
        f'_base_ = {str(repo / "configs/cfg_voc21.py")!r}\n'
        'model = dict(type="AuditedFreeCPSegmentation", model_type="SCLIP", '
        f'rp_score={condition["score"]!r}, rp_thres={condition["threshold"]!r}, ap_thres=0.8, '
        f'name_path={str(vocabulary)!r})\n'
        'test_dataloader = dict(num_workers=0, persistent_workers=False, '
        f'dataset=dict(data_root={str(voc)!r}, ann_file={str(split)!r}))\n', encoding='utf-8')
    save_json(output.with_suffix('.manifest.json'), {
        'upstream_commit': UPSTREAM_SHA, 'source_split': 'val', 'mode': 'validation',
        'dataset': 'VOC21', 'n_images': 1449, 'split_sha256': digest(split),
        'data_root': str(voc), 'condition': condition, 'selection_sha256': SELECTION_SHA256,
        'vocabulary_sha256': digest(vocabulary)})


def main(root=Path('/content/freecp_t4')):
    root = Path(root).resolve()
    source = Path(__file__).resolve().parent
    fingerprint = package_fingerprint(source)
    artifact, state, resumed = choose_run(root, fingerprint)
    state['attempts'].append({'started_utc': datetime.now(timezone.utc).isoformat(), 'resumed': resumed})
    state['ok'] = False
    state.pop('error', None)
    state.pop('traceback', None)
    exit_code = 1
    try:
        scripts = artifact / 'scripts'
        if not scripts.exists():
            scripts.mkdir()
            for path in source.iterdir():
                if path.is_file() and path.suffix in {'.py', '.md', '.txt', '.json'}:
                    shutil.copy2(path, scripts / path.name)
        if package_fingerprint(scripts) != fingerprint:
            raise RuntimeError('Saved source differs from the resume package.')
        validate_selection((scripts / 'reviewed_selection.json').read_bytes())
        repo, python, voc = root / 'FreeCP', root / 'env_py310/bin/python', root / 'data/VOCdevkit/VOC2012'
        for path in [python, repo / 'configs/cfg_voc21.py', voc / 'ImageSets/Segmentation/val.txt']:
            if not path.exists():
                raise FileNotFoundError(f'{path} is missing. Continue in the same live Colab VM as stages 02–04.')
        if state.get('development_run'):
            # Resuming validation must retain the same development provenance.
            previous, baseline = read_compatible_development(state['development_run'])
        else:
            previous, baseline = find_reviewed_development(root)
        state['development_run'], state['baseline_run'] = str(previous), str(baseline)
        for name in ['score_ops.py', 'audited_segmentor.py']:
            if digest(scripts / name) != digest(previous / 'scripts' / name):
                raise RuntimeError('Model implementation differs from the reviewed development run.')
        evidence = artifact / 'evidence'
        evidence.mkdir(exist_ok=True)
        for name in ['locked_validation_plan.json', 'development_summary.json', 'vocabulary_manifest.json']:
            shutil.copy2(previous / name, evidence / name)
        # Preserve both records without relabelling a rerun as the original run.
        shutil.copy2(previous / 'selection.json', evidence / 'live_selection.json')
        validate_compatible_selection((evidence / 'live_selection.json').read_bytes())
        shutil.copy2(scripts / 'reviewed_selection.json', evidence / 'selection.json')
        validate_selection((evidence / 'selection.json').read_bytes())
        state['live_selection_sha256'] = digest(evidence / 'live_selection.json')
        save_json(evidence / 'selection_provenance.json', {
            'frozen_reference_file': 'selection.json', 'frozen_reference_sha256': SELECTION_SHA256,
            'live_run_file': 'live_selection.json', 'live_run_sha256': state['live_selection_sha256'],
            'live_development_directory': str(previous),
            'scientific_selection_compatible': True,
            'metadata_may_differ': ['locked_at_utc', 'run_directory', 'calibration mIoU values with the same winning thresholds'],
            'note': 'Evaluation manifests refer to the immutable reviewed selection. Live rerun evidence is separately preserved. No validation-driven retuning.'})
        locked_plan = json.loads((evidence / 'locked_validation_plan.json').read_text())
        if (locked_plan['methods'] != METHODS or locked_plan['vocabularies'] != VOCABULARIES
                or locked_plan['selection_sha256'] != state['live_selection_sha256']):
            raise RuntimeError('Unexpected locked validation plan.')
        split = evidence / 'val1449.split.txt'
        shutil.copy2(baseline / 'val1449_config.split.txt', split)
        if digest(split) != VAL_SHA256:
            raise RuntimeError('Reviewed validation split changed.')
        ids = split.read_text().split()
        actual_ids = (voc / 'ImageSets/Segmentation/val.txt').read_text().split()
        train_ids = set((voc / 'ImageSets/Segmentation/train.txt').read_text().split())
        if ids != actual_ids or len(ids) != 1449 or len(set(ids)) != 1449 or set(ids) & train_ids:
            raise RuntimeError('Validation IDs differ or overlap the training split.')
        vocab_dir, config_dir = artifact / 'vocabularies', artifact / 'configs'
        vocab_dir.mkdir(exist_ok=True)
        config_dir.mkdir(exist_ok=True)
        vocab_manifest = json.loads((evidence / 'vocabulary_manifest.json').read_text())
        for vocabulary in VOCABULARIES + ['deduplicated_bg']:
            target = vocab_dir / (vocabulary + '.txt')
            shutil.copy2(previous / 'vocabularies' / target.name, target)
            if digest(target) != vocab_manifest[vocabulary]['sha256']:
                raise RuntimeError('Vocabulary input changed since development.')
        if (vocab_dir / 'clean.txt').read_bytes() != (vocab_dir / 'deduplicated_bg.txt').read_bytes():
            raise RuntimeError('Deduplication control is not input-equivalent.')
        if git_blob_sha(repo / 'open_clip/bpe_simple_vocab_16e6.txt.gz') != BPE_GIT_BLOB_SHA:
            raise RuntimeError('Tokenizer provenance changed.')
        env = os.environ.copy()
        env.update(MPLBACKEND='Agg', TOKENIZERS_PARALLELISM='false')

        def run(command, label, cwd=None):
            run_logged(command, label, artifact, cwd=cwd, env=env)

        run([python, scripts / 'check_runtime.py', repo, artifact / 'runtime_report.json'], 'runtime_recheck', repo)
        freeze = subprocess.check_output([str(python), '-m', 'pip', 'freeze'], text=True, env=env)
        if set(freeze.splitlines()) != set((previous / 'pip_freeze.txt').read_text().splitlines()):
            raise RuntimeError('Isolated packages changed after development.')
        (artifact / 'pip_freeze.txt').write_text(freeze)
        run([python, '-m', 'unittest', '-v', 'test_metrics', 'test_development', 'test_validation'], 'unit_tests', scripts)
        print('VALIDATION: 12 fixed conditions, each on 1449 images. Completed conditions are reused on resume.', flush=True)
        # Process all clean comparisons first, then the primary stress condition.
        state['completed_runs'] = []
        for vocabulary in ['clean', 'duplicate_bg', 'half_a', 'half_b']:
            for method in METHODS:
                condition = {'score': method['score'], 'threshold': method['threshold'], 'vocabulary': vocabulary}
                name = condition_id(method['score'], method['threshold'], vocabulary)
                output = artifact / 'conditions' / name
                config = config_dir / (name + '.py')
                write_config(repo, voc, split, vocab_dir / (vocabulary + '.txt'), condition, config)
                if completed_condition(output, condition):
                    print('RESUME: verified completion record found for ' + name, flush=True)
                else:
                    if output.exists():
                        partial = artifact / 'partial_runs'
                        partial.mkdir(exist_ok=True)
                        output.rename(partial / (name + '_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')))
                    run([python, scripts / 'run_evaluation.py', '--repo', repo, '--config', config,
                         '--output', output, '--max-previews', '2'], name, repo)
                if not completed_condition(output, condition):
                    raise RuntimeError('Incomplete validation condition: ' + name)
                result = json.loads((output / 'evaluation_report.json').read_text())
                if name == condition_id('original', 0.15, 'clean'):
                    run([python, scripts / 'analyze_validation.py', '--parity', baseline / 'val1449', output,
                         artifact / 'validation_baseline_parity.json'], 'validation_baseline_parity')
                    state['validation_baseline_parity_passed'] = True
                row = dict(condition, condition_id=name, mIoU=result['independent_metrics_percent']['mIoU'])
                state['completed_runs'].append(row)
                save_json(artifact / 'validation_report.json', state)
                print(f"VALIDATION {len(state['completed_runs'])}/12: {name} mIoU={row['mIoU']:.6f}", flush=True)
        run([python, scripts / 'analyze_validation.py', '--run-dir', artifact], 'paired_validation_analysis')
        state['ok'] = True
        exit_code = 0
    except (Exception, KeyboardInterrupt) as exc:
        state['error'] = f'{type(exc).__name__}: {exc}'
        state['traceback'] = traceback.format_exc()
        print(state['traceback'], flush=True)
    finally:
        state['attempts'][-1]['finished_utc'] = datetime.now(timezone.utc).isoformat()
        state['attempts'][-1]['ok'] = state['ok']
        save_json(artifact / 'validation_report.json', state)
        print('Packaging result ZIP. Prediction masks and audit logs may make this a large file...', flush=True)
        bundle = shutil.make_archive(str(root / ('freecp_validation_results_' + state['run_id'])), 'zip', root_dir=artifact)
        save_json(root / 'latest_validation_result.json', {'archive': bundle, 'ok': state['ok'],
                  'artifact': str(artifact), 'completed_conditions': len(state['completed_runs']),
                  'error': state.get('error'), 'package_version': 2})
        print(json.dumps({k: state.get(k) for k in ['ok', 'validation_baseline_parity_passed', 'validation_driven_tuning', 'error']}, indent=2), flush=True)
        print('RESULT_ZIP=' + bundle, flush=True)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
