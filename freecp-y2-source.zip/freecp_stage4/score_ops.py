"""Score functions only; Torch is imported inside functions for CPU-only checks."""


def original_score(x, y):
    # Exactly the released implementation, including its denominator.
    return (x * y).sum((-1, -2)) / (x.sum((-1, -2)) + y.sum((-1, -2)) + 1e-8)


def cosine_score(x, y):
    import torch.nn.functional as F
    # Float32 accumulation avoids FP16 norm underflow. Zero maps score zero.
    return F.cosine_similarity(x.float().flatten(1), y.float().flatten(1),
                               dim=1, eps=1e-8).clamp(0.0, 1.0)
