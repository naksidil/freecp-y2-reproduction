"""Protocol and scientific edge cases; Torch-specific checks also run in Colab."""
import importlib.util
import tempfile
import unittest
from pathlib import Path
import numpy as np
from protocol import vocabulary_variants, choose_threshold, GRIDS
from score_ops import original_score, cosine_score
from analyze_development import retention, comparison

VOCAB = ', '.join('bg' + str(i) for i in range(26)) + '\n' + '\n'.join('fg' + str(i) for i in range(20))


class ProtocolTests(unittest.TestCase):
    def test_foreground_ontology_unchanged(self):
        variants = vocabulary_variants(VOCAB)
        for v in variants.values():
            self.assertEqual(v['text'].splitlines()[1:], VOCAB.splitlines()[1:])
            self.assertEqual(len(v['text'].splitlines()), 21)
        self.assertEqual(variants['half_a']['num_text_queries'], 33)
        self.assertEqual(variants['duplicate_bg']['num_text_queries'], 72)

    def test_halves_complement_without_new_concepts(self):
        v = vocabulary_variants(VOCAB)
        a, b = set(v['half_a']['background_prompts']), set(v['half_b']['background_prompts'])
        self.assertFalse(a & b)
        self.assertEqual(a | b, set(v['clean']['background_prompts']))
        self.assertEqual(v, vocabulary_variants(VOCAB))

    def test_duplicate_control_restores_exact_input(self):
        v = vocabulary_variants(VOCAB)
        self.assertEqual(v['duplicate_bg']['num_background_entries'], 52)
        self.assertEqual(v['duplicate_bg']['num_unique_background_entries'], 26)
        self.assertEqual(v['clean']['sha256'], v['deduplicated_bg']['sha256'])

    def test_reject_foreground_aliases(self):
        with self.assertRaises(ValueError):
            vocabulary_variants(VOCAB.replace('fg0\n', 'fg0, extra\n'))

    def test_selection_ignores_stress_performance(self):
        rows = [dict(score='original', threshold=t, vocabulary='clean', mIoU=60 if t == .1 else 50)
                for t in GRIDS['original']]
        rows += [dict(score='original', threshold=.25, vocabulary='duplicate_bg', mIoU=100)]
        self.assertEqual(choose_threshold(rows, 'original')['threshold'], .1)

    def test_selection_requires_equal_complete_budget(self):
        rows = [dict(score='cosine', threshold=t, vocabulary='clean', mIoU=50) for t in GRIDS['cosine']]
        self.assertEqual(choose_threshold(rows, 'cosine')['threshold'], .9)
        with self.assertRaises(ValueError):
            choose_threshold(rows[:-1], 'cosine')
        with self.assertRaises(ValueError):
            choose_threshold(rows + rows[:1], 'cosine')

    def test_keep_all_is_flagged_by_false_retention(self):
        result = retention([{'rp_kept_class_ids_union': list(range(1, 21)),
                             'gt_present_foreground_class_ids': [1, 2]}])
        self.assertEqual(result['image_class_presence_recall_percent'], 100)
        self.assertEqual(result['image_absent_class_retention_percent'], 100)

    def test_original_score_uniform_amplitude_sensitivity(self):
        x = np.array([[[.9, .8], [.2, .1]]])
        y = np.array([[[1., .75], [.125, 0.]]])
        self.assertGreater(float(original_score(x, y)[0]), .15)
        self.assertLess(float(original_score(x / 8, y)[0]), .15)

    def test_paired_stability_denominators_and_void_ignore(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for subdir in ['SegmentationClass', 'clean/figures', 'changed/figures']:
                (root / subdir).mkdir(parents=True)
            Image.fromarray(np.array([[1, 255]], dtype='uint8')).save(root / 'SegmentationClass/example.png')
            Image.fromarray(np.array([[1, 0]], dtype='uint8')).save(root / 'clean/figures/example_prediction.png')
            Image.fromarray(np.array([[1, 1]], dtype='uint8')).save(root / 'changed/figures/example_prediction.png')
            common = dict(image_id='example', image_sha256='same-image', gt_sha256='same-GT')
            a = dict(common, rp_kept_class_ids_union=[1],
                     rp_audit=[dict(crop_index=0, grid_hw=[1, 2], kept_voc_class_ids=[1])])
            b = dict(common, rp_kept_class_ids_union=[1, 2],
                     rp_audit=[dict(crop_index=0, grid_hw=[1, 2], kept_voc_class_ids=[1, 2])])
            clean = dict(per_image=[a], dataset_manifest={'data_root': str(root)})
            changed = dict(per_image=[b])
            result = comparison(root/'clean', root/'changed', clean, changed)
            self.assertEqual(result['image_union_decision_flip_percent'], 5.)
            self.assertEqual(result['crop_decision_flip_percent'], 5.)
            self.assertEqual(result['valid_pixel_prediction_disagreement_percent'], 0.)
            b['image_sha256'] = 'different-image'
            with self.assertRaises(ValueError):
                comparison(root/'clean', root/'changed', clean, changed)


@unittest.skipUnless(importlib.util.find_spec('torch') is not None, 'Torch checks execute in the Colab environment')
class TorchScoreTests(unittest.TestCase):
    def test_scale_invariance_and_zero_maps(self):
        import torch
        x = torch.tensor([[[.9, .8], [.2, .1]], [[0., 0.], [0., 0.]]], dtype=torch.float16)
        y = torch.tensor([[[1., .75], [.125, 0.]], [[1., 0.], [0., 0.]]], dtype=torch.float32)
        a, b = cosine_score(x, y), cosine_score(x / 8, y * 3)
        torch.testing.assert_close(a, b, atol=1e-6, rtol=1e-5)
        self.assertEqual(a[1].item(), 0.)
        self.assertTrue(bool(torch.isfinite(a).all()))

    def test_identical_and_disjoint_patterns(self):
        import torch
        x = torch.tensor([[[1., 0.], [0., 0.]], [[1., 0.], [0., 0.]]])
        y = torch.tensor([[[2., 0.], [0., 0.]], [[0., 1.], [0., 0.]]])
        torch.testing.assert_close(cosine_score(x, y), torch.tensor([1., 0.]))

    def test_original_cpu_and_cuda_threshold_agree(self):
        import torch
        x = torch.tensor([[[.9, .8], [.2, .1]]], dtype=torch.float16)
        y = torch.tensor([[[1., .75], [.125, 0.]]])
        self.assertTrue(bool((original_score(x, y) > .15).item()))
        self.assertFalse(bool((original_score(x / 8, y) > .15).item()))
        if torch.cuda.is_available():
            torch.testing.assert_close(cosine_score(x.cuda(), y.cuda()).cpu(), cosine_score(x, y))


if __name__ == '__main__':
    unittest.main(verbosity=2)
