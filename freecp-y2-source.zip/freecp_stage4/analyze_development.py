"""Compare aligned development runs; no threshold selection on stress results."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image
from stage2_helpers import save_json
from protocol import condition_id, PERTURBATIONS


def check_parity(previous, current, output):
    previous, current = Path(previous), Path(current)
    old = json.loads((previous / 'evaluation_report.json').read_text())
    new = json.loads((current / 'evaluation_report.json').read_text())
    a, b = np.load(previous / 'per_image_confusions.npz'), np.load(current / 'per_image_confusions.npz')
    if not old['ok'] or not new['ok'] or not np.array_equal(a['image_ids'], b['image_ids']):
        raise RuntimeError('Baseline parity: incomplete run or image order mismatch.')
    differing_pixels = 0
    for old_row, new_row in zip(old['per_image'], new['per_image']):
        if any(old_row[k] != new_row[k] for k in ['image_id', 'image_sha256', 'gt_sha256']):
            raise RuntimeError('Baseline parity: image/annotation provenance mismatch.')
        name = old_row['image_id'] + '_prediction.png'
        old_mask = np.array(Image.open(previous / 'figures' / name))
        new_mask = np.array(Image.open(current / 'figures' / name))
        if old_mask.shape != new_mask.shape:
            raise RuntimeError('Baseline parity: spatial shape mismatch.')
        differing_pixels += int(np.count_nonzero(old_mask != new_mask))
    matrices_equal = bool(np.array_equal(a['confusion_matrices'], b['confusion_matrices']))
    result = {'ok': differing_pixels == 0 and matrices_equal, 'images': len(a['image_ids']),
              'differing_prediction_pixels': differing_pixels, 'confusions_exactly_equal': matrices_equal,
              'previous_mIoU': old['independent_metrics_percent']['mIoU'],
              'current_mIoU': new['independent_metrics_percent']['mIoU'],
              'note': 'Exact parity is required before threshold selection; inspect failures rather than relax silently.'}
    save_json(output, result)
    if not result['ok']:
        raise RuntimeError('Instrumented baseline differs from stage 3. Stop and share result ZIP for inspection.')


def retention(rows):
    true_kept = present_count = false_kept = absent_count = total_kept = 0
    for row in rows:
        kept, present = set(row['rp_kept_class_ids_union']), set(row['gt_present_foreground_class_ids'])
        true_kept += len(kept & present)
        present_count += len(present)
        false_kept += len(kept - present)
        absent_count += 20 - len(present)
        total_kept += len(kept)
    return {'image_class_presence_recall_percent': 100 * true_kept / present_count if present_count else None,
            'image_absent_class_retention_percent': 100 * false_kept / absent_count if absent_count else None,
            'mean_RP_kept_foreground_classes_union': total_kept / len(rows)}


def comparison(clean_dir, changed_dir, clean, changed):
    union_flips = crop_flips = crop_decisions = changed_pixels = valid_pixels = 0
    if len(clean['per_image']) != len(changed['per_image']):
        raise ValueError('Unpaired image counts.')
    for a, b in zip(clean['per_image'], changed['per_image']):
        if any(a[k] != b[k] for k in ['image_id', 'image_sha256', 'gt_sha256']):
            raise ValueError('Unpaired inputs.')
        union_flips += len(set(a['rp_kept_class_ids_union']) ^ set(b['rp_kept_class_ids_union']))
        if len(a['rp_audit']) != len(b['rp_audit']):
            raise ValueError('Crop counts differ.')
        for x, y in zip(a['rp_audit'], b['rp_audit']):
            if x['crop_index'] != y['crop_index'] or x['grid_hw'] != y['grid_hw']:
                raise ValueError('Crop alignment differs.')
            crop_flips += len(set(x['kept_voc_class_ids']) ^ set(y['kept_voc_class_ids']))
            crop_decisions += 20
        name = a['image_id'] + '_prediction.png'
        mask_a = np.array(Image.open(clean_dir / 'figures' / name))
        mask_b = np.array(Image.open(changed_dir / 'figures' / name))
        gt_path = Path(clean['dataset_manifest']['data_root']) / 'SegmentationClass' / (a['image_id'] + '.png')
        gt = np.array(Image.open(gt_path))
        valid = gt != 255
        if mask_a.shape != mask_b.shape or mask_a.shape != gt.shape:
            raise ValueError('Unpaired prediction shapes.')
        changed_pixels += int(np.count_nonzero((mask_a != mask_b) & valid))
        valid_pixels += int(np.count_nonzero(valid))
    return {'image_union_decision_flip_percent': 100 * union_flips / (20 * len(clean['per_image'])),
            'crop_decision_flip_percent': 100 * crop_flips / crop_decisions,
            'valid_pixel_prediction_disagreement_percent': 100 * changed_pixels / valid_pixels}


def analyze(run_dir):
    run_dir = Path(run_dir)
    selection = json.loads((run_dir / 'selection.json').read_text())
    records = []
    for method in selection['methods']:
        clean_dir = run_dir / 'conditions' / condition_id(method['score'], method['threshold'], 'clean')
        clean = json.loads((clean_dir / 'evaluation_report.json').read_text())
        for vocabulary in ['clean'] + PERTURBATIONS:
            path = run_dir / 'conditions' / condition_id(method['score'], method['threshold'], vocabulary)
            report = json.loads((path / 'evaluation_report.json').read_text())
            if not report['ok']:
                raise ValueError('Incomplete condition.')
            row = {'method': method['name'], 'score': method['score'], 'threshold': method['threshold'],
                   'vocabulary': vocabulary, 'mIoU': report['independent_metrics_percent']['mIoU'],
                   'mIoU_change_from_clean_points': report['independent_metrics_percent']['mIoU'] - clean['independent_metrics_percent']['mIoU'],
                   'peak_allocated_gpu_gib': report['peak_allocated_gpu_gib'],
                   'mean_audited_unwarmed_step_seconds': float(np.mean([x['unwarmed_test_step_seconds'] for x in report['per_image']]))}
            row.update(retention(report['per_image']))
            row.update(comparison(clean_dir, path, clean, report))
            records.append(row)
    with (run_dir / 'development_summary.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    save_json(run_dir / 'development_summary.json', {
        'ok': True, 'split': 'train50', 'records': records,
        'interpretation': 'Development evidence only; no claim of held-out improvement or novelty.',
        'RP_retention_definition': 'Union of RP-kept classes across all crops in an image, BEFORE AP. Recall/false retention are image-class micro rates, not pixel recall.',
        'keep_all_warning': 'Zero decision flips alone is not success: keeping all classes can be perfectly stable.',
        'duplicate_control': 'Deduplicate input before model: exactly the clean input; clean output is reused, not separately measured.',
        'timing_warning': 'Audit synchronizes and copies tensors. These timings are not formal method latency.'})


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--run-dir')
    p.add_argument('--parity', nargs=3, metavar=('PREVIOUS', 'CURRENT', 'OUTPUT'))
    a = p.parse_args()
    if a.parity:
        check_parity(*a.parity)
    elif a.run_dir:
        analyze(a.run_dir)
    else:
        p.error('Specify --run-dir or --parity.')
