"""Precommitted development protocol. No validation-driven selection."""
from __future__ import annotations
import hashlib
import random

SEED = 5110
TRAIN50_SHA256 = '4f991c55bd461523a92888da6d3c871ebe9cd0d5a93de3522115ec90f055bad8'
GRIDS = {'original': [0.05, 0.10, 0.15, 0.20, 0.25],
         'cosine': [0.30, 0.45, 0.60, 0.75, 0.90]}
PERTURBATIONS = ['half_a', 'half_b', 'duplicate_bg']


def vocabulary_variants(text):
    lines = text.strip().splitlines()
    if len(lines) != 21 or any(', ' in line for line in lines[1:]):
        raise ValueError('Expected 21 semantic rows with exactly one name per foreground class.')
    background = lines[0].split(', ')
    if len(background) != 26 or len(set(background)) != 26:
        raise ValueError('Expected the pinned 26 unique background prompts.')
    subset = set(random.Random(SEED).sample(range(26), 13))
    groups = {'clean': background,
              'half_a': [s for i, s in enumerate(background) if i in subset],
              'half_b': [s for i, s in enumerate(background) if i not in subset],
              'duplicate_bg': background + background}
    groups['deduplicated_bg'] = list(dict.fromkeys(groups['duplicate_bg']))
    result = {}
    for name, words in groups.items():
        content = '\n'.join([', '.join(words)] + lines[1:]) + '\n'
        result[name] = {'text': content, 'background_prompts': words,
                        'num_background_entries': len(words),
                        'num_unique_background_entries': len(set(words)),
                        'num_text_queries': len(words) + 20,
                        'semantic_classes': 21,
                        'sha256': hashlib.sha256(content.encode()).hexdigest()}
    assert result['clean']['text'] == result['deduplicated_bg']['text']
    return result


def choose_threshold(rows, score):
    """Highest clean-train mIoU; exact ties use the higher threshold."""
    candidates = [r for r in rows if r['score'] == score and r['vocabulary'] == 'clean']
    if sorted(r['threshold'] for r in candidates) != GRIDS[score]:
        raise ValueError('Selection requires each of the five precommitted clean-training runs.')
    return max(candidates, key=lambda r: (r['mIoU'], r['threshold']))


def condition_id(score, threshold, vocabulary):
    return f'{score}_{threshold:.2f}_{vocabulary}'.replace('.', 'p')


def experiment_protocol():
    return {
        'version': 1, 'seed': SEED, 'source_split': 'train', 'n_images': 50,
        'train50_sha256': TRAIN50_SHA256,
        'question': 'Does scale-normalized RP reduce sensitivity to background prompt composition/multiplicity while retaining segmentation quality?',
        'intervention': 'Only the redundancy-purification similarity score changes to spatial cosine similarity; AP stays at 0.8.',
        'threshold_grids': GRIDS,
        'selection_rule': 'Maximize unrounded clean train50 mIoU separately for each score. Exact ties: higher threshold. Freeze before perturbation runs.',
        'comparisons': ['original RP 0.15', 'original RP with selected threshold', 'cosine RP with selected threshold'],
        'vocabularies': ['clean'] + PERTURBATIONS,
        'duplicate_control': 'Exact deduplication restores clean input byte-for-byte; reuse clean predictions, with input hash proof. This is not a separate measured run.',
        'primary_development_outcome': 'mIoU for each method/vocabulary and change relative to the same method on clean vocabulary.',
        'secondary_outcomes': ['RP class-decision flips per crop', 'image-level RP foreground recall',
                               'image-level RP absent-class retention', 'pixel prediction disagreement', 'peak allocated GPU memory'],
        'limits': ['Exploratory development on only 50 training images.',
                   'Uniform positive map scaling invariance does not guarantee invariance to pixel-dependent softmax changes.',
                   'Half vocabularies alter background semantic coverage; duplicate vocabulary only changes multiplicity.',
                   'Cosine similarity itself is established, not claimed novel.',
                   'No validation evaluation or model selection is performed by this package.',
                   'Auditing adds CPU transfers and synchronization; recorded timings are not formal latency benchmarks.'],
        'validation_policy': 'Lock thresholds and conditions now. Evaluate all three methods on full validation later; report all conditions, including unfavorable results. Do not retune after inspecting validation.',
    }
