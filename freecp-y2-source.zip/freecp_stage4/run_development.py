"""Continue in the existing T4 VM. Development only; never evaluate validation."""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from stage2_helpers import UPSTREAM_SHA, BPE_GIT_BLOB_SHA, digest, git_blob_sha, run_logged, save_json
from protocol import (SEED, TRAIN50_SHA256, GRIDS, PERTURBATIONS, choose_threshold,
                      condition_id, experiment_protocol, vocabulary_variants)


def find_baseline(root):
    for path in sorted((root / 'runs').glob('baseline_*/continuation_report.json'), reverse=True):
        try:
            state = json.loads(path.read_text())
            report = json.loads((path.parent / 'train50/evaluation_report.json').read_text())
            if (state.get('ok') is True and report.get('ok') is True
                    and report.get('upstream_commit') == UPSTREAM_SHA
                    and report['dataset_manifest']['split_sha256'] == TRAIN50_SHA256
                    and report['dataset_manifest']['source_split'] == 'train'
                    and report.get('real_images_evaluated') == 50):
                return path.parent
        except (OSError, ValueError, KeyError):
            continue
    raise RuntimeError('Successful stage 03 is missing from this VM. Do not reinstall or change packages blindly; share this result ZIP.')


def write_config(repo, voc, split, vocabulary, condition, output):
    config = (
        f'_base_ = {str(repo / "configs/cfg_voc21.py")!r}\n'
        'model = dict(type="AuditedFreeCPSegmentation", model_type="SCLIP", '
        f'rp_score={condition["score"]!r}, rp_thres={condition["threshold"]!r}, ap_thres=0.8, '
        f'name_path={str(vocabulary)!r})\n'
        'test_dataloader = dict(num_workers=0, persistent_workers=False, '
        f'dataset=dict(data_root={str(voc)!r}, ann_file={str(split)!r}))\n'
    )
    output.write_text(config, encoding='utf-8')
    save_json(output.with_suffix('.manifest.json'), {
        'upstream_commit': UPSTREAM_SHA, 'mode': 'pilot', 'source_split': 'train',
        'dataset': 'VOC21', 'n_images': 50, 'sampling_seed': SEED,
        'split_sha256': digest(split), 'data_root': str(voc), 'config': str(output),
        'vocabulary_sha256': digest(vocabulary), 'condition': condition})


def main(root=Path('/content/freecp_t4')):
    root = Path(root).resolve()
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    artifact = root / 'runs' / ('development_' + run_id)
    artifact.mkdir(parents=True, exist_ok=False)
    state = {'ok': False, 'run_id': run_id, 'stage': 'train50_development',
             'validation_evaluated': False, 'thresholds_locked': False,
             'heldout_improvement_demonstrated': False, 'novelty_established': False,
             'completed_runs': []}
    exit_code = 1
    try:
        scripts = artifact / 'scripts'
        scripts.mkdir()
        for path in Path(__file__).resolve().parent.iterdir():
            if path.is_file() and path.suffix in {'.py', '.md', '.txt', '.json'}:
                shutil.copy2(path, scripts / path.name)
        save_json(artifact / 'protocol.json', experiment_protocol())
        repo, python, voc = root / 'FreeCP', root / 'env_py310/bin/python', root / 'data/VOCdevkit/VOC2012'
        for path in [python, repo / 'configs/cls_voc21.txt', voc / 'ImageSets/Segmentation/train.txt']:
            if not path.exists():
                raise FileNotFoundError(f'{path} is missing. This package requires the live stage-02/03 VM.')
        previous = find_baseline(root)
        state['previous_baseline'] = str(previous)
        evidence = artifact / 'baseline_evidence'
        evidence.mkdir()
        for source, name in [(previous / 'train50/evaluation_report.json', 'train50_report.json'),
                             (previous / 'train50/per_image_confusions.npz', 'train50_confusions.npz'),
                             (previous / 'train50_config.split.txt', 'train50.split.txt'),
                             (previous / 'pip_freeze.txt', 'pip_freeze.txt')]:
            shutil.copy2(source, evidence / name)
        if (previous / 'licenses').is_dir():
            shutil.copytree(previous / 'licenses', artifact / 'licenses')
        split = evidence / 'train50.split.txt'
        if digest(split) != TRAIN50_SHA256:
            raise RuntimeError('Development split differs from the reviewed stage-03 split.')
        train_ids = set((voc / 'ImageSets/Segmentation/train.txt').read_text().split())
        val_ids = set((voc / 'ImageSets/Segmentation/val.txt').read_text().split())
        dev_ids = split.read_text().split()
        if len(dev_ids) != 50 or len(set(dev_ids)) != 50 or not set(dev_ids) <= train_ids or set(dev_ids) & val_ids:
            raise RuntimeError('Development IDs are not a disjoint 50-image training subset.')
        if git_blob_sha(repo / 'open_clip/bpe_simple_vocab_16e6.txt.gz') != BPE_GIT_BLOB_SHA:
            raise RuntimeError('Tokenizer provenance check failed.')
        env = os.environ.copy()
        env['MPLBACKEND'], env['TOKENIZERS_PARALLELISM'] = 'Agg', 'false'

        def run(command, label, cwd=None):
            run_logged(command, label, artifact, cwd=cwd, env=env)

        run([python, scripts / 'check_runtime.py', repo, artifact / 'runtime_report.json'], 'runtime_recheck', repo)
        freeze = subprocess.check_output([str(python), '-m', 'pip', 'freeze'], text=True, env=env)
        (artifact / 'pip_freeze.txt').write_text(freeze)
        if set(freeze.splitlines()) != set((evidence / 'pip_freeze.txt').read_text().splitlines()):
            raise RuntimeError('Dependencies differ from the reproduced baseline.')
        run([python, '-m', 'unittest', '-v', 'test_metrics', 'test_development'], 'unit_tests', scripts)
        vocabularies = vocabulary_variants((repo / 'configs/cls_voc21.txt').read_text())
        vocab_dir, config_dir = artifact / 'vocabularies', artifact / 'configs'
        vocab_dir.mkdir()
        config_dir.mkdir()
        for name, info in vocabularies.items():
            (vocab_dir / (name + '.txt')).write_text(info['text'], encoding='utf-8')
        save_json(artifact / 'vocabulary_manifest.json', vocabularies)
        save_json(artifact / 'deduplication_control.json', {
            'input': 'duplicate_bg', 'operation': 'stable exact-string deduplication of background row',
            'clean_sha256': vocabularies['clean']['sha256'],
            'deduplicated_sha256': vocabularies['deduplicated_bg']['sha256'],
            'input_equality_verified': True,
            'prediction_source': 'Reuse each method clean run; NOT a separately timed/measured experiment.'})
        records = []
        cache = {}

        def evaluate(score, threshold, vocabulary):
            name = condition_id(score, threshold, vocabulary)
            if name in cache:
                return cache[name]
            config = config_dir / (name + '.py')
            condition = {'score': score, 'threshold': threshold, 'vocabulary': vocabulary}
            write_config(repo, voc, split, vocab_dir / (vocabulary + '.txt'), condition, config)
            output = artifact / 'conditions' / name
            run([python, scripts / 'run_evaluation.py', '--repo', repo, '--config', config,
                 '--output', output, '--max-previews', '2'], name, repo)
            result = json.loads((output / 'evaluation_report.json').read_text())
            if not result.get('ok') or result.get('real_images_evaluated') != 50:
                raise RuntimeError(f'Incomplete condition: {name}')
            row = dict(condition, mIoU=result['independent_metrics_percent']['mIoU'],
                       run_directory=str(output), condition_id=name)
            records.append(row)
            cache[name] = row
            state['completed_runs'].append(row)
            save_json(artifact / 'development_report.json', state)
            print(f"DEVELOPMENT {name}: mIoU={row['mIoU']:.6f}", flush=True)
            return row

        # Audit instrumentation must first recover every original predicted pixel.
        reference = evaluate('original', 0.15, 'clean')
        run([python, scripts / 'analyze_development.py', '--parity', previous / 'train50',
             reference['run_directory'], artifact / 'baseline_parity.json'], 'baseline_parity')
        state['baseline_parity_passed'] = True
        for score, grid in GRIDS.items():
            for threshold in grid:
                evaluate(score, threshold, 'clean')
        selected = {score: choose_threshold(records, score) for score in GRIDS}
        selection = {
            'locked_at_utc': datetime.now(timezone.utc).isoformat(),
            'selection_source': 'clean_train50_only', 'protocol_sha256': digest(artifact / 'protocol.json'),
            'rule': experiment_protocol()['selection_rule'],
            'calibration_runs': records.copy(),
            'methods': [
                {'name': 'released_original', 'score': 'original', 'threshold': 0.15},
                {'name': 'retuned_original', 'score': 'original', 'threshold': selected['original']['threshold']},
                {'name': 'cosine_RP', 'score': 'cosine', 'threshold': selected['cosine']['threshold']}],
            'note': 'Selection frozen before any perturbed-vocabulary evaluation. Shared identical conditions reuse the same predictions.'}
        save_json(artifact / 'selection.json', selection)
        selection_hash = digest(artifact / 'selection.json')
        state['thresholds_locked'] = True
        state['selection_sha256'] = selection_hash
        save_json(artifact / 'locked_validation_plan.json', {
            'status': 'planned_not_run', 'selection_sha256': selection_hash,
            'methods': selection['methods'], 'vocabularies': ['clean'] + PERTURBATIONS,
            'split': 'all_1449_VOC2012_validation_images',
            'primary_endpoint': 'Paired difference in mIoU change from clean, cosine RP versus retuned original RP, for duplicate_bg; also report clean quality cost.',
            'secondary_endpoints': 'Both half-vocabulary conditions, original 0.15 comparison, RP flips, recall, false retention, memory.',
            'reporting_rule': 'Report all predeclared conditions; no validation-driven retuning or selective reporting.',
            'deduplication_control': 'Duplicate input with exact deduplication equals clean input and reuses its predictions.',
            'uncertainty': 'Use paired image bootstrap on saved per-image confusion matrices; not a claim about training seeds.',
            'caveat': 'Validation baseline has already been inspected for reproduction; it is not a pristine blind test. Additional independent data would strengthen publication claims.'})
        for method in selection['methods']:
            for vocabulary in PERTURBATIONS:
                evaluate(method['score'], method['threshold'], vocabulary)
        if digest(artifact / 'selection.json') != selection_hash:
            raise RuntimeError('Selection changed after locking.')
        run([python, scripts / 'analyze_development.py', '--run-dir', artifact], 'development_analysis')
        state['ok'] = True
        exit_code = 0
    except Exception as exc:
        state['error'] = f'{type(exc).__name__}: {exc}'
        state['traceback'] = traceback.format_exc()
        print(state['traceback'], flush=True)
    finally:
        save_json(artifact / 'development_report.json', state)
        bundle = shutil.make_archive(str(root / ('freecp_development_results_' + run_id)), 'zip', root_dir=artifact)
        save_json(root / 'latest_development_result.json', {'archive': bundle, 'ok': state['ok'], 'run_id': run_id})
        print(json.dumps({k: state.get(k) for k in ['ok', 'baseline_parity_passed', 'thresholds_locked', 'validation_evaluated', 'error']}, indent=2), flush=True)
        print('RESULT_ZIP=' + bundle, flush=True)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
