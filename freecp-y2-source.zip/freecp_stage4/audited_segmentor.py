"""External subclass: no edits to the pinned FreeCP repository."""
import torch
from mmseg.registry import MODELS
from freecp_segmentor import FreeCPSegmentation
from score_ops import original_score, cosine_score


@MODELS.register_module()
class AuditedFreeCPSegmentation(FreeCPSegmentation):
    def __init__(self, rp_score='original', **kwargs):
        if rp_score not in {'original', 'cosine'}:
            raise ValueError('Unknown RP score.')
        self.rp_score = rp_score
        self.rp_audit = []
        super().__init__(**kwargs)
        if self.num_classes != 21 or self.num_queries - self.num_bkg_prompts != 20:
            raise ValueError('This experiment requires the unchanged VOC21 foreground ontology.')
        if not self.with_bkg or self.ignore_bkg:
            raise ValueError('The experiment requires the released VOC21 background configuration.')

    @torch.no_grad()
    def predict(self, inputs, data_samples):
        if len(data_samples) != 1:
            raise ValueError('Auditing requires batch size 1.')
        self.rp_audit = []
        outputs = super().predict(inputs, data_samples)
        outputs[0].set_metainfo({'rp_audit': self.rp_audit})
        return outputs

    def redundancy_purification(self, logits, logits_ref):
        x = logits[0, self.num_bkg_prompts:]
        y = logits_ref[0, self.num_bkg_prompts:]
        if x.shape != y.shape or x.shape[0] != 20:
            raise ValueError('Unexpected foreground map shape.')
        score = original_score(x, y) if self.rp_score == 'original' else cosine_score(x, y)
        if not bool(torch.isfinite(score).all()):
            raise ValueError('Non-finite RP score; stop rather than hide it.')
        if self.rp_score == 'original':
            # Delegate to unchanged source; audit must be observational only.
            logits_ref, candidates = super().redundancy_purification(logits, logits_ref)
        else:
            candidates = torch.where(score > self.rp_thres)[0]
            for i in range(self.num_bkg_prompts, logits_ref.shape[1]):
                if i - self.num_bkg_prompts not in candidates:
                    logits_ref[:, i] = logits_ref[:, i] * 0.0
        self.rp_audit.append({
            'crop_index': len(self.rp_audit), 'grid_hw': list(x.shape[-2:]),
            'scores': score.detach().float().cpu().tolist(),
            'raw_map_mean': x.detach().float().mean((-1, -2)).cpu().tolist(),
            'kept_voc_class_ids': (candidates + 1).detach().cpu().tolist(),
        })
        return logits_ref, candidates
