# 04 — FreeCP: küçük değişiklik ve geliştirme deneyi

Bu paket, **03 ile tamamlanmış aynı Colab T4 oturumunda** çalışır. Yeni model eğitmez, API anahtarı istemez, ücretli LLM çağrısı yapmaz. FreeCP'nin depoda bulunan hazır metin açıklamalarını kullanır.

## Şu anda neredeyiz?

VOC2012'nin 1.449 doğrulama görüntüsünde SCLIP + FreeCP sonucumuz **%65,7633 mIoU**. Makaledeki **%65,8** ile bir ondalık basamakta uyuşuyor. Bu, seçtiğimiz VOC21 sonucunun yeniden üretimidir; bütün makalenin veya yeni önerinin doğrulanması değildir.

Şimdi bir araştırma sorusunu test ediyoruz: **Arka planı tanımlayan aday kelimeler değiştiğinde, sınıf eleme kararlarını daha kararlı hâle getirebilir miyiz?**

## Tek müdahale

FreeCP önce ham sınıf haritası X'i, sonra iyileştirilmiş harita Y'yi hesaplıyor. RP, bir sınıfı elemeden önce bu haritaları karşılaştırıyor.

- Resmî kod: `sum(X*Y) / (sum(X) + sum(Y) + 1e-8)`.
- Deney: `cosine_similarity(flatten(X), flatten(Y))`, float32, epsilon `1e-8`, aralık `[0,1]`.

Yeni skor, sıfır olmayan haritaların **tek bir pozitif katsayıyla ölçeklenmesine** karşı kararlıdır (sayısal epsilon sınırları dışında). Ama kelime listesi değişince softmax her pikseli farklı etkileyebilir; dolayısıyla gerçek görüntülerde başarı veya kelime listesine tam değişmezlik garanti edilmez. Düşük güvenli yanlış sınıfları da koruyabilir. Bunu ölçüyoruz.

AP, model ağırlıkları, görüntü boyutlandırma, kırpma, nesne sınıfları ve veri bölünmesi aynı kalır. Orijinal skor koşullarında üst sınıfın değişmemiş RP fonksiyonu çağrılır. Resmî kaynak dosyaları değiştirilmez. Makaledeki denklem ile yayımlanan kodun paydası arasında farklılık bulunduğundan yeniden ürettiğimiz **kod tanımını** koruyoruz; bu deney o farkı düzeltme deneyi değildir.

## Adil karşılaştırma

| Yöntem | Ne değişiyor? |
| --- | --- |
| Yayımlanan ayar | Orijinal RP, eşik 0,15 |
| Eşik kontrolü | Orijinal RP; eşik eğitim görüntülerinde seçiliyor |
| Önerimiz | Kosinüs RP; eşik aynı eğitim görüntülerinde seçiliyor |

Her skor için **5 aday eşik** var. Orijinal: `0.05, 0.10, 0.15, 0.20, 0.25`; kosinüs: `0.30, 0.45, 0.60, 0.75, 0.90`. İki skorun sayısal ölçekleri farklıdır. Bunlar önceden belirlenmiş kaba aramalardır, kapsamlı optimum araması değildir. Aynı 50 eğitim görüntüsündeki en yüksek yuvarlanmamış mIoU seçilir. Tam eşitlikte daha yüksek eşik seçilir. En iyi eşik aralığın ucunda kalırsa bu bir sınırlama olarak raporlanır; paket aralığı sonuçlara göre genişletmez.

**Seçim yalnızca özgün kelime listesinde yapılır.** `selection.json` yazıldıktan sonra bozulmuş listeler denenir; eşikler değiştirilmez. Orijinal yöntemin en iyi eşiği yine 0,15 olursa iki kontrol aynıdır ve aynı sonuç yeniden kullanılır.

## Kelime listesi deneyi

VOC21'de 21 semantik sınıf vardır: arka plan + 20 nesne sınıfı. Depodaki arka plan satırı 26 ayrı kelime içerir. Nesne sınıflarının adlarını ve sırasını değiştirmiyoruz.

| Koşul | Arka plan girdisi | Toplam metin adayı | Anlamı |
| --- | ---: | ---: | --- |
| clean | 26 | 46 | Özgün liste |
| half_a | 13 | 33 | Sabit tohumla seçilmiş yarı |
| half_b | 13 | 33 | Diğer yarı |
| duplicate_bg | 52 | 72 | Aynı 26 kelimenin iki kez yazılması |

İki yarı, anlamsal kapsamı değiştirir. Tekrar koşulu yeni nesne veya yeni kavram eklemez; adayların çokluğunu değiştirir. Sonuçlarımızı genel olarak bütün açık sözlüklü segmentasyon koşullarına yayamayız.

Tekrarlı girdiyi **birebir aynı kelimeleri silerek temizlemek**, özgün listeyi aynen geri getirir. Bu basit kontrolün girdileri SHA256 ile eşitlenir ve özgün koşulun ölçümü yeniden kullanılır. Bu kontrol ayrıca çalıştırılmış veya zamanlanmış gibi raporlanmaz. Yeni skorun gerekli veya üstün olduğu iddiası bu kontrol göz ardı edilerek kurulamaz.

## Paket hangi sırada çalışır?

1. Önceki 03 çalışmasını, paket sürümlerini, kaynak revizyonunu, tokenizer dosyasını ve aynı 50 eğitim görüntüsünü kontrol eder.
2. Orijinal yöntemi kayıt tutan sürümle çalıştırır. Önceki 50 görüntünün **her tahmin pikseli ve karışıklık matrisi** aynı olmalıdır. Fark varsa durur ve farkı raporlar.
3. İki skor için toplam 10 temiz koşuldan eşikleri seçer.
4. Seçimi kilitler; 3 yöntem × 3 kelime değişikliğini çalıştırır. Aynı koşulları tekrar etmez. Toplam 16–19 farklı 50 görüntülük çalışma olur.
5. `development_summary.csv`, `development_summary.json`, her koşulun tahminleri, skorları, kaynakları ve deney kayıtlarını ZIP'e koyar.

T4'te önceki 50 görüntü yaklaşık 31 saniyeydi. Bu pakette daha çok kayıt ve tekrar var; **yaklaşık 15–30 dakika ayır**, süre garanti değildir. Aynı oturumda veri veya model yeniden indirilmez. Konsolda her 50 görüntü tamamlandığında ve her koşul sonunda ilerleme görünür.

## Nasıl çalıştırılır?

1. `04_FreeCP_Kucuk_Degisiklik_ve_Gelistirme.zip` dosyasını bilgisayarına indir. ZIP'in içindeki `COLAB_BASLAT.txt` metnini aç.
2. **03'ü çalıştırdığın aynı 02 Colab not defterinde**, en alta yeni kod hücresi ekle. Mevcut kurulumu silme veya tüm hücreleri yeniden çalıştırma.
3. `COLAB_BASLAT.txt` içeriğini hücreye yapıştır ve çalıştır.
4. Dosya seçici açıldığında **04 ile başlayan ZIP'i** yükle. Sonuç ZIP'ini değil.
5. Bittiğinde indirilen `freecp_development_results_....zip` dosyasını paylaş. Hata olsa da oluşan ZIP'i paylaş; başarılı olmuş varsayma.

Colab sanal makinesi sıfırlandıysa gerekli dosyalar kaybolmuş olabilir. Paket bu durumda durur. Yeniden kurulumun veya önceki sonuçlardan kurtarmanın planlanması gerekir; bu paket tek başına kurulum yapmaz.

## Sonuçları nasıl okuyacağız?

- **mIoU:** Her yöntem ve her listede segmentasyon kalitesi. Eğitim sonucunu makalenin doğrulama sonucuyla karşılaştırma.
- **Temiz listeye göre fark:** Kelime değişikliğinin kaliteye etkisi. Sadece farkın küçülmesi yetmez; temiz koşulun mutlak kalitesi de korunmalıdır.
- **RP karar değişimi:** Aynı görüntünün aynı kırpmasında 20 sınıfın tut/ele kararlarının yüzde kaçı değişiyor?
- **Görüntü düzeyinde sınıf koruma:** Herhangi bir kırpmada RP'nin tuttuğu sınıfların birleşimi. Görüntüde gerçekten olan sınıfların korunma oranını ve olmayanların yanlış tutulma oranını birlikte inceleriz. Bu, piksel recall değildir; AP'den önce ölçülür.
- **Tahmin pikseli değişimi:** Ignore=255 dışındaki geçerli piksellerde temiz ve değişmiş liste tahminlerinin anlaşmazlığı.
- **Kaynak kullanımı:** PyTorch'un tepe ayrılmış GPU belleği kaydedilir; toplam ekran kartı kullanımı değildir. Sürelere ayrıntılı kayıt/senkronizasyon dahildir; bunlardan yöntem hızlanması iddia edilmez. Nihai hız karşılaştırması gerekiyorsa kayıt kapalı, ısınmalı ayrı ölçüm yapılmalı.

Hiçbir sınıfı elemeyen yöntem çok kararlı görünebilir. Bu yüzden karar kararlılığı tek başına başarı sayılmaz. Kosinüs benzerliği bilinen bir ölçüttür; yöntemin veya bu uygulamasının özgünlüğü henüz literatürle doğrulanmış değildir.

## Sonraki aşama

Sonuçları kontrol ettikten sonra kilitlenen üç yöntemi 1.449 doğrulama görüntüsünde ve aynı liste koşullarında karşılaştıracağız. Paket bu planı `locked_validation_plan.json` içine yazar fakat **doğrulama deneyi çalıştırmaz**. Eşikleri doğrulama sonucuna bakarak değiştirmeyeceğiz. Kalite artmazsa bunu da raporlayacağız. Yeniden üretim sırasında doğrulama başlangıç puanını zaten gördük; tamamen kör bir testmiş gibi sunmayacağız. Konferans düzeyindeki iddialar için ek veri ve daha geniş deneyler gerekebilir.

Araştırma raporunda bu kodun ve deney tasarımının yapay zekâ yardımıyla hazırlandığını belirt. Çalıştırılan kodları ve sonuçları incelemek, yorumları doğrulamak ve sunumda açıklayabilmek öğrencinin sorumluluğudur.

## Kaynaklar ve yerel doğrulama

- FreeCP: https://arxiv.org/abs/2508.00557
- Sabit kaynak: https://github.com/chenqi1126/FreeCP/tree/6946aa7999ec5d57d1fe91968ba1ae35a1e53295
- SCLIP: https://arxiv.org/abs/2312.01597

Bu paketin CPU testleri ve sözdizimi kontrolleri hazırlama ortamında çalıştırılır; sonuçları `VERIFICATION.json` kaydeder. Hazırlama ortamında Torch/CUDA yoktur. **Yeni GPU akışı burada çalıştırılmış değildir.** Colab'da Torch testleri ve eski yöntemle birebir eşitlik kontrolü yeni deneyden önce çalışır.
