"""Reuse the verified Colab runtime: 50 train images, then 1449 val images."""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from stage2_helpers import UPSTREAM_SHA, BPE_GIT_BLOB_SHA, git_blob_sha, run_logged, save_json


def find_previous_run(root):
    candidates = []
    for report_path in (root / 'runs').glob('*/pilot/pilot_report.json'):
        try:
            report = json.loads(report_path.read_text())
            if (report.get('ok') is True and report.get('upstream_commit') == UPSTREAM_SHA
                    and report.get('model_algorithm_changed') is False
                    and report.get('real_images_evaluated', 0) >= 3):
                candidates.append(report_path.parent.parent)
        except (OSError, ValueError):
            continue
    if not candidates:
        raise RuntimeError('No successful stage-2 run found in this Colab VM. Run notebook 02 here first.')
    return sorted(candidates)[-1]


def main(root=Path('/content/freecp_t4')):
    root = Path(root).resolve()
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    artifact = root / 'runs' / ('baseline_' + run_id)
    artifact.mkdir(parents=True, exist_ok=False)
    state = {'ok': False, 'run_id': run_id, 'experiment': 'unchanged SCLIP+FreeCP baseline',
             'planned_runs': [{'split': 'train', 'images': 50}, {'split': 'val', 'images': 1449}],
             'method_tuning_performed': False, 'improvement_demonstrated': False}
    exit_code = 1
    try:
        repo = root / 'FreeCP'
        python = root / 'env_py310/bin/python'
        voc = root / 'data/VOCdevkit/VOC2012'
        for path in [repo / 'configs/cfg_voc21.py', python, voc / 'ImageSets/Segmentation/val.txt']:
            if not path.exists():
                raise FileNotFoundError(f'{path} is missing. Use the same live Colab VM as notebook 02.')
        previous = find_previous_run(root)
        state['previous_successful_run'] = str(previous)
        inputs = artifact / 'previous_run_evidence'
        inputs.mkdir()
        for name in ['runtime_report.json', 'pip_freeze.txt', 'dataset_manifest.json',
                     'source_revision.json', 'tokenizer_asset.json', 'host_environment.json']:
            shutil.copy2(previous / name, inputs / name)
        shutil.copy2(previous / 'pilot/pilot_report.json', inputs / 'three_image_or_previous_pilot_report.json')
        if (previous / 'licenses').is_dir():
            shutil.copytree(previous / 'licenses', artifact / 'licenses')
        scripts = artifact / 'scripts'
        scripts.mkdir()
        for source in Path(__file__).resolve().parent.iterdir():
            if source.is_file() and source.suffix in {'.py', '.md', '.txt', '.json'}:
                shutil.copy2(source, scripts / source.name)
        env = os.environ.copy()
        env['MPLBACKEND'] = 'Agg'
        env['TOKENIZERS_PARALLELISM'] = 'false'

        def run(command, label, cwd=None):
            run_logged(command, label, artifact, cwd=cwd, env=env)

        if git_blob_sha(repo / 'open_clip/bpe_simple_vocab_16e6.txt.gz') != BPE_GIT_BLOB_SHA:
            raise RuntimeError('Tokenizer asset differs from the verified asset.')
        run([python, scripts / 'check_runtime.py', repo, artifact / 'runtime_report.json'], 'runtime_recheck', cwd=repo)
        current_freeze = subprocess.check_output([str(python), '-m', 'pip', 'freeze'], text=True, env=env)
        (artifact / 'pip_freeze.txt').write_text(current_freeze, encoding='utf-8')
        if set(current_freeze.splitlines()) != set((previous / 'pip_freeze.txt').read_text().splitlines()):
            raise RuntimeError('The isolated dependencies changed after the verified run; inspect before comparing results.')
        run([python, scripts / 'test_metrics.py'], 'independent_metric_tests')
        state['results'] = {}
        for mode, label, count in [('pilot', 'train50', 50), ('reproduction', 'val1449', None)]:
            config = artifact / (label + '_config.py')
            command = [python, scripts / 'prepare_baseline_config.py', '--repo', repo, '--data-root', voc,
                       '--output', config, '--mode', mode, '--seed', '5110']
            if count is not None:
                command.extend(['--count', str(count)])
            run(command, label + '_config')
            run([python, scripts / 'run_evaluation.py', '--repo', repo, '--config', config,
                 '--output', artifact / label, '--mode', mode, '--max-previews', '5'], label + '_evaluation', cwd=repo)
            report = json.loads((artifact / label / 'evaluation_report.json').read_text())
            if not report.get('ok'):
                raise RuntimeError(f'{label} did not complete successfully.')
            state['results'][label] = {k: report.get(k) for k in [
                'real_images_evaluated', 'metrics_percent', 'metrics_crosscheck_passed',
                'full_validation_evaluated', 'mIoU_difference_from_paper_points']}
            save_json(artifact / 'continuation_report.json', state)
        state['ok'] = True
        exit_code = 0
    except Exception as exc:
        state['error'] = f'{type(exc).__name__}: {exc}'
        state['traceback'] = traceback.format_exc()
        print(state['traceback'], flush=True)
    finally:
        save_json(artifact / 'continuation_report.json', state)
        bundle = shutil.make_archive(str(root / ('freecp_baseline_results_' + run_id)), 'zip', root_dir=artifact)
        save_json(root / 'latest_baseline_result.json', {'archive': bundle, 'ok': state['ok'], 'run_id': run_id})
        print(json.dumps(state, indent=2), flush=True)
        print('RESULT_ZIP=' + bundle, flush=True)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
