# 03 — Çalışan kurulumla temel değerlendirmeyi tamamla

Bu paket, 02 notebook'unda doğrulanan **aynı Colab sanal makinesini** kullanır.
Yeni ortam kurmaz, veriyi yeniden indirmez ve FreeCP algoritmasını değiştirmez.
Yeni notebook açmak farklı bir sanal makineye bağlanabilir. Başlatma hücresini mevcut
02 notebook'unun en altına ekle. Oturum silinmişse önce 02 ile kurulumu yeniden yap.

## Tamamlanan aşama

9 Kasım 2026 tarihli gönderilen sonuç paketinde 15 aşama başarılıydı. Ayrı Python 3.10.22
ortamındaki CUDA/MMCV testleri geçti. Üç train görüntüsünde SCLIP+FreeCP çalıştı:
mIoU %50.91, piksel doğruluğu %92.77. Bunlar küçük pilot sonuçlarıdır; val skoru değildir.
Görseller ve gerçek piksel etiketleri oluştu. Kütüphane veya algoritma düzeltmesi gerekmedi.

## Bu paketin çalıştıracağı işler

1. Çalışan ortamı, tokenizer özetini ve bağımlılık listesini önceki başarılı kayıtla kontrol eder.
2. Sabit tohum 5110 ile seçilen 50 VOC2012 train görüntüsünü değerlendirir.
3. Orijinal RP/AP ayarlarıyla VOC2012 val bölümünün **1449 görüntüsünü** değerlendirir.
4. Her görüntünün tahmin maskesini, piksel karışıklık matrisini ve çalışma ölçümlerini saklar.
5. mIoU'yu ayrıca ham etiketlerden hesaplayıp MMSeg sonucuyla karşılaştırır.
6. Sonuçları ZIP olarak paketler. Hata durumunda da o ana kadarki kayıtlar paketlenir.

Önizlemeler, sonuçları görmeden belirlenmiş listedeki ilk beş görüntüdür.
Tüm görüntülerin tahmin maskeleri ve karışıklık matrisleri ayrıca bulunur.
Görsellerde soldan sağa girdi, gerçek etiket, tahmin vardır; gri GT void bölgesidir.

## Sonucu yorumlama

- Train50 geliştirme/pilot bölümüdür; makalenin val skoru ile karşılaştırılmaz.
- Val1449 temel yeniden üretim ölçümüdür. [FreeCP makalesi Tablo 2'de](https://arxiv.org/html/2508.00557v1)
  SCLIP+FreeCP için VOC21 mIoU %65.8 raporlanır. Bizim ölçümümüz ayrıca gösterilecek.
- Val sonucunu görüp yöntem/eşik ayarlamıyoruz. Önerilen değişiklik train pilotunda geliştirilecek.
- `full_validation_evaluated=true` bütün val görüntülerinin işlendiğini belirtir. Bu tek başına
  makalenin başarıyla yeniden üretildiğine karar vermez; farkları birlikte inceleyeceğiz.
- `full_baseline_reproduced=false` ve `reproduction_assessed=false` otomatik başarı iddiasını
  önler; nihai değerlendirmeyi henüz yapmadığımızı gösterir.
- Kaynak algoritma, ağırlıklar, ön işleme ve RP/AP eşikleri değiştirilmez.
  Sadece değerlendirme kapsamı ve sonuç kayıtları genişletilir. İşçi sayısı yine 0'dır.
- Süreler ısınma yapılmadan, veri ön işleme ve kaynak kodun maske okuması dahil ölçülür.
  Bunları resmî hız karşılaştırması olarak sunma. Bellek PyTorch tepe allocated belleğidir;
  CUDA sürücüsü ve başka süreçlerin toplam ekran kartı kullanımı değildir.
- `per_image_confusions.npz` dosyaları daha sonra görüntü bazında eşleştirilmiş belirsizlik
  hesabına olanak verir. Bu aşamada yeni yöntem veya iyileşme ölçülmez.

## Doğrulama ve atıf

Kaynak sürümü: `6946aa7999ec5d57d1fe91968ba1ae35a1e53295`.
Kod: https://github.com/chenqi1126/FreeCP
Makale: https://arxiv.org/abs/2508.00557

`run_evaluation.py`, çalışan `run_pilot.py` üzerinden geliştirildi. Aynı
`Runner.from_cfg` ve `runner.test` yolu kullanılır. Modele müdahale edilmez.
Beş bağımsız metrik testi CPU'da çalıştırıldı. Genişletilmiş GPU değerlendirmesi
henüz kullanıcı tarafında çalıştırılmalıdır; sonuçlar önceden üretilmiş değildir.

AI yardımı: ChatGPT/Codex, sonuç paketi incelemesi, devam betikleri, bağımsız metrik
kontrolü ve açıklamaların hazırlanmasında kullanıldı. Öğrenci kaynakları ve kodu
incelemeli, deneyleri çalıştırmalı, sonuçları doğrulamalı ve bu yardımı raporunda belirtmelidir.
