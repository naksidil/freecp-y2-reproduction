"""CPU-only audit of the packaged, unmodified per-image confusion matrices.

No dataset, checkpoint, network connection, or torch import is required.
"""
from pathlib import Path
import argparse, csv, hashlib, json, sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'freecp_stage9'))
from benchmark_metrics import miou, paired_comparison

def read(stage,condition):
    p=ROOT/'results'/f'stage{stage:02d}'/'conditions'/condition/'per_image_confusions.npz'
    with np.load(p,allow_pickle=False) as a:
        return a['image_ids'].copy(),a['confusion_matrices'].copy()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true',help='Verify hashes, point estimates, pairing and baseline parity; skip bootstrap.')
    ap.add_argument('--out',type=Path,default=ROOT/'output/reanalysis')
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    ledger=json.loads((ROOT/'results/source_members.json').read_text())
    for item in ledger:
        assert hashlib.sha256((ROOT/item['file']).read_bytes()).hexdigest()==item['sha256'],item['file']
    rows=[]
    for path in sorted((ROOT/'results').glob('stage*/conditions/*/per_image_confusions.npz')):
        with np.load(path,allow_pickle=False) as a:
            cm=a['confusion_matrices'];ids=a['image_ids']
            assert len(set(ids))==len(cm) and cm.shape[1:]==(21,21) and np.all(cm>=0),path
            rows.append(dict(stage=path.parts[-4],condition=path.parts[-2],images=len(cm),mIoU=float(miou(cm.sum(0)))))
    with (args.out/'all_condition_scores.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    pairs=[(8,'expanded_y2','expanded_baseline'),(8,'original_y2','original_baseline'),
           (8,'original_y2','original_random'),(8,'expanded_y2','expanded_random'),
           (8,'original_random','original_baseline'),(8,'expanded_random','expanded_baseline'),
           (9,'original_y2','original_baseline')]
    expected8=json.loads((ROOT/'results/stage08/y2_confirmation_summary.json').read_text())['comparisons']
    expected9=json.loads((ROOT/'results/stage09/y2_benchmark_summary.json').read_text())['comparison']
    comparisons=[]
    for i,(stage,method,base) in enumerate(pairs):
        ids,a=read(stage,method);ids_b,b=read(stage,base)
        assert np.array_equal(ids,ids_b) and np.array_equal(a.sum(2),b.sum(2))
        result={'stage':stage,'method':method,'baseline':base}
        if args.quick:result['delta_mIoU']=float(miou(a.sum(0))-miou(b.sum(0)))
        else:result.update(paired_comparison(a,b,draws=5000))
        expected=expected8[i] if stage==8 else expected9
        assert abs(result['delta_mIoU']-expected['delta_mIoU'])<1e-10,result
        if not args.quick:
            assert np.allclose(result['paired_bootstrap_95ci'],expected['paired_bootstrap_95ci'],atol=1e-10,rtol=0),result
        comparisons.append(result)
        print(stage,method,'minus',base,round(result['delta_mIoU'],6),flush=True)
    ids,a=read(5,'original_0p15_clean');ids_b,b=read(9,'original_baseline')
    assert np.array_equal(ids,ids_b) and np.array_equal(a,b),'Baseline replay differs.'
    result=dict(hashes_verified=len(ledger),conditions=len(rows),quick=args.quick,
                baseline_parity_1449=True,comparisons=comparisons)
    (args.out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS:',len(ledger),'source hashes;',len(rows),'condition scores; exact baseline parity.')
    print('Saved',args.out)

if __name__=='__main__':main()
